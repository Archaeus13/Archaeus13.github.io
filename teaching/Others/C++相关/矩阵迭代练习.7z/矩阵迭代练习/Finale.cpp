﻿#include "iter.h"
#include <chrono>

void test1() {
	const int N = 300;
	Matrix a(N, N);
	for (int i = 0; i < N; i++) {
		for (int j = 0; j < N; j++) {
			a[i][j] = rand() % 10;
		}
		a[i][i] += 10 * N;
	}
	Vector real(N);
	for (int i = 0; i < N; i++) {
		real[i] = rand() % 10;
	}
	Vector b = a * real;
	for (int i = 0; i < 30; i++) {
		cout << i << '\t';
		auto start = chrono::high_resolution_clock::now();
		Vector res1 = Jacobi_iter(a, b, i);
		auto end = chrono::high_resolution_clock::now();
		auto duration = chrono::duration_cast<std::chrono::milliseconds>(end - start).count();
		cout << log(to_vec(res1 - real).norm()) << '\t' << duration << '\t';

		start = chrono::high_resolution_clock::now();
		Vector res2 = GS_iter(a, b, i);
		end = chrono::high_resolution_clock::now();
		duration = chrono::duration_cast<std::chrono::milliseconds>(end - start).count();
		cout << log(to_vec(res2 - real).norm()) << '\t' << duration << '\t';

		start = chrono::high_resolution_clock::now();
		Vector res3 = SOR_iter(a, b, i, 1.2);
		end = chrono::high_resolution_clock::now();
		duration = chrono::duration_cast<std::chrono::milliseconds>(end - start).count();
		cout << log(to_vec(res3 - real).norm()) << '\t' << duration << '\t';

		start = chrono::high_resolution_clock::now();
		Vector res4 = SOR_iter(a, b, i, 1.7);
		end = chrono::high_resolution_clock::now();
		duration = chrono::duration_cast<std::chrono::milliseconds>(end - start).count();
		cout << log(to_vec(res4 - real).norm()) << '\t' << duration << '\t';

		cout << endl;
	}
}

void test2() {
	const int N = 60;
	const int M = 2;
	Matrix A(N, N);
	for (int i = 0; i < N; i++) {
		for (int j = 0; j < N; j++) {
			A[i][j]= rand() % 10;
		}
		A[i][i] += 10 * N;
	}
	Matrix U(N, M);
	for (int i = 0; i < N; i++) {
		for (int j = 0; j < M; j++) {
			U[i][j] = rand() % 10;
		}
	}
	double gamma = 0.1;
	Vector real(N);
	for (int i = 0; i < N; i++) {
		real[i] = rand() % 10;
	}
	Vector b = (A + U * (U.transpose() * gamma)) * real;

	auto start = chrono::high_resolution_clock::now();
	Matrix Q = A + U * (U.transpose() * gamma);
	Vector res = GS_iter(Q, b, 10);
	auto end = chrono::high_resolution_clock::now();
	auto duration = chrono::duration_cast<std::chrono::milliseconds>(end - start).count();
	cout << log(to_vec(res - real).norm()) << endl << duration << endl;

	start = chrono::high_resolution_clock::now();
	double alpha = 0;
	for (int i = 0; i < N; i++) {
		alpha += A[i][i];
	}
	alpha /= N;
	alpha *= 1.2;
	res = alpha_iter(A, U, gamma, b, 10, 40, alpha);
	end = chrono::high_resolution_clock::now();
	duration = chrono::duration_cast<std::chrono::milliseconds>(end - start).count();
	cout << log(to_vec(res - real).norm()) << endl << duration << endl;

	start = chrono::high_resolution_clock::now();
	alpha = 0;
	for (int i = 0; i < N; i++) {
		alpha += A[i][i];
	}
	alpha /= N;
	alpha *= 1.2;
	res = Palpha_iter(A, U, gamma, b, 10, 40, alpha);
	end = chrono::high_resolution_clock::now();
	duration = chrono::duration_cast<std::chrono::milliseconds>(end - start).count();
	cout << log(to_vec(res - real).norm()) << endl << duration << endl;
}

int main() {
	test2();
}