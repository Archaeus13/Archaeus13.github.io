// ʵ�ֻ����ľ���������غ���

#include "base.h"

Matrix::Matrix(int m, int n) {
	row = m;
	col = n;
	vector<vector<double>> temp(m, vector<double>(n, 0));
	el = temp;
}

Matrix::Matrix(const Matrix& A) {
	row = A.row;
	col = A.col;
	el = A.el;
}

void Matrix::print() {
	for (int i = 0; i < row; i++) {
		for (int j = 0; j < col; j++) {
			cout << el[i][j] <<  ' ';
		}
		cout << endl;
	}
}

vector<double>& Matrix::operator[] (int i){
	if (i < 0 || i >= row) {
		cout << "Error" << endl;
		return el[0];
	}
	return el[i];
}

Matrix Matrix::operator+(Matrix B) {
	if (row != B.get_row() || col != B.get_col()) {
		cout << "Error" << endl;
		return Matrix(0, 0);
	}
	Matrix Res(row, col);
	for (int i = 0; i < row; i++) {
		for (int j = 0; j < col; j++) {
			Res[i][j] = el[i][j] + B[i][j];
		}
	}
	return Res;
}

Matrix Matrix::operator-(Matrix B) {
	if (row != B.get_row() || col != B.get_col()) {
		cout << "Error" << endl;
		return Matrix(0, 0);
	}
	Matrix Res(row, col);
	for (int i = 0; i < row; i++) {
		for (int j = 0; j < col; j++) {
			Res[i][j] = el[i][j] - B[i][j];
		}
	}
	return Res;
}

Matrix Matrix::operator*(Matrix B) {
	if (col != B.get_row()) {
		cout << "Error" << endl;
		return Matrix(0, 0);
	}
	Matrix Res = Matrix(row, B.get_col());
	for (int i = 0; i < Res.get_row(); i++) {
		for (int j = 0; j < Res.get_col(); j++) {
			for (int k = 0; k < col; k++) {
				Res[i][j] += el[i][k] * B[k][j];
			}
		}
	}
	return Res;
}

Matrix Matrix::operator*(double lambda) {
	Matrix Res(row, col);
	for (int i = 0; i < row; i++) {
		for (int j = 0; j < col; j++) {
			Res[i][j] = el[i][j] * lambda;
		}
	}
	return Res;
}

Matrix Matrix::transpose() {
	Matrix Res(col, row);
	for (int i = 0; i < row; i++) {
		for (int j = 0; j < col; j++) {
			Res[j][i] = el[i][j];
		}
	}
	return Res;
}

Matrix Matrix::inverse_pd() {
	Matrix L = *this;
	for (int k = 0; k < row; k++) {
		L[k][k] = sqrt(L[k][k]);
		for (int i = k + 1; i < row; i++) L[i][k] /= L[k][k];
		for (int j = k + 1; j < row; j++)
			for (int i = j; i < row; i++)
				L[i][j] -= L[i][k] * L[j][k];
	}
	// ֻ��ʹ�������ǲ��� ������Ȼ��
	Matrix LI(row, row);
	for (int j = 0; j < row; j++) {
		Vector Ij(row);
		Ij[j] = 1;
		Vector Res = Ij.Lsolve(L);
		for (int i = 0; i < row; i++) {
			LI[i][j] = Res[i];
		}
	}
	return LI.transpose() * LI;
}

Vector::Vector(const Vector& B) : Matrix(B.row, 1){
	row = B.row;
	el = B.el;
}

void Vector::print() {
	for (int i = 0; i < Matrix::row; i++) {
		cout << Matrix::el[i][0] << ' ';
	}
	cout << endl;
}

double& Vector::operator[](int i){
	return el[i][0];
}

Vector Vector::operator/(Vector B) {
	if (row != B.get_row()) {
		cout << "Error" << endl;
		return Vector(0);
	}
	Vector Res = *this;
	for (int i = 0; i < row; i++) {
		Res[i] /= B[i];
	}
	return Res;

}

double Vector::inner(Vector B) {
	if (row != B.get_row()) {
		cout << "Error" << endl;
		return 0;
	}
	double res = 0;
	for (int i = 0; i < row; i++) {
		res += el[i][0] * B[i];
	}
	return res;
}

double Vector::norm() {
	return sqrt(inner(*this));
}

double Vector::norm(const string ty) {
	if (ty == "2") {
		return norm();
	}
	if (ty == "1") {
		double res = 0;
		for (int i = 0; i < row; i++) {
			res += abs((*this)[i]);
		}
		return res;
	}
	if (ty == "inf") {
		double res = 0;
		for (int i = 0; i < row; i++) {
			res = max(res, abs((*this)[i]));
		}
		return res;
	}
}

Vector Vector::Lsolve(Matrix A) {
	if (A.get_row() != row || A.get_col() != row) {
		cout << "Error" << endl;
		return Vector(0);
	}
	Vector Res = *this;
	for (int i = 0; i < row; i++) {
		for (int j = 0; j < i; j++) {
			Res[i] -= A[i][j] * Res[j];
		}
		Res[i] /= A[i][i];
	}
	return Res;
}

Vector Vector::Usolve(Matrix A) {
	if (A.get_row() != row || A.get_col() != row) {
		cout << "Error" << endl;
		return Vector(0);
	}
	Vector Res = *this;
	for (int i = row - 1; i >= 0; i--) {
		for (int j = i + 1; j < row; j++) {
			Res[i] -= A[i][j] * Res[j];
		}
		Res[i] /= A[i][i];
	}
	return Res;
}

Vector to_vec(Matrix A) {
	if (A.get_col() != 1) {
		cout << "Error" << endl;
		return Vector(0);
	}
	Vector Res(A.get_row());
	for (int i = 0; i < A.get_row(); i++) {
		Res[i] = A[i][0];
	}
	return Res;
}

Vector operator*(Matrix A, Vector B) {
	if (A.get_col() != B.get_row()) {
		cout << "Error" << endl;
		return Vector(0);
	}
	Vector Res = Vector(A.get_row());
	for (int i = 0; i < Res.get_row(); i++) {
		for (int j = 0; j < A.get_col(); j++) {
			Res[i] += A[i][j] * B[j];
		}
	}
	return Res;
}