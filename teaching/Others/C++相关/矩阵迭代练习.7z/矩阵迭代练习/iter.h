#pragma once

#include"base.h"

Vector Jacobi_iter(Matrix A, Vector b, int steps);
Vector GS_iter(Matrix A, Vector b, int steps);
Vector SOR_iter(Matrix A, Vector b, int steps, double omega);
Vector alpha_iter(Matrix A, Matrix U, double gamma, Vector b, int steps, int i_step, double alpha);
Vector Palpha_iter(Matrix A, Matrix U, double gamma, Vector b, int steps, int i_step, double alpha);