#pragma once
#include <iostream>
#include <vector>

using namespace std;

class Matrix {
protected:
	int row;
	int col;
	vector<vector<double>> el;

public:
	Matrix(int m, int n);
	Matrix(const Matrix& A);
	void print();
	inline int get_row() const { return row; };
	inline int get_col() const { return col; };
	vector<double>& operator[](int i);
	Matrix operator+(Matrix B);
	Matrix operator-(Matrix B);
	Matrix operator*(Matrix B);
	Matrix operator*(double lambda);
	Matrix transpose();
	Matrix inverse_pd();
};

class Vector: public Matrix{
public:
	Vector(int m) : Matrix(m, 1) {};
	Vector(const Vector& B);
	void print();
	double& operator[](int i);
	Vector operator/(Vector B);
	double inner(Vector B);
	double norm();
	double norm(const string ty);
	Vector Lsolve(Matrix A); // A ��Ϊ�������� ��� Ax=b
	Vector Usolve(Matrix A); // A ��Ϊ�������� ��� Ax=b
};

Vector to_vec(Matrix A);

Vector operator*(Matrix A, Vector B);