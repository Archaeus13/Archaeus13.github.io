#include "iter.h"

Vector Jacobi_iter(Matrix A, Vector b, int steps) {
	int N = b.get_row();
	Vector res(N);
	Vector D(N);
	for (int i = 0; i < N; i++) {
		D[i] = A[i][i];
		A[i][i] = 0;
	}
	for (int i = 0; i < steps; i++) {
		res = to_vec(A * res * (-1) + b) / D;
		//res.print();
	}
	return res;
}

Vector GS_iter(Matrix A, Vector b, int steps) {
	int N = b.get_row();
	Vector res(N);
	Matrix U(N, N);
	for (int i = 0; i < N; i++) {
		for (int j = i+1;j<N;j++) {
			U[i][j] = -A[i][j];
		}
	}
	for (int i = 0; i < steps; i++) {
		res = to_vec(U * res + b).Lsolve(A);
		//res.print();
	}
	return res;
}

Vector SOR_iter(Matrix A, Vector b, int steps, double omega) {
	int N = b.get_row();
	Vector res(N);
	Matrix U(N, N);
	for (int i = 0; i < N; i++) {
		for (int j = 0; j < i; j++) {
			A[i][j] = omega * A[i][j];
		}
		U[i][i] = (1 - omega) * A[i][i];
		for (int j = i + 1; j < N; j++) {
			U[i][j] = -omega * A[i][j];
		}
	}
	for (int i = 0; i < steps; i++) {
		res = to_vec(U * res + b * omega).Lsolve(A);
		//res.print();
	}
	return res;
}

Vector alpha_iter(Matrix A, Matrix U, double gamma, Vector b, int steps, int i_step, double alpha) {
	// i_step ����ƫС stepsƫ��
	int n = b.get_row();
	int k = U.get_col();
	Matrix I(n, n);
	for (int i = 0; i < n; i++) {
		I[i][i] = 1;
	}
	Matrix Ik(k, k);
	for (int i = 0; i < k; i++) {
		Ik[i][i] = 1;
	}
	Matrix Ap = A + I * alpha;
	Matrix sUp = Ik * alpha + (U.transpose() * U) * gamma;// small U + alpha
	Matrix sUpI = sUp.inverse_pd();
	Vector Res(n);
	for (int i = 0; i < steps; i++) {
		Vector Right = to_vec(Res * alpha - (U * (U.transpose() * Res)) * gamma + b);
		Vector xhalf = GS_iter(Ap, Right, i_step);
		Right = to_vec(xhalf * alpha - A * xhalf + b);
		Res = to_vec(Right * (1 / alpha) - (U * (sUpI * (U.transpose() * Right))) * (gamma / alpha));
	}
	return Res;
}

Vector Palpha_iter(Matrix A, Matrix U, double gamma, Vector b, int steps, int i_step, double alpha) {
	// i_step ��Ҫ�� alpha_iter����
	int n = b.get_row();
	int k = U.get_col();
	Matrix I(n, n);
	for (int i = 0; i < n; i++) {
		I[i][i] = 1;
	}
	Matrix Ik(k, k);
	for (int i = 0; i < k; i++) {
		Ik[i][i] = 1;
	}
	Matrix Ap = A + I * alpha;
	Matrix sUp = Ik * alpha + (U.transpose() * U) * gamma;// small U + alpha
	Matrix sUpI = sUp.inverse_pd();
	Vector Res(n);
	for (int i = 0; i < steps; i++) {
		Vector Right = b;
		Matrix guuTx = (U * (U.transpose() * Res)) * gamma;
		Right = to_vec((Right - A * Res - guuTx) * (2 * alpha));
		Matrix temp = Res * alpha + guuTx;
		Right = to_vec(Right + A * temp + temp * alpha);
		Res = GS_iter(Ap, Right, i_step);
		Res = to_vec(Res * (1 / alpha) - (U * (sUpI * (U.transpose() * Res))) * (gamma / alpha));
	}
	return Res;
}