---
comments: true 
---

# <strong>Logisim 的自动电路生成</strong>


通过前面实验的学习，用户可以使用 Logisim 管理窗中的各种组件以及自己设计的子电路，设计出各种功能的组合逻辑电路，但是在搭建电路时大量的拖拽、布局、连线非常费时费力。好消息是，Logisim 提供了两种自动化生成电路的方式：通过真值表生成、通过表达式生成。


## <strong>3.1 通过真值表</strong>

考虑一个 3bits 优先编码器，输入为 3bits，输出为 2bits。当输入均为 0 时，输出为 11，代表无输入；否则输出为当前的优先译码结果。

我们要设计该电路，一般的做法是：

- 根据真值表画出各输出项的卡诺图；
- 通过卡诺图写出各输出项的逻辑表达式；
- 根据逻辑表达式画出电路图，完成电路设计。

???+ Note "Tips"

    一般真值表中没有列出的输入项，对应的输出视为 x（即 0、1 均可）


Logisim 能够帮我们完成上述步骤中大部分的工作。

首先在 Logisim 中新建一个电路图（电路名称自拟），在电路图中放置输入引脚，有几个输入就放几个引脚，按同样的方式放置输出引脚。放置完毕后，给所有引脚标上标号，并按高低位顺序排列。对于表 1，我们的输入引脚为三个，输出引脚为两个。完成后的效果如下图所示。

<figure markdown>
  ![Image title](./figs/logisim/log_example1.png){ width="700" }
</figure>

接下来，在菜单栏的 Project 选项卡中找到 Analyze Circuit 选项并选中。在弹出的窗口中选择 Table 选项，按照前面的真值表修改输出值（鼠标点击输出信号对应的叉号就可修改），最后点击 Build Circuit 便可生成电路（弹出的对话框都选择是）


<table><tr>
<td><figure>
<img src="../figs/logisim/log_example2.png" width="400">
<figcaption>打开 Analyze Circuit 窗口</figcaption>
</figure></td>

<td><figure>
<img src="../figs/logisim/log_example3.png" width="415">
<figcaption>修改输出值</figcaption>
</figure></td>
</tr></table>

生成的电路如下图所示。

<figure markdown>
  ![Image title](./figs/logisim/log_example4.png){ width="400" }
</figure>


## <strong>3.2 通过表达式</strong>

通过真值表生成电路确实能为我们减少工作，但是也存在不足之处，我们知道，真值表条目数与输入项个数呈指数相关，当输入信号数量较多时，编辑真值表也是一项非常繁重的工作。例如：一个 8 位的优先编码器电路，其完整的真值表有 256 项之多。此时，我们可以选择通过表达式生成电路。

???+ Note "Tips"

    通过表达式生成电路的前提是，用户已经知道了各输出项的逻辑表达式。


回到 3bits 优先编码器的例子。首先在 Logisim 中新建一个电路图（电路名称自拟），在电路图中放置输入引脚，有几个输入就放几个引脚，按同样的方式放置输出引脚。放置完毕后，给所有引脚标上标号，并按高低位顺序排列。完成后的效果如图所示。

<figure markdown>
  ![Image title](./figs/logisim/yinjiao.png){ width="700" }
</figure>

接下来，在菜单栏的 Project 选项卡中找到 Analyze Circuit 选项并选中。在弹出的窗口中选择 Expression 选项，按照相应的接口填入各输出项的逻辑表达式，最后点击 Build Circuit 生成电路：

<table><tr>
<td><figure>
<img src="../figs/logisim/expression.png" width="400">
<figcaption>打开 Analyze Circuit 窗口</figcaption>
</figure></td>

<td><figure>
<img src="../figs/logisim/expression_1.png" width="415">
<figcaption>修改输出值</figcaption>
</figure></td>
</tr></table>

<figure markdown>
  ![Image title](./figs/logisim/expression_done.png){ width="400" }
</figure>