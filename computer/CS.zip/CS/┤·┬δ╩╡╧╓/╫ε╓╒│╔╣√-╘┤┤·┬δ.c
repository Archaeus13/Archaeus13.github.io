//ѧ����Ϣ����ϵͳ 
//�����ߣ�֣����
//ѧ�ţ�PB20000296 
 
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdbool.h>
#define N sizeof(stu) 

typedef struct Student {
	int iSerial;
	char sStuNum[11];
	char sStuName[10];
	bool bGender;
	short siCScore;
	struct Student* next;
} stu;

typedef struct Data {
	int iSerial;
	char sStuNum[11];
	char sStuName[10];
	bool bGender;
	short siCScore;
} dat;

int choose(void)
{
	int c;
	puts("\n************************************************\n");
	puts("Welcome to Management Information System");
	puts("Produced by PB20000296");
    puts("\n************************************************\n");
	puts("Please choose a sequential list/a linked list");
	while (1) {
		puts("Input 1 for a sequential list, 2 for a linked list:");
	    scanf("%d", &c);
	    switch (c) {
		    case 1:
				puts("Choose complete! A sequential list is ready.");
				return 0;
				
		    case 2:
			    puts("Choose complete! A linked list is ready.");
				return 1;
		
		    default:
		    	puts("\aERR: Input error, try again.");
		    	while(getchar() != '\n');
	    }
	}
}

int inputPassword(char password[])
{
	char s[20];
	while(getchar() != '\n');
	puts("Please enter the password");
	scanf("%[^\n]", s);
	if (!strcmp(password, s)) return 0;
	puts("\aERR: Wrong password.");
	return 1;
}

void enterPassword(char password[])
{
	char s[20];
	while(1) {
		while(getchar() != '\n');
		puts("Now please enter the new password, finishing with \"enter\"");
	    scanf("%[^\n]", password);
	    while(getchar() != '\n');
		puts("Input again to confirm:");
		scanf("%[^\n]", s);
		if (!strcmp(password, s)) break;
		puts("\aERR: Different input, try again.");
	}
}

void printHelp(void)
{
	puts("\n************************************************\n");
	puts("Welcome to Management Information System");
	puts("Produced by PB20000296");
	puts("You don't need the password to enter the Student List.");
	puts("In this list, you can search, find statistics or output a file.");
	puts("After inputing the password, you can enter the Manager List and Setting List.");
	puts("In the manager list, you can insert, delete or alter the information.");
	puts("In the setting list, you can change the password or initialize again.");
	puts("Press any key to go back to main menu.");
	getch();
}

void printStudentlist(void)
{
	puts("\n************************************************\n");
	puts("Choose an action to continue:");
	puts("1-Search for information");
	puts("2-Search by score");
	puts("3-Find statistics");
	puts("4-Output a file");
	puts("5-Exit to main menu");
}

void printManagerlist(void)
{
	puts("\n************************************************\n");
	puts("Choose an action to continue:");
	puts("1-Insert information");
	puts("2-Delete information");
	puts("3-Change information");
	puts("4-Exit to main menu");
}

void printSettinglist(void)
{
	puts("\n************************************************\n");
	puts("Choose an action to continue:");
	puts("1-Change the password");
	puts("2-Initialize");
	puts("3-Exit to main menu");
}

void printMainmenu(void)
{
	puts("\n************************************************\n");
	puts("Choose a list to continue:");
	puts("0-Help");
	puts("1-Student List");
	puts("2-Manager List");
	puts("3-Setting List");
	puts("4-Exit");
}

void printdat_S(dat info)
{
	printf("%d\t", info.iSerial);
	printf("%s\t", info.sStuNum);
	printf("%s\t", info.sStuName);
	if (info.bGender) printf("%s", "��\t");
	else printf("%s", "Ů\t");
	printf("%hd\n", info.siCScore);
}

int initialize_S(dat info[], char password[])
{
	char s[20];
	int i = 0;
	dat temp;
	FILE *fp;
	while(1) {
		while(getchar() != '\n');
		puts("Please input the name of the original file:");
	    scanf("%[^\n]", s);
	    if(!(fp = fopen(s, "rb"))) puts("\aERR: Cannot open the file, try again.");
		else break;
	}
	fread(&temp, sizeof(dat), 1, fp);
	while(!feof(fp)) {
		info[i] = temp;
		printdat_S(info[i]);
		i++;
		fread(&temp, sizeof(dat), 1, fp);
	}
	puts("\nReading complete!");
	printf("Total: %d\n", i); 
	fclose(fp);
	enterPassword(password);
	puts("Initialization complete!");
	getch();
	return i;
}

void search_S(dat info[], int length)
{
	int i;
	char s[20];
	while(getchar() != '\n');
	puts("Please input the student number or student name");
	scanf("%s", s);
	for (i = 0; i < length; i++) if (!(strcmp(s, info[i].sStuNum)*strcmp(s, info[i].sStuName))) {
	    printdat_S(info[i]);
	    getch();
	    return;
	}
	puts("\aERR: Data not found.");
	getch();
}

void searchscore_S(dat info[], int length)
{
	int begin, end, i, find = 0;
	while(getchar() != '\n');
	puts("Input the beginning score:");
	scanf("%d", &begin);
	while(getchar() != '\n');
	puts("Input the ending score:");
	scanf("%d", &end);
	if (begin > end) {
		puts("\aERR: begin is greater than end");
		getch();
		return;
	}
	for (i = 0; i < length; i++) if (info[i].siCScore >= begin && info[i].siCScore <= end) {
	    printdat_S(info[i]);
	    find++;
	}
	if (!find) puts("\aERR: Data not found.");
	else printf("Total: %d", find);
	getch();
}

void statistics_S(dat info[], int length)
{
	int score[10], i;
	long sum;
	double average;
	for (i = 0; i < 10; i++) score[i] = 0;
	for (i = 0; i < length; i++) {
		score[(info[i].siCScore - 1) / 10]++;
		sum += info[i].siCScore;
	}
	for (i = 0; i < 10; i++) printf("%d to %d: %d\n", i * 10 + 1, i * 10 + 10, score[i]);
	average = (double) sum / length;
	printf("Average: %.2lf\n", average);
	getch();
}

void output_S(dat info[], int length)
{
	int i;
	char s[20];
	FILE *fp;
	while(getchar() != '\n');
	puts("Please input the name of the file:");
	scanf("%s", s);
	if (!(fp = fopen(strcat(s, ".txt"), "w"))) {
		puts("\aERR: Fail to create the file.");
		return;
	}
	for (i = 1; i < length; i++) {
		fprintf(fp, "%d\t", info[i].iSerial);
	    fprintf(fp, "%s\t", info[i].sStuNum);
	    fprintf(fp, "%s\t", info[i].sStuName);
	    if (info[i].bGender) fprintf(fp, "%s", "��\t");
	    else fprintf(fp, "%s", "Ů\t");
	    fprintf(fp, "%hd\n", info[i].siCScore);
	}
	fclose(fp);
	puts("Complete!");
}

void studentlist_S(dat info[], int length)
{
	int t;
	while(1) {
		while(getchar() != '\n');
		printStudentlist();
		scanf("%d", &t);
		switch(t) {
			case 1:
				search_S(info, length);
				break;
				
			case 2:
				searchscore_S(info, length);
				break;
				
			case 3:
				statistics_S(info, length);
				break;
				
			case 4:
				output_S(info, length);
				break;
				
			case 5:
				return;
					
			default:
				puts("\aERR: Input error, try again.");
		}
	}
}

int insert_S(dat info[], int length)
{
	int i, t, read;
	if (length == 200) {
		puts("\aERR: Data is full.");
	    return length;
	}
	puts("Where do you want to insert? (0 means before the first data, etc.)");
	scanf("%d", &t);
	if (t > length || t < 0) {
		puts("\aERR: Input error, try again.");
		return length;
	}
	for (i = length - 1; i >= t; i--) {
		info[i + 1] = info[i];
	    info[i + 1].iSerial++;
	}
	puts("Number:");
	scanf("%s", info[t].sStuNum);
	puts("Name:");
	scanf("%s", info[t].sStuName);
	while(1) {
		while(getchar() != '\n');
		puts("Gender (1 for male, 0 for female):");
	    scanf("%d", &read);
	    if (!read || read == 1) {
	    	info[t].bGender = read;
	    	break;
		}
		puts("\aERR: Input error, try again.");
	}
	while(1) {
		while(getchar() != '\n');
		puts("Score:");
	    scanf("%d", &read);
	    if (read >= 0 && read <= 100) {
	    	info[t].siCScore = read;
	    	break;
		}
		puts("\aERR: Input error, try again.");
	}
	puts("Input complete!");
	return ++length;
}

int delete_S(dat info[], int length)
{
	int i, t, read;
	if (length == 1) {
		puts("\aERR: Data can't be deleted to empty.");
	    return length;
	}
	puts("Where do you want to delete?");
	scanf("%d", &t);
	if (t > length || t <= 0) {
		puts("\aERR: Input error, try again.");
		return length;
	}
	printdat_S(info[t - 1]);
	while(1) {
		while(getchar() != '\n');
		puts("Are you sure you want to delete this? (1 for yes, 0 for no)");
	    scanf("%d", &read);
	    if (!read) return length;
	    if (read == 1) break;
		puts("\aERR: Input error, try again.");
	}
	for (i = t - 1; i < length; i++) {
		info[i] = info[i + 1];
	    info[i].iSerial--;
	}
	puts("Delete complete!");
	return --length;
}

void change_S(dat info[], int length)
{
	int i, t, read;
	puts("Where do you want to change?");
	scanf("%d", &t);
	if (t > length || t <= 0) {
		puts("\aERR: Input error, try again.");
		return;
	}
	printdat_S(info[t - 1]);
	puts("Input the new information");
	puts("Number:");
	scanf("%s", info[t - 1].sStuNum);
	puts("Name:");
	scanf("%s", info[t - 1].sStuName);
	while(1) {
		while(getchar() != '\n');
		puts("Gender (1 for male, 0 for female):");
	    scanf("%d", &read);
	    if (!read || read == 1) {
	    	info[t - 1].bGender = read;
	    	break;
		}
		puts("\aERR: Input error, try again.");
	}
	while(1) {
		while(getchar() != '\n');
		puts("Score:");
	    scanf("%d", &read);
	    if (read >= 0 && read <= 100) {
	    	info[t - 1].siCScore = read;
	    	break;
		}
		puts("\aERR: Input error, try again.");
	}
	puts("Change complete!");
}

int managerlist_S(dat info[], int length, char password[])
{
	int t;
	if(inputPassword(password)) return length;
	while(1) {
		while(getchar() != '\n');
		printManagerlist();
		scanf("%d", &t);
		switch(t) {
			case 1:
				length = insert_S(info, length);
				break;
				
			case 2:
				length = delete_S(info, length);
				break;
				
			case 3:
				change_S(info, length);
				break;
				
			case 4:
				return length;
					
			default:
				puts("\aERR: Input error, try again.");
		}
	}
}

int settinglist_S(char password[])
{
	int t;
	if(inputPassword(password)) return 0;
	while(1) {
		while(getchar() != '\n');
		printSettinglist();
		scanf("%d", &t);
		switch(t) {
			case 1:
				enterPassword(password);
				puts("Complete!"); 
				getch();
				break;
				
			case 2:
				return 1;
				
			case 3:
				return 0;
					
			default:
				puts("\aERR: Input error, try again.");
		}
	}
}

int mainmenu_S(dat info[], int length, char password[])
{
	int t;
	while(1) {
		while(getchar() != '\n');
		printMainmenu();
		scanf("%d", &t);
		switch(t) {
			case 0:
				printHelp();
				break;
				
			case 1:
				studentlist_S(info, length);
				break;
				
			case 2:
				length = managerlist_S(info, length, password);
				break;
				
			case 3:
				if(settinglist_S(password)) return 0;
				break;
				
			case 4:
				return 1;
				
			default:
				puts("\aERR: Input error, try again.");
		}
	}
}

void printdat_L(stu *p)
{
	printf("%d\t", p->iSerial);
	printf("%s\t", p->sStuNum);
	printf("%s\t", p->sStuName);
	if (p->bGender) printf("%s", "��\t");
	else printf("%s", "Ů\t");
	printf("%hd\n", p->siCScore);
}

stu* initialize_L(char password[])
{
	char s[20];
	int i = 0;
	dat temp;
	stu *p, *head;
	FILE *fp;
	if (!(head = malloc(N))) puts("\aERR: Not enough space");
	p = head;
	while(1) {
		while(getchar() != '\n');
		puts("Please input the name of the original file:");
	    scanf("%[^\n]", s);
	    if(!(fp = fopen(s, "rb"))) puts("\aERR: Cannot open the file, try again.");
		else break;
	}
	fread(&temp, sizeof(dat), 1, fp);
	while(!feof(fp)) {
		if (!(p->next = malloc(N))) puts("\aERR: Not enough space");
		p = p->next;
		p->iSerial = temp.iSerial;
		strcpy(p->sStuNum, temp.sStuNum);
		strcpy(p->sStuName, temp.sStuName);
		p->bGender = temp.bGender;
		p->siCScore = temp.siCScore;
		printdat_L(p);
		i++;
		fread(&temp, sizeof(dat), 1, fp);
	}
	p->next = NULL;
	puts("\nReading complete!");
	printf("Total: %d\n", i); 
	fclose(fp);
	enterPassword(password);
	puts("Initialization complete!");
	getch();
	return head;
}

void search_L(stu* head)
{
	char s[20];
	while (getchar() != '\n');
	puts("Please input the student number or student name");
	scanf("%s", s);
	while (head->next) {
		head = head->next;
		if (!(strcmp(s, head->sStuNum)*strcmp(s, head->sStuName))) {
	    	printdat_L(head);
	    	getch();
	    	return;
	    }
	}
	puts("\aERR: Data not found.");
	getch();
}

void searchscore_L(stu* head)
{
	int begin, end, find = 0;
	while(getchar() != '\n');
	puts("Input the beginning score:");
	scanf("%d", &begin);
	while(getchar() != '\n');
	puts("Input the ending score:");
	scanf("%d", &end);
	if (begin > end) {
		puts("\aERR: begin is greater than end");
		getch();
		return;
	}
	while(head->next) {
		head = head->next; 
		if (head->siCScore >= begin && head->siCScore <= end) {
	        printdat_L(head);
	        find++;
	    }
    }
	if (!find) puts("\aERR: Data not found.");
	else printf("Total: %d", find);
	getch();
}

void statistics_L(stu* head)
{
	int score[10], i, t;
	long sum;
	double average;
	for (i = 0; i < 10; i++) score[i] = 0;
	while(head->next) {
		head = head->next;
		t++;
		score[(head->siCScore - 1) / 10]++;
		sum += head->siCScore;
	}
	for (i = 0; i < 10; i++) printf("%d to %d: %d\n", i * 10 + 1, i * 10 + 10, score[i]);
	average = (double) sum / t;
	printf("Average: %.2lf\n", average);
	getch();
}

void output_L(stu* head)
{
	int i;
	char s[20];
	FILE *fp;
	dat temp;
	while(getchar() != '\n');
	puts("Please input the name of the file:");
	scanf("%s", s);
	if (!(fp = fopen(s, "wb"))) {
		puts("\aERR: Fail to create the file.");
		return;
	}
	while (head->next) {
		head = head->next;
		temp.iSerial = head->iSerial;
	    strcpy(temp.sStuNum, head->sStuNum);
		strcpy(temp.sStuName, head->sStuName);
		temp.bGender = head->bGender;
		temp.siCScore = head->siCScore;
	    fwrite(&temp, sizeof(dat), 1, fp);
	}
	fclose(fp);
	puts("Complete!");
}

void studentlist_L(stu* head)
{
	int t;
	while(1) {
		while(getchar() != '\n');
		printStudentlist();
		scanf("%d", &t);
		switch(t) {
			case 1:
				search_L(head);
				break;
				
			case 2:
				searchscore_L(head);
				break;
				
			case 3:
				statistics_L(head);
				break;
				
			case 4:
				output_L(head);
				break;
				
			case 5:
				return;
					
			default:
				puts("\aERR: Input error, try again.");
		}
	}
}

void insert_L(stu* head)
{
	int i, t, read;
	stu *q;
	puts("Where do you want to insert? (0 means before the first data, etc.)");
	scanf("%d", &t);
	if (t < 0) {
		puts("\aERR: Input error, try again.");
		return;
	}
	for (i = 0; i < t; i++) {
		if (!(head->next)) {
			puts("\aERR: Input error, try again.");
		    return;
		}
		head = head->next;
	}
	if (!(q = malloc(N))) puts("\aERR: Not enough space");
	puts("Number:");
	scanf("%s", q->sStuNum);
	puts("Name:");
	scanf("%s", q->sStuName);
	while(1) {
		while(getchar() != '\n');
		puts("Gender (1 for male, 0 for female):");
	    scanf("%d", &read);
	    if (!read || read == 1) {
	    	q->bGender = read;
	    	break;
		}
		puts("\aERR: Input error, try again.");
	}
	while(1) {
		while(getchar() != '\n');
		puts("Score:");
	    scanf("%d", &read);
	    if (read >= 0 && read <= 100) {
	    	q->siCScore = read;
	    	break;
		}
		puts("\aERR: Input error, try again.");
	}
	q->next = head->next;
	head->next = q;
	while (head->next) {
		head = head->next;
		t++;
		head->iSerial = t;
	}
	puts("Input complete!");
}

void delete_L(stu* head)
{
	int i, t, read;
	stu *q;
	if (!(head->next->next)) {
		puts("\aERR: Data can't be deleted to empty.");
	    return;
	}
	puts("Where do you want to delete?");
	scanf("%d", &t);
	if (t <= 0) {
		puts("\aERR: Input error, try again.");
		return;
	}
	for (i = 0; i < t - 1; i++) {
		if (!(head->next)) {
			puts("\aERR: Input error, try again.");
		    return;
		}
		head = head->next;
	}
	if (!(head->next)) {
			puts("\aERR: Input error, try again.");
		    return;
	}
	printdat_L(head->next);
	while(1) {
		while(getchar() != '\n');
		puts("Are you sure you want to delete this? (1 for yes, 0 for no)");
	    scanf("%d", &read);
	    if (!read) return;
	    if (read == 1) break;
		puts("\aERR: Input error, try again.");
	}
	q = head->next;
	head->next = head->next->next;
	free(q);
	while (head->next) {
		head = head->next;
	    head->iSerial--;
	}
	puts("Delete complete!");
}

void change_L(stu* head)
{
	int i, t, read;
	puts("Where do you want to change?");
	scanf("%d", &t);
	if (t <= 0) {
		puts("\aERR: Input error, try again.");
		return;
	}
	for (i = 0; i < t; i++) {
		if (!(head->next)) {
			puts("\aERR: Input error, try again.");
		    return;
		}
		head = head->next;
	}
	printdat_L(head);
	puts("Input the new information");
	puts("Number:");
	scanf("%s", head->sStuNum);
	puts("Name:");
	scanf("%s", head->sStuName);
	while(1) {
		while(getchar() != '\n');
		puts("Gender (1 for male, 0 for female):");
	    scanf("%d", &read);
	    if (!read || read == 1) {
	    	head->bGender = read;
	    	break;
		}
		puts("\aERR: Input error, try again.");
	}
	while(1) {
		while(getchar() != '\n');
		puts("Score:");
	    scanf("%d", &read);
	    if (read >= 0 && read <= 100) {
	    	head->siCScore = read;
	    	break;
		}
		puts("\aERR: Input error, try again.");
	}
	puts("Change complete!");
}

void managerlist_L(stu* head, char password[])
{
	int t;
	if(inputPassword(password)) return;
	while(1) {
		while(getchar() != '\n');
		printManagerlist();
		scanf("%d", &t);
		switch(t) {
			case 1:
				insert_L(head);
				break;
				
			case 2:
				delete_L(head);
				break;
				
			case 3:
				change_L(head);
				break;
				
			case 4:
				return;
					
			default:
				puts("\aERR: Input error, try again.");
		}
	}
}

int settinglist_L(stu* head, char password[])
{
	int t;
	stu* p = head;
	if(inputPassword(password)) return 0;
	while(1) {
		while(getchar() != '\n');
		printSettinglist();
		scanf("%d", &t);
		switch(t) {
			case 1:
				enterPassword(password);
				puts("Complete!"); 
				getch();
				break;
				
			case 2:
				while (p->next) {
					p = p->next;
					free(head);
					head = p;
				}
				free(head);
				return 1;
				
			case 3:
				return 0;
					
			default:
				puts("\aERR: Input error, try again.");
		}
	}
}

int mainmenu_L(stu* head, char password[])
{
	int t;
	while(1) {
		while(getchar() != '\n');
		printMainmenu();
		scanf("%d", &t);
		switch(t) {
			case 0:
				printHelp();
				break;
				
			case 1:
				studentlist_L(head);
				break;
				
			case 2:
				managerlist_L(head, password);
				break;
				
			case 3:
				if(settinglist_L(head, password)) return 0;
				break;
				
			case 4:
				return 1;
				
			default:
				puts("\aERR: Input error, try again.");
		}
	}
}

int main(void) {
	int n;
	char password[20];
	dat info[200];
	stu *head;
	while(1) {
		if (choose()) {
			head = initialize_L(password);
		    if(mainmenu_L(head, password)) return 0;
		}
		else {
			n = initialize_S(info, password);
			if(mainmenu_S(info, n, password)) return 0;
		}
	}
}
