#include <iostream>
using namespace::std;

struct node{
	ElemType n;
	struct node* next;
};

int InitQueue(node* &p) {
	if (p) return -1;
	p = new node;
	p->next = NULL;
	return 0;
}

int DestroyQueue(node* &p) {
	if (!p)	return -1;
	node* q;
	while (p) {
		q = p;
		p = p->next;
		delete q;
	}
	return 0;
}

int EnQueue(node* &p, ElemType a) {
	if (!p) return -1;
	node* s = new node;
	p->n = a;
	s->next = p;
	p = s;
	return 0;
}

int DeQueue(node* &p, ElemType &a) {
	if (!p) return -1;
	if (!p->next) return 1;
	node* s = p, *t;
	while (s->next->next) s = s->next;
	t = s->next;
	s->next = NULL;
	a = t->n;
	delete t;
	return 0;
}

int GetTop(node* p, ElemType &a) {
	if (!p) return -1;
	if (!p->next) return 1;
	node* s = p;
	while (s->next) s = s->next;
	a = s->n;
	return 0;
}

int TraverseQueue(node* p) {
	if (!p) return -1;
	if (!p->next) return 1;
	while (p->next) {
		p = p->next;
		cout << p->n << ' ';
	}
	cout << endl;
	return 0;
}
