clear;
a0 = @(x) 1 + 0 * x(:, 1);
r2 = @(x) x(:, 1) .^ 2 + x(:, 2) .^ 2;
f = @(x) 20 / 3 * nthroot(r2(x), 3) .* sin(theta(x) * 2 / 3);
exact_u = @(x) (1 - r2(x)) .* nthroot(r2(x), 3).* sin(theta(x) * 2 / 3);
node = [-1, -1; -1, 0; -1, 1; 0, -1; 0, 0; 0, 1; 1, 0; 1, 1];
elem = [1, 4, 5; 5, 2, 1; 2, 5, 6; 6, 3, 2; 5, 7, 8; 8, 6, 5];
[node, elem] = uniformrefine(node, elem);
T = 9;
l2 = zeros(1, T);
li = zeros(1, T);
h1 = zeros(1, T);
w1i = zeros(1, T);

gx = @(x) eux(x);
gy = @(x) euy(x);
for i = 1:T
    if i == T
        res = poisson_L(node, elem, a0, f, exact_u, gx, gy, 1, 1);
    else
        res = poisson_L(node, elem, a0, f, exact_u, gx, gy, 0, 1);
    end
    N = size(node, 1);
    M = size(elem, 1);
    err1 = res(1:N) - exact_u(node);
    err2 = res(N+1:2*N) - eux(node);
    err3 = res(2*N+1:3*N) - euy(node);
    err4 = res(3*N+1:end) - exact_u((node(elem(:, 1), :) + ...
        node(elem(:, 2), :) + node(elem(:, 3), :)) / 3);
    l2(i) = 2 * sqrt((sum(err1 .^ 2) + sum(err4 .^ 2)) / (M + N));
    li(i) = max(max(abs(err1)), max(abs(err4)));
    h1(i) = sqrt(l2(i) ^ 2 + 4 * (sum(err2 .^ 2) + sum(err3 .^ 2)) / N);
    w1i(i) = max([li(i), max(abs(err2)), max(abs(err3))]);
    [node, elem] = uniformrefine(node, elem);
end
figure;
plot(1:T, log(l2)/log(2), LineWidth=1.5);
hold on;
plot(1:T, log(li)/log(2), LineWidth=1.5);
plot(1:T, log(h1)/log(2), LineWidth=1.5);
plot(1:T, log(w1i)/log(2), LineWidth=1.5);
ylabel("log_2(error)");
xlabel("-log_2(h)");
legend(["L^2", "L^\infty", "H^1", "W^1_\infty"]);

function t = theta(x)
    temp = x(:, 1) .^ 2 + x(:, 2) .^ 2;
    t = (x(:, 2) > 0 | (x(:, 2) == 0 & x(:, 1) >= 0)) .* ...
        acos(x(:, 1) ./ sqrt(temp)) ...
        + (x(:, 2) < 0 | (x(:, 2) == 0 & x(:, 1) < 0)) .* ...
        (2 * pi - acos(x(:, 1) ./ sqrt(temp)));
    t(temp == 0) = 0;
end
function res = eux(x)
    temp = x(:, 1) .^ 2 + x(:, 2) .^ 2;
    t = theta(x);
    res = -2 * (1 - temp + 3 * temp .* cos(t * 2 / 3) ...
    + 3 * temp .* cos(t * 4 / 3)) .* sin(t / 3) / 3 ...
    ./ nthroot(temp, 6);
    res(temp == 0) = 0;
end
function res = euy(x)
    temp = x(:, 1) .^ 2 + x(:, 2) .^ 2;
    t = theta(x);
    res = -2 * (-1 + temp + 3 * temp .* cos(t * 2 / 3) ...
    - 3 * temp .* cos(t * 4 / 3)) .* cos(t / 3) / 3 ...
    ./ nthroot(temp, 6);
    res(temp == 0) = 0;
end