function [u, A, r] = poisson_L(node, elem, a0, f, g, gx, gy, if_time, if_s)
    N = size(node, 1);
    M = size(elem, 1);
    Z = 3 * N + M;
    
    % after each part, clear needless variables and count time
    if if_time
        tic;
    end

    %% Count somthing about a, b, c, d

    % to get rid of repetitive countings

    a = node(elem(:, 2), 1) - node(elem(:, 1), 1);
    b = node(elem(:, 2), 2) - node(elem(:, 1), 2);
    c = node(elem(:, 3), 1) - node(elem(:, 1), 1);
    d = node(elem(:, 3), 2) - node(elem(:, 1), 2);

    a2 = a .^ 2; b2 = b .^ 2; c2 = c .^ 2; d2 = d .^ 2;
    ab = a .* b; ac = a .* c; ad = a .* d;
    bc = b .* c; bd = b .* d; cd = c .* d;

    a3 = a2 .* a; b3 = b2 .* b; c3 = c2 .* c; d3 = d2 .* d;
    bcd = bc .* d; acd = ac .* d; abd = ab .* d; abc = ab .* c;
    ab2 = ab .* b; a2b = a2 .* b; ac2 = ac .* c; a2c = a2 .* c;
    ad2 = ad .* d; a2d = a2 .* d; bc2 = bc .* c; b2c = b2 .* c;
    bd2 = bd .* d; b2d = b2 .* d; cd2 = cd .* d; c2d = c2 .* d;

    a3c = a3 .* c; a3d = a3 .* d; a2bc = a2b .* c; a2bd = a2b .* d;
    a2c2 = a2c .* c; a2cd = a2c .* d; a2d2 = a2d .* d; ab2c = ab2 .* c;
    ab2d = ab2 .* d; abc2 = abc .* c; abcd = abc .* d; abd2 = abd .* d;
    ac3 = ac2 .* c; ac2d = ac2 .* d; acd2 = acd .* d; ad3 = ad2 .* d;
    b3c = b3 .* c; b3d = b3 .* d; b2c2 = b2c .* c; b2cd = b2c .* d;
    b2d2 = b2d .* d; bc3 = bc2 .* c; bc2d = bc2 .* d; bcd2 = bcd .* d;
    bd3 = bd2 .* d;

    D = bc - ad; D2 = D .^ 2; D3 = D2 .* D;
    
    if if_time
        toc;
    end
    
    %% Count Hermite coefficients
    
    % pc(k, i, :) the coe of pi in Tk
    % order: x^3 x^2y xy^2 y^3 x^2 xy y^2 x y 1

    pc = zeros(M, 10, 10);

    pc(:, 1, 1) = -(-2 * b3 + 13 * b2d - 13 * bd2 + 2 * d3) ./ D3;
    pc(:, 1, 2) = -(6 * ab2 - 13 * b2c - 26 * abd + 26 * bcd + 13 * ad2 - 6 * cd2) ./ D3;
    pc(:, 1, 3) = -(-6 * a2b + 26 * abc - 13 * bc2 + 13 * a2d - 26 * acd + 6 * c2d) ./ D3;
    pc(:, 1, 4) = -(2 * a3 - 13 * a2c + 13 * ac2 - 2 * c3) ./ D3;
    pc(:, 1, 5) = (-3 * b2 + 13 * bd - 3 * d2) ./ D2;
    pc(:, 1, 6) = (6 * ab - 13 * bc - 13 * ad + 6 * cd) ./ D2;
    pc(:, 1, 7) = (-3 * a2 + 13 * ac - 3 * c2) ./ D2;
    pc(:, 1, 10) = 1;

    pc(:, 2, 1) = -(7 * b2d - 7 * bd2 - 2 * d3) ./ D3;
    pc(:, 2, 2) = -(-7 * b2c - 14 * abd + 14 * bcd + 7 * ad2 + 6 * cd2) ./ D3;
    pc(:, 2, 3) = -(14 * abc - 7 * bc2 + 7 * a2d - 14 * acd - 6 * c2d) ./ D3;
    pc(:, 2, 4) = -(-7 * a2c + 7 * ac2 + 2 * c3) ./ D3;
    pc(:, 2, 5) = (7 * bd + 3 * d2) ./ D2;
    pc(:, 2, 6) = (-7 * bc - 7  * ad - 6 * cd) ./ D2;
    pc(:, 2, 7) = (7 * ac + 3 * c2) ./ D2;

    pc(:, 3, 1) = (-2 * b3 - 7 * b2d + 7 * bd2) ./ D3;
    pc(:, 3, 2) = -(-6 * ab2 - 7 * b2c - 14 * abd + 14 * bcd + 7 * ad2) ./ D3;
    pc(:, 3, 3) = -(6 * a2b + 14 * abc - 7 * bc2 + 7 * a2d - 14 * acd) ./ D3;
    pc(:, 3, 4) = -(-2 * a3 - 7 * a2c + 7 * ac2) ./ D3;
    pc(:, 3, 5) = (3 * b2 + 7 * bd) ./ D2;
    pc(:, 3, 6) = (-6 * ab - 7 * bc - 7 * ad) ./ D2;
    pc(:, 3, 7) = (3 * a2 + 7 * ac) ./ D2;

    pc(:, 4, 1) = (b3c - 2 * ab2d - 3 * b2cd + 3 * abd2 + 2 * bcd2 - ad3) ./ D3;
    pc(:, 4, 2) = (-ab2c+ 3 * b2c2 + 4 * a2bd - 4 * bc2d - 3 * a2d2 + acd2) ./ D3;
    pc(:, 4, 3) = -(a2bc + 3 * abc2 - 2 * bc3 + 2 * a3d - 3 * a2cd - ac2d) ./ D3;
    pc(:, 4, 4) = (a3c - ac3) ./ D3;
    pc(:, 4, 5) = (-2 * b2c + 3 * abd + 3 * bcd - 2 * ad2) ./ D2;
    pc(:, 4, 6) = (abc - 3 * bc2 - 3 * a2d + acd) ./ D2;
    pc(:, 4, 7) = (a2c + ac2) ./ D2;
    pc(:, 4, 8) = 1;

    pc(:, 5, 1) = -(-2 * ab2d + b2cd + 2 * abd2 - 2 * bcd2 + ad3) ./ D3;
    pc(:, 5, 2) = -(2 * ab2c - b2c2 + 4 * a2bd - 6 * abcd + 4 * bc2d - 2 * a2d2 - acd2) ./ D3;
    pc(:, 5, 3) = -(-4 * a2bc + 4 * abc2 - 2 * bc3 - 2 * a3d + 5 * a2cd - ac2d) ./ D3;
    pc(:, 5, 4) = -(2 * a3c - 3 * a2c2 + ac3) ./ D3;
    pc(:, 5, 5) = -(2 * abd - bcd + ad2) ./ D2;
    pc(:, 5, 6) = (2 * abc - bc2 + 2 * a2d + acd) ./ D2;
    pc(:, 5, 7) = -2 * a2c ./ D2;

    pc(:, 6, 1) = (b3c - 2 * ab2d + 2 * b2cd + abd2 - 2 * bcd2) ./ D3;
    pc(:, 6, 2) = (-ab2c - 2 * b2c2 + 4 * a2bd - 6 * abcd + 4 * bc2d - a2d2 + 2 * acd2) ./ D3;
    pc(:, 6, 3) = -(a2bc - 5 * abc2+ 2 * bc3 + 2 * a3d - 4 * a2cd + 4 * ac2d) ./ D3;
    pc(:, 6, 4) = -(-a3c + 3 * a2c2 - 2 * ac3) ./ D3;
    pc(:, 6, 5) = -(b2c - abd + 2 * bcd) ./ D2;
    pc(:, 6, 6) = (abc + 2 * bc2 - a2d + 2 * acd) ./ D2;
    pc(:, 6, 7) = -2 * ac2 ./ D2;

    pc(:, 7, 1) = -(b3d - bd3) ./ D3;
    pc(:, 7, 2) = -(-2 * b3c - ab2d + 3 * b2cd - 3 * abd2 + bcd2 + 2 * ad3) ./ D3;
    pc(:, 7, 3) = -(4 * ab2c - 3 * b2c2 - a2bd + bc2d + 3 * a2d2 - 4 * acd2) ./ D3;
    pc(:, 7, 4) = -(-2 * a2bc + 3 * abc2 - bc3 + a3d - 3 * a2cd + 2 * ac2d) ./ D3;
    pc(:, 7, 5) = (b2d + bd2) ./ D2;
    pc(:, 7, 6) = (-3 * b2c + abd + bcd - 3 * ad2) ./ D2;
    pc(:, 7, 7) = (3 * abc - 2 * bc2 - 2 * a2d + 3 * acd) ./ D2;
    pc(:, 7, 9) = 1;

    pc(:, 8, 1) = - (-2 * b3d + 3 * b2d2 - bd3) ./ D3;
    pc(:, 8, 2) = -(2 * b3c + 4 * ab2d - 5 * b2cd - 4 * abd2 + bcd2 + 2 * ad3) ./ D3;
    pc(:, 8, 3) = -(-4 * ab2c + 2 * b2c2 - 2 * a2bd + 6 * abcd + bc2d + a2d2 - 4 * acd2) ./ D3;
    pc(:, 8, 4) = -(2 * a2bc - 2 * abc2 - bc3 - a2cd + 2 * ac2d) ./ D3;
    pc(:, 8, 5) = -2 * b2d ./ D2;
    pc(:, 8, 6) = (2 * b2c + 2 * abd + bcd - ad2) ./ D2;
    pc(:, 8, 7) = -(2 * abc + bc2 - acd) ./ D2;
    
    pc(:, 9, 1) = (-b3d + 3 * b2d2 - 2 * bd3) ./ D3;
    pc(:, 9, 2) = (2 * b3c + ab2d - 4 * b2cd - 5 * abd2 + 4 * bcd2 + 2 * ad3) ./ D3;
    pc(:, 9, 3) = (-4 * ab2c + b2c2 + a2bd + 6 * abcd - 2 * bc2d + 2 * a2d2 - 4 * acd2)  ./ D3;
    pc(:, 9, 4) = -(-2 * a2bc + abc2 + a3d + 2 * a2cd - 2 * ac2d) ./ D3;
    pc(:, 9, 5) = -2 * bd2 ./ D2;
    pc(:, 9, 6) = (-b2c + abd + 2 * bcd + 2 * ad2) ./ D2;
    pc(:, 9, 7) = -(-abc + a2d + 2 * acd) ./ D2;

    pc(:, 10, 1) = 27 * (b2d - bd2) ./ D3;
    pc(:, 10, 2) = -27 * (b2c + 2 * abd - 2 * bcd - ad2) ./ D3;
    pc(:, 10, 3) = -27 * (-2 * abc + bc2 - a2d + 2 * acd) ./ D3;
    pc(:, 10, 4) = -27 * (a2c - ac2) ./ D3;
    pc(:, 10, 5) = -27 * bd ./ D2;
    pc(:, 10, 6) = 27 * (bc + ad) ./ D2;
    pc(:, 10, 7) = -27 * ac ./ D2;

    clear a2 b2 c2 d2 ab ac ad bc bd cd;
    clear a3 b3 c3 d3 bcd acd abd abc;
    clear ab2 a2b ac2 a2c ad2 a2d bc2 b2c bd2 b2d cd2 c2d;
    clear a3c a3d a2bc a2bd a2c2 a2cd a2d2 ab2c ab2d abc2 abcd abd2;
    clear ac3 ac2d acd2 ad3 b3c b3d b2c2 b2cd b2d2 bc3 bc2d bcd2 bd3;
    clear D2 D3;
    if if_time
        toc;
    end

    %% Count integrate points and weights

    % 4 points in each element
    % for each point count x^3 x^2y xy^2 y^3 x^2 xy y^2 x y 1
    % vp(k, i, :) the value of things above at point i in Tk
    xs = [0.33333333, 0.45929259, 0.17056931, 0.05054723, 0.26311283, ...
        0.08141482, 0.45929259, 0.65886138, 0.17056931, 0.89890554, ...
        0.05054723, 0.72849239, 0.72849239, 0.00839478, 0.00839478, ...
        0.26311283];
    ys = [0.33333333, 0.45929259, 0.17056931, 0.05054723, 0.72849239, ...
        0.45929259, 0.08141482, 0.17056931, 0.65886138, 0.05054723, ...
        0.89890554, 0.26311283, 0.00839478, 0.26311283, 0.72849239, ...
        0.00839478];
    ws = [0.0721578 , 0.04754582, 0.05160869, 0.01622925, 0.01361516, ...
       0.04754582, 0.04754582, 0.05160869, 0.05160869, 0.01622925, ...
       0.01622925, 0.01361516, 0.01361516, 0.01361516, 0.01361516, ...
       0.01361516];
    pts = length(ws);

    vp = ones(M, pts, 10);
    vp(:, :, 8) = a * xs + c * ys;
    vp(:, :, 9) = b * xs + d * ys;
    
    vp(:, :, 7) = vp(:, :, 9) .^ 2;
    vp(:, :, 6) = vp(:, :, 8) .* vp(:, :, 9);
    vp(:, :, 5) = vp(:, :, 8) .^ 2;
    vp(:, :, 4) = vp(:, :, 7) .* vp(:, :, 9);
    vp(:, :, 3) = vp(:, :, 7) .* vp(:, :, 8);
    vp(:, :, 2) = vp(:, :, 5) .* vp(:, :, 9);
    vp(:, :, 1) = vp(:, :, 5) .* vp(:, :, 8);

    % w(k, i) the weight at point i in Tk
    w = -D * ws;

    clear a b c d;
    if if_time
        toc;
    end

    %% Generate A
    % count a0 with weight at each point
    A0w = zeros(M, pts);
    for i = 1:pts
        A0w(:, i) = a0(node(elem(:, 1), :) + reshape(vp(:, i, 8:9), [M, 2]));
    end
    A0w = A0w .* w;

    % count (pi)x, (pi)y at each point
    px = zeros(M, 10, pts);

    for i = 1:pts
        px(:, :, i) = 3 * pc(:, :, 1) .* vp(:, i, 5) ...
            + 2 * pc(:, :, 2) .* vp(:, i, 6) ...
            + pc(:, :, 3) .* vp(:, i, 7) ...
            + 2 * pc(:, :, 5) .* vp(:, i, 8) ...
            + pc(:, :, 6) .* vp(:, i, 9) ...
            + pc(:, :, 8) .* vp(:, i, 10);
    end

    py = zeros(M, 10, pts);

    for i = 1:pts
        py(:, :, i) = 3 * pc(:, :, 4) .* vp(:, i, 7) ...
            + 2 * pc(:, :, 3) .* vp(:, i, 6) ...
            + pc(:, :, 2) .* vp(:, i, 5) ...
            + 2 * pc(:, :, 7) .* vp(:, i, 9) ...
            + pc(:, :, 6) .* vp(:, i, 8) ...
            + pc(:, :, 9) .* vp(:, i, 10);
    end

    % count and accum
    A = sparse(Z, Z);

    for i = 1:3
        for j = 1:3
            Tij = px(:, i, :) .* px(:, j, :) + py(:, i, :) .* py(:, j, :);
            Aij = sum(reshape(Tij, [M, pts]) .* A0w, 2);
            A = A + sparse(elem(:, i), elem(:, j), Aij, Z, Z);
        end
    end
    for i = 1:3
        for j = 1:3
            Tij = px(:, i, :) .* px(:, j + 3, :) + py(:, i, :) .* py(:, j + 3, :);
            Aij = sum(reshape(Tij, [M, pts]) .* A0w, 2);
            A = A + sparse(elem(:, i), elem(:, j) + N, Aij, Z, Z);
        end
    end
    for i = 1:3
        for j = 1:3
            Tij = px(:, i, :) .* px(:, j + 6, :) + py(:, i, :) .* py(:, j + 6, :);
            Aij = sum(reshape(Tij, [M, pts]) .* A0w, 2);
            A = A + sparse(elem(:, i), elem(:, j) + 2 * N, Aij, Z, Z);
        end
    end
    for i = 1:3
        Tij = px(:, i, :) .* px(:, 10, :) + py(:, i, :) .* py(:, 10, :);
        Aij = sum(reshape(Tij, [M, pts]) .* A0w, 2);
        A = A + sparse(elem(:, i), 3*N+1:Z, Aij, Z, Z);
    end
    A(N+1:2*N, 1:N) = A(1:N, N+1:2*N)';
    for i = 1:3
        for j = 1:3
            Tij = px(:, i + 3, :) .* px(:, j + 3, :) + py(:, i + 3, :) .* py(:, j + 3, :);
            Aij = sum(reshape(Tij, [M, pts]) .* A0w, 2);
            A = A + sparse(elem(:, i) + N, elem(:, j) + N, Aij, Z, Z);
        end
    end
    for i = 1:3
        for j = 1:3
            Tij = px(:, i + 3, :) .* px(:, j + 6, :) + py(:, i + 3, :) .* py(:, j + 6, :);
            Aij = sum(reshape(Tij, [M, pts]) .* A0w, 2);
            A = A + sparse(elem(:, i) + N, elem(:, j) + 2 * N, Aij, Z, Z);
        end
    end
    for i = 1:3
        Tij = px(:, i + 3, :) .* px(:, 10, :) + py(:, i + 3, :) .* py(:, 10, :);
        Aij = sum(reshape(Tij, [M, pts]) .* A0w, 2);
        A = A + sparse(elem(:, i) + N, 3*N+1:Z, Aij, Z, Z);
    end
    A(2*N+1:3*N, 1:2*N) = A(1:2*N, 2*N+1:3*N)';
    for i = 1:3
        for j = 1:3
            Tij = px(:, i + 6, :) .* px(:, j + 6, :) + py(:, i + 6, :) .* py(:, j + 6, :);
            Aij = sum(reshape(Tij, [M, pts]) .* A0w, 2);
            A = A + sparse(elem(:, i) + 2 * N, elem(:, j) + 2 * N, Aij, Z, Z);
        end
    end
    for i = 1:3
        Tij = px(:, i + 6, :) .* px(:, 10, :) + py(:, i + 6, :) .* py(:, 10, :);
        Aij = sum(reshape(Tij, [M, pts]) .* A0w, 2);
        A = A + sparse(elem(:, i) + 2 * N, 3*N+1:Z, Aij, Z, Z);
    end
    A(3*N+1:Z, 1:3*N) = A(1:3*N, 3*N+1:Z)';
    Tij = px(:, 10, :) .* px(:, 10, :) + py(:, 10, :) .* py(:, 10, :);
    Aij = sum(reshape(Tij, [M, pts]) .* A0w, 2);
    A(3*N+1:Z, 3*N+1:Z) = sparse(1:M, 1:M, Aij);
    
    clear Tij Aij A0w px py a0 j;
    if if_time
        toc;
    end

    %% Generate r
    r = zeros(Z, 1);

    % count f with weight at each point
    Fw = zeros(M, pts);
    for i = 1:pts
        Fw(:, i) = f(node(elem(:, 1), :) + reshape(vp(:, i, 8:9), [M, 2]));
    end
    Fw = Fw .* w;

    % count pi, at each point
    p = zeros(M, 10, pts);

    for i = 1:pts
        p(:, :, i) = p(:, :, i) + sum(pc(:, :, :) .* vp(:, i, :), 3);
    end
    
    for i = 1:3
        Fi = sum(reshape(p(:, i, :), [M, pts]) .* Fw, 2);
        r(1:N) = r(1:N) + accumarray(elem(:, i), Fi, [N, 1]);
    end
    for i = 1:3
        Fi = sum(reshape(p(:, i + 3, :), [M, pts]) .* Fw, 2);
        r(N+1:2*N) = r(N+1:2*N) + accumarray(elem(:, i), Fi, [N, 1]);
    end
    for i = 1:3
        Fi = sum(reshape(p(:, i + 6, :), [M, pts]) .* Fw, 2);
        r(2*N+1:3*N) = r(2*N+1:3*N) + accumarray(elem(:, i), Fi, [N, 1]);
    end
    Fi = sum(reshape(p(:, 10, :), [M, pts]) .* Fw, 2);
    r(3*N+1:Z) = Fi;

    clear Fi Fw p vp w pc M f;
    if if_time
        toc;
    end
    
    %% Dirichlet Boundary condition
    u = zeros(Z, 1);

    Boundary = findboundary(elem);
    u(Boundary) = g(node(Boundary, :));

    freenode = true(Z, 1);
    freenode(Boundary) = false;
    
    if if_s
        for i = Boundary'
            if (node(i, 1) == 1 || node(i, 1) == -1 || ...
                    (node(i, 1) == 0 && node(i, 2) < 0))
                freenode(i + 2 * N) = false;
                u(i + 2 * N) = gy(node(i, :));
            end
             if (node(i, 2) == 1 || node(i, 2) == -1 || ...
                     (node(i, 2) == 0 && node(i, 1) > 0))
                freenode(i + N) = false;
                u(i + N) = gx(node(i, :));
            end
        end
    else
        for i = Boundary'
            if (node(i, 1) == 1 || node(i, 1) == -1 || ...
                    (node(i, 1) == 0 && node(i, 2) <= 0))
                freenode(i + 2 * N) = false;
                u(i + 2 * N) = gy(node(i, :));
            end
             if (node(i, 2) == 1 || node(i, 2) == -1 || ...
                     (node(i, 2) == 0 && node(i, 1) >= 0))
                freenode(i + N) = false;
                u(i + N) = gx(node(i, :));
            end
        end
    end

    r = r - A * u;
    
    clear elem node Boundary g Z;
    if if_time
        toc;
    end

    %% solve
    
    u(freenode) = A(freenode, freenode) \ r(freenode);

    if if_time
        toc;
    end
end