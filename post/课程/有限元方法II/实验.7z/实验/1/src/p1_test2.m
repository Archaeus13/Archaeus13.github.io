clear;
a0 = @(x) 1 + 0.5 * sin(pi * x(:, 1));
f = @(x) -pi * x(:, 1) .* cos(pi * x(:, 1)) - 4 - 2 * sin(pi * x(:, 1));
exact_u = @(x) x(:, 1) .^ 2 + x(:, 2) .^ 2;
eux = @(x) 2 * x(:, 1);
euy = @(x) 2 * x(:, 2);
[node, elem] = squaremesh([-1, 1, -1, 1], 0.5);
T = 8;
l2 = zeros(1, T);
li = zeros(1, T);
h1 = zeros(1, T);
w1i = zeros(1, T);
for i = 1:T
    if i == T
        res = poisson_square(node, elem, a0, f, exact_u, eux, euy, 1);
    else
        res = poisson_square(node, elem, a0, f, exact_u, eux, euy, 0);
    end
    N = size(node, 1);
    M = size(elem, 1);
    err1 = res(1:N) - exact_u(node);
    err2 = res(N+1:2*N) - eux(node);
    err3 = res(2*N+1:3*N) - euy(node);
    err4 = res(3*N+1:end) - exact_u((node(elem(:, 1), :) + ...
        node(elem(:, 2), :) + node(elem(:, 3), :)) / 3);
    l2(i) = 2 * sqrt((sum(err1 .^ 2) + sum(err4 .^ 2)) / (M + N));
    li(i) = max(max(abs(err1)), max(abs(err4)));
    h1(i) = sqrt(l2(i) ^ 2 + 4 * (sum(err2 .^ 2) + sum(err3 .^ 2)) / N);
    w1i(i) = max([li(i), max(abs(err2)), max(abs(err3))]);
    [node, elem] = uniformrefine(node, elem);
end
figure;
plot(1:T, log(l2)/log(2), LineWidth=1.5);
hold on;
plot(1:T, log(li)/log(2), LineWidth=1.5);
plot(1:T, log(h1)/log(2), LineWidth=1.5);
plot(1:T, log(w1i)/log(2), LineWidth=1.5);
ylabel("log_2(error)");
xlabel("-log_2(h)");
legend(["L^2", "L^\infty", "H^1", "W^1_\infty"]);