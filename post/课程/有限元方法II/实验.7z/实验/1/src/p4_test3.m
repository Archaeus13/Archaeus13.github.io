clear;
a0 = @(x) 1 + sin(x(:, 1) .* x(:, 2)) / 2;
a0x = @(x) x(:, 2) .* cos(x(:, 1) .* x(:, 2)) / 2;
a0y = @(x) x(:, 1) .* cos(x(:, 1) .* x(:, 2)) / 2;
f = @(x) 1 + 0 * x(:, 1);
z = @(x) 0 * x(:, 1);
T = 40;
l2 = zeros(1, T);
li = zeros(1, T);
h1 = zeros(1, T);
ALL = zeros(1, T);

node = [-1, -1; -1, 0; -1, 1; 0, -1; 0, 0; 0, 1; 1, 0; 1, 1];
elem = [1, 4, 5; 5, 2, 1; 2, 5, 6; 6, 3, 2; 5, 7, 8; 8, 6, 5];
[node, elem] = uniformrefine(node, elem);

for i = 1:T
    [res, E2, S, mkd] = poisson_L_E(node, elem, a0, a0x, a0y, f, z, z, z, 0, 0, 0.7);
    [node, elem] = bisect(node, elem, mkd);
end
fin_res = poisson_L_E(node, elem, a0, a0x, a0y, f, z, z, z, 1, 0, 0.7);
fin_N = size(node, 1);

node = [-1, -1; -1, 0; -1, 1; 0, -1; 0, 0; 0, 1; 1, 0; 1, 1];
elem = [1, 4, 5; 5, 2, 1; 2, 5, 6; 6, 3, 2; 5, 7, 8; 8, 6, 5];
[node, elem] = uniformrefine(node, elem);
for i = 1:T
    [res, E2, S, mkd] = poisson_L_E(node, elem, a0, a0x, a0y, f, z, z, z, 0, 0, 0.7);
    N = size(node, 1);
    err1 = res(1:N) - fin_res(1:N);
    err2 = res(N+1:2*N) - fin_res(fin_N + (1:N));
    err3 = res(2*N+1:3*N) - fin_res(fin_N * 2 + (1:N));
    % disp(res(N + 2));
    l2(i) = sqrt(sum( (err1(elem(:, 1)) .^ 2 + err1(elem(:, 2)) .^ 2 + ...
        err1(elem(:, 3)) .^ 2 ) / 3 .* S));
    li(i) = max(abs(err1));
    h1(i) = sqrt(l2(i) .^ 2 + ...
        sum((err2(elem(:, 1)) .^ 2 + err2(elem(:, 2)) .^ 2 + ...
        err2(elem(:, 3)) .^ 2 + err3(elem(:, 1)) .^ 2 + ...
        err3(elem(:, 2)) .^ 2 + err3(elem(:, 3)) .^ 2) / 3 ...
        .* S));
    ALL(i) = sqrt(sum(E2));
    [node, elem] = bisect(node, elem, mkd);
end
% disp(fin_res(fin_N + 2));
figure;
showmesh(node, elem);
figure;
plot(1:T, log(l2)/log(2), LineWidth=1.5);
hold on;
plot(1:T, log(li)/log(2), LineWidth=1.5);
plot(1:T, log(h1)/log(2), LineWidth=1.5);
plot(1:T, log(ALL)/log(2), LineWidth=1.5);
ylabel("log_2(error)");
xlabel("times");
legend(["L^2", "L^\infty", "H^1", "E"]);