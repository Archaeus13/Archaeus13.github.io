clear;
a0 = @(x) 1 + 0 * x(:, 1);
a0x = @(x) 0 * x(:, 1);
a0y = @(x) 0 * x(:, 1);
r2 = @(x) x(:, 1) .^ 2 + x(:, 2) .^ 2;
f = @(x) 20 / 3 * nthroot(r2(x), 3) .* sin(theta(x) * 2 / 3);
exact_u = @(x) (1 - r2(x)) .* nthroot(r2(x), 3).* sin(theta(x) * 2 / 3);
node = [-1, -1; -1, 0; -1, 1; 0, -1; 0, 0; 0, 1; 1, 0; 1, 1];
elem = [1, 4, 5; 5, 2, 1; 2, 5, 6; 6, 3, 2; 5, 7, 8; 8, 6, 5];
[node, elem] = uniformrefine(node, elem);
T = 50;
l2 = zeros(1, T);
li = zeros(1, T);
h1 = zeros(1, T);
ALL = zeros(1, T);

gx = @(x) eux(x);
gy = @(x) euy(x);
for i = 1:T
    if i == T
        [res, E2, S, mkd] = poisson_L_E(node, elem, a0, a0x, a0y, f, exact_u, gx, gy, 1, 0, 0.7);
    else
        [res, E2, S, mkd] = poisson_L_E(node, elem, a0, a0x, a0y, f, exact_u, gx, gy, 0, 0, 0.7);
    end
    N = size(node, 1);
    M = size(elem, 1);
    err1 = res(1:N) - exact_u(node);
    err2 = (res(N+1:2*N) - eux(node));
    err3 = (res(2*N+1:3*N) - euy(node));
    err4 = res(3*N+1:end) - exact_u((node(elem(:, 1), :) + ...
        node(elem(:, 2), :) + node(elem(:, 3), :)) / 3);
    l2(i) = sqrt(sum(err4 .^ 2 .* S));
    li(i) = max(max(abs(err1)), max(abs(err4)));
    h1(i) = sqrt(l2(i) .^ 2 + ...
        sum((err2(elem(:, 1)) .^ 2 + err2(elem(:, 2)) .^ 2 + ...
        err2(elem(:, 3)) .^ 2 + err3(elem(:, 1)) .^ 2 + ...
        err3(elem(:, 2)) .^ 2 + err3(elem(:, 3)) .^ 2) / 3 ...
        .* S));
    ALL(i) = sqrt(sum(E2));
    [node, elem] = bisect(node, elem, mkd);
end
figure;
showmesh(node, elem);
figure;
plot(1:T, log(l2)/log(2), LineWidth=1.5);
hold on;
plot(1:T, log(li)/log(2), LineWidth=1.5);
plot(1:T, log(h1)/log(2), LineWidth=1.5);
plot(1:T, log(ALL)/log(2), LineWidth=1.5);
ylabel("log_2(error)");
xlabel("times");
legend(["L^2", "L^\infty", "H^1", "E"]);

function t = theta(x)
    temp = x(:, 1) .^ 2 + x(:, 2) .^ 2;
    t = (x(:, 2) > 0 | (x(:, 2) == 0 & x(:, 1) >= 0)) .* ...
        acos(x(:, 1) ./ sqrt(temp)) ...
        + (x(:, 2) < 0 | (x(:, 2) == 0 & x(:, 1) < 0)) .* ...
        (2 * pi - acos(x(:, 1) ./ sqrt(temp)));
    t(temp == 0) = 0;
end
function res = eux(x)
    temp = x(:, 1) .^ 2 + x(:, 2) .^ 2;
    t = theta(x);
    res = -2 * (1 - temp + 3 * temp .* cos(t * 2 / 3) ...
    + 3 * temp .* cos(t * 4 / 3)) .* sin(t / 3) / 3 ...
    ./ nthroot(temp, 6);
    res(temp == 0) = 0;
end
function res = euy(x)
    temp = x(:, 1) .^ 2 + x(:, 2) .^ 2;
    t = theta(x);
    res = -2 * (-1 + temp + 3 * temp .* cos(t * 2 / 3) ...
    - 3 * temp .* cos(t * 4 / 3)) .* cos(t / 3) / 3 ...
    ./ nthroot(temp, 6);
    res(temp == 0) = 0;
end