文件夹src中的文件为本实验相关的代码。由于使用了 iFEM 包，需要先在 iFEM 所在的文件夹运行 setpath.m 以正常执行。

文件与功能介绍：
Hermite.nb			对 Hermite 单元的一组基进行计算（Mathematica笔记本）
Laplace.nb			对第二题中函数的相关导数进行计算（Mathematica笔记本）
p1_test1.m			第一题 对真解 sin(pi x)sin(pi y) 进行测试的脚本
p1_test2.m			第一题 对真解 x^2 + y^2 进行测试的脚本
p1_test3.m			第一题 对真解 sin(x + y) 进行测试的脚本
p2.m				第二题 对较奇异的解进行测试的脚本
p3_test1.m			第三题 对 a = 1 进行测试的脚本
p3_test2.m			第三题 对 a = 1 + 0.5sin(xy) 进行测试的脚本
p4_test1.m			第四题 对第二题情况进行测试的脚本
p4_test2.m			第四题 对第三题 a = 1 情况进行测试的脚本
p4_test3.m			第四题 对第三题 a = 1 + 0.5sin(xy) 情况进行测试的脚本
poisson_L.m			L 形区域的模拟 允许设置是否计时、是否以 0 为奇点（第二、三题）
poisson_L_E.m		L 形区域的模拟 在普通模拟的基础上增添误差估计与单元标记（第四题）
poisson_square.m		正方形区域的模拟 允许设置是否计时（第一题）