%
% ==========================================================================
%
%       Filename:  gen_data.m
%
%    Description:  
%
%        Version:  1.0
%        Created:  04/08/2023 09:17:32 PM
%       Revision:  none
%
%         Author:  Yiyang Liu, yiyeung_lau@pku.edu.cn
%   Organization:  BICMR, PKU
% 
% ==========================================================================
% 

% Read source image
source = imread('source.png');
fprintf('Source image size: %i x %i.\n', size(source, 1), size(source, 2));

% Read destination image
dest = imread('dest.png');
fprintf('Dest image size: %i x %i.\n', size(dest, 1), size(dest, 2));

% Reshape the source and dest into vector and normalize so that they both
% sum to 1
source = reshape(source, [], 1);
dest = reshape(dest, [], 1);

source = double(source) / sum(source);
dest = double(dest) / sum(dest);

% Make sure source and dest are valid probability distributions
assert(all(source >= 0));
assert(all(dest >= 0));
assert(abs(sum(source) - 1) < 1e-8 && abs(sum(dest) - 1) < 1e-8);
fprintf('Source and destination distributions generated.\n');

% Generate the squared Euclidean cost function C. The cost efficient 
% C_{i, j} between position i = (ix,iy) at the original source image and
% position j = (jx, jy) at the original destination image is defined as
% C_{i, j} = (ix - jx)^2 + (iy - jy)^2. 
% This code assumes that both images are square and have the same size. 
% Please modify the code accordingly if the data does not meet this 
% assumption.
sz = size(imread('source.png'), 1);
ii = repmat([0 : sz - 1]', sz, 1);
jj = repelem([0 : sz - 1]', sz, 1);
C = (ii - ii').^2 + (jj - jj').^2;
fprintf('Cost function generated.\n');

% Solve the optimal transportation problem (as a special case of LP) using 
% MATLAB's linprog.
c = reshape(C', [], 1);
m = sz^2;
n = sz^2;
i_pos = [repelem([1 : m]', n, 1); repmat([1 : n]' + m, m, 1)];
j_pos = [[1 : m * n]'; [1 : m * n]'];
Aeq = sparse(i_pos, j_pos, 1, m + n, m * n);
beq = [source; dest];
lb = zeros(m * n, 1);
ub = Inf(m * n, 1);
options = optimoptions('linprog');
options.Algorithm = 'interior-point-legacy'; % possible choices: 'dual-simplex',  'interior-point-legacy',  or 'interior-point'
options.Display = 'iter';
tol = 1e-6;
options.OptimalityTolerance = tol;
options.ConstraintTolerance = tol;

fprintf('\nSolving the LP using linprog ...\n\n');
t0 = tic;
[x, ~, ~, linprog_output, lambda] = linprog(c, [], [], Aeq, beq, lb, ub, options);
t1 = toc(t0);

linprog_output
fprintf('linprog time: %.1f seconds.\n', t1);
fprintf('Optimal transportation cost: %.8e.\n', c' * x);
fprintf('Dual objective value: %.8e.\n', beq' * -lambda.eqlin);
fprintf('Relative duality gap: %.2e.\n', abs(c' * x - beq' * -lambda.eqlin) / (1 + 0.5 * abs(c' * x) + 0.5 * (beq' * -lambda.eqlin)));
fprintf('Relative primal infeasibility: %.2e.\n', norm(Aeq * x - beq, inf) / (1 + norm(beq, inf)));
fprintf('Relative dual infeasibility: %.2e.\n', norm(Aeq' * -lambda.eqlin + lambda.lower - c, inf) / (1 + norm(c, inf)));






