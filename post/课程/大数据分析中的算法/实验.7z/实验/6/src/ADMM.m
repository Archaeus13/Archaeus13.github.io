function [x, val] = ADMM(A, b, c, t, l, max_iter, tol)
    % solve linear progamming
    % min (c'x) while Ax = b, x >= 0
    % val - optimal value
    % t, l - learning rate
    % max_iter, tol - determine the end of iteration
    tic;
    [~, n] = size(A);
    R = inv(A * A');
    temp = mean(b);
    b = b / temp;
    x = randn(n, 1);
    s = randn(n, 1);
    loss = zeros(int32(max_iter / 100), 1);
    rs = s - c;
    for i = 1:max_iter
        val = sum(c .* x);
        if mod(i, 100) == 0
            tt = val * temp;
            disp("iter: " + i + ", " + tt)
            loss(i/100) = tt;
        end
        rx = A * x - b;
        y = -R * (rx / t + A * rs);
        ry = A' * y;
        s = max(c - ry - x / t, 0);
        rs = s - c;
        x = x + l * t * (ry + rs);
        if abs(val - sum(b .* y)) < tol
            break
        end
    end
    disp("iters = " + i);
    val = val * temp;
    toc;
    loss = loss(1:floor(i/100));
    save loss loss;
end