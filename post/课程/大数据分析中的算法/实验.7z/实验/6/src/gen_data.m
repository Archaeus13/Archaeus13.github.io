% Read source image
source = imread('my_source.png');
fprintf('Source image size: %i x %i.\n', size(source, 1), size(source, 2));
sz = size(source, 1);

% Read destination image
dest = imread('my_dest.png');
fprintf('Dest image size: %i x %i.\n', size(dest, 1), size(dest, 2));

% Reshape the source and dest into vector and normalize so that they both
% sum to 1
source = reshape(source, [], 1);
dest = reshape(dest, [], 1);

source = double(source) / sum(source);
dest = double(dest) / sum(dest);

% Make sure source and dest are valid probability distributions
assert(all(source >= 0));
assert(all(dest >= 0));
assert(abs(sum(source) - 1) < 1e-8 && abs(sum(dest) - 1) < 1e-8);
fprintf('Source and destination distributions generated.\n');

% Generate the squared Euclidean cost function C. The cost efficient 
% C_{i, j} between position i = (ix,iy) at the original source image and
% position j = (jx, jy) at the original destination image is defined as
% C_{i, j} = (ix - jx)^2 + (iy - jy)^2. 
% This code assumes that both images are square and have the same size. 
% Please modify the code accordingly if the data does not meet this 
% assumption.
ii = repmat((0 : sz - 1)', sz, 1);
jj = repelem((0 : sz - 1)', sz, 1);
C = (ii - ii').^2 + (jj - jj').^2;
fprintf('Cost function generated.\n');

save temp source dest C;