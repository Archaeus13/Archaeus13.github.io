%% load data & log
clear;
load temp.mat;
m = length(source);
n = length(dest);

diary("log.txt");
diary on;

%% gurobi model
model.sense = '=';
i_pos = [repelem((1 : m)', n, 1); repmat((1 : n)' + m, m, 1)];
j_pos = [(1 : m * n)'; (1 : m * n)'];
model.A = sparse(i_pos, j_pos, 1, m + n, m * n);
model.rhs = [source; dest];
model.obj = reshape(C', [], 1);

% gurobi Simplex
params.method = 0; % primal simplex
result1 = gurobi(model, params);
disp('------------------------------------------------------------------');

params.method = 1; % dual simplex
result2 = gurobi(model, params);
disp('------------------------------------------------------------------');

% gurobi Interior
params.method = 2; % barrier
result3 = gurobi(model, params);
disp('------------------------------------------------------------------');

%% mosek model
B = sparse(i_pos, j_pos, 1, m + n, m * n);
c = [source; dest];
f = reshape(C', [], 1);

% mosek Simplex
opt.Simplex = 'primal';
opt.Display = "iter";
[result4.x, result4.opt, ~, ~, result4.L] ...
    = linprog(f, [], [], B, c, 0 .* f, Inf .* f, [], opt);
disp('------------------------------------------------------------------');
opt.Simplex = 'dual';
opt.Display = "iter";
[result5.x, result5.opt, ~, ~, result5.L] ...
    = linprog(f, [], [], B, c, 0 .* f, Inf .* f, [], opt);
disp('------------------------------------------------------------------');

% mosek Interior-point
opt.Simplex = '';
opt.Display = "iter";
[result6.x, result6.opt, ~, ~, result6.L] ...
    = linprog(f, [], [], B, c, 0 .* f, Inf .* f, [], opt);
disp('------------------------------------------------------------------');

%% test optimal condition
if min(result1.rc) >= 0
    disp("result 1 optimal");
end
if min(result2.rc) >= 0
    disp("result 2 optimal");
end
if min(result3.rc) >= 0
    disp("result 3 optimal");
end
disp("result 4 dual gap: " + (result4.opt + sum(result4.L.eqlin .* c)));
disp("result 5 dual gap: " + (result5.opt + sum(result5.L.eqlin .* c)));
disp("result 6 dual gap: " + (result6.opt + sum(result6.L.eqlin .* c)));
disp('------------------------------------------------------------------');

diary off;