function [P, val] = sinkhorn(source, dest, C, eps, max_iter, tol)
    % solve regularized optimal transport
    % min (<P, C>- eps * H(P)) while P in U(source, dest)
    % val - optimal value
    % max_iter, tol - determine the end of iteration
    tic;
    u = ones(length(source), 1);
    K = exp(- C / eps);
    hK = diag(1 ./ source) * K;
    % loss = zeros(max_iter/10, 1);
    for i = 1:max_iter
        % if mod(i, 10) == 0
            % P = diag(u) * K * diag(v);
            % loss(i/10) = sum(sum(P .* C));
        % end
        u_old = u;
        v = dest ./ (K' * u);
        u = 1 ./ (hK * v);
        if max(abs(u_old - u)) < tol
            break
        end
    end
    disp("iters = " + i);
    % loss = loss(1:floor(i/10));
    P = diag(u) * K * diag(v);
    val = sum(sum(P .* C));
    % save losss loss;
    toc;
end