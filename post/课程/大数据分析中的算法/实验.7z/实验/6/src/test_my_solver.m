%% load data
clear;
load temp.mat;

%% Sinkhorn

[P, v0] = sinkhorn(source, dest, C, 1, 1000000, 1e-6);
% save sinkhorn P v0;

%% ADMM

% source = [2;2;3];
% dest = [2;3;2];
% C = [3,2,3;1,3,1;2,1,1];
m = length(source);
n = length(dest);
i_pos = [repelem((1 : m)', n, 1); repmat((1 : n)' + m, m, 1)];
j_pos = [(1 : m * n)'; (1 : m * n)'];
A = sparse(i_pos, j_pos, 1, m + n, m * n);
A = A(1:end-1, :);
rhs = [source; dest(1:end-1)];
obj = reshape(C', [], 1);
[x, v] = ADMM(A, rhs, obj, 0.1, 0.1, 200000, 1e-6);
save ADMM x v;