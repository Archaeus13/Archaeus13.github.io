
tt = [1, 1, 1];

rng(1);

%% 1D Gaussian

if tt(1)
    n = 128;
    z = randn(n,1) + 1i*randn(n,1);
    
    m = round(4.5*n);                     
    A = 1/sqrt(2)*randn(m,n) + 1i/sqrt(2)*randn(m,n);
    y = abs(A*z) .^ 2;

    opts.rho = 1;
    opts.tau = 1;
    opts.iter = 1000;
    
    tic;
    ADMM(A, y, opts, z);
    toc;

    opts.mu = @(t) min(1 - exp(-t/330), 0.2);
    opts.iter = 13000;
    opts.npower_iter = 50;
    opts.draw_loss = true;

    tic;
    gd(A, y, opts, z);
    toc;
end

%% 1D CDP

if tt(2)
    n = 128;
    x = randn(n,1) + 1i*randn(n,1);
    
    %% Make masks and linear sampling operators
    
    L = 6;                   % Number of masks  
    
    % Sample phases: each symbol in alphabet {1, -1, i , -i} has equal prob. 
    Masks = randi(4, n, L);
    Masks(Masks == 2) = -1;
    Masks(Masks == 3) = 1i;
    Masks(Masks == 4) = -1i;
    
    % Sample magnitudes and make masks 
    temp = rand(size(Masks));
    Masks = Masks .* ( (temp <= 0.2)*sqrt(3) + (temp > 0.2)/sqrt(2) );
    
    % Make linear operators; A is forward map and At its scaled adjoint (At(Y)*numel(Y) is the adjoint) 
    A = @(I)  fft(conj(Masks) .* repmat(I,[1 L]));  % Input is n x 1 signal, output is n x L array
    At = @(Y) mean(Masks .* ifft(Y), 2);            % Input is n x L array, output is n x 1 signal          
    
    % Data 
    Y = abs(A(x)).^2;

    opts.mu = @(t) min(1 - exp(-t/330), 0.2);
    opts.iter = 7000;
    opts.npower_iter = 50;
    opts.draw_loss = true;
    gd(A, Y, opts, x, At);
end

%%  Read Image

if tt(3)
    % Below X is n1 x n2 x 3; i.e. we have three n1 x n2 images, one for each of the 3 color channels  
    X       = rgb2gray(imread('ngc6543a.jpg')) ;
    figure();
    subplot(2, 3, 1);
    imshow(X);
    title("original");
    X = double(X);
    n1      = size(X,1)                        ;
    n2      = size(X,2)                        ;
    
    %% Make masks and linear sampling operators  
    
    % Each mask has iid entries following the octanary pattern in which the entries are 
    % distributed as b1 x b2 where 
    % b1 is uniform over {1, -1, i, -i} (phase) 
    % b2 is equal to 1/sqrt(2) with prob. 4/5 and sqrt(3) with prob. 1/5 (magnitude)
    
    L = 21;                  % Number of masks  
    Masks = zeros(n1,n2,L);  % Storage for L masks, each of dim n1 x n2
    
    % Sample phases: each symbol in alphabet {1, -1, i , -i} has equal prob. 
    for ll = 1:L
        Mask = randi(4, n1, n2);
        Mask(Mask == 2) = -1;
        Mask(Mask == 3) = 1i;
        Mask(Mask == 4) = -1i;
        Masks(:, :, ll) = Mask;
    end
    
    % Sample magnitudes and make masks 
    temp = rand(size(Masks));
    Masks = Masks .* ( (temp <= 0.2)*sqrt(3) + (temp > 0.2)/sqrt(2) );
    
    % Make linear operators; 
    A = @(I)  fft2(conj(Masks) .* reshape(repmat(I,[1 L]), size(I,1), size(I,2), L));  % Input is n1 x n2 image, output is n1 x n2 x L array
    At = @(Y) sum(Masks .* ifft2(Y), 3) * size(Y,1) * size(Y,2);                       % Input is n1 x n2 x L array, output is n1 x n2 image
    
    % Data 
    Y = abs(A(X)).^2;

    opts.mu = @(t) min(1 - exp(-t/330), 0.2);
    opts.npower_iter = 30;
    opts.draw_loss = false;
    opts.inter = 300;
    opts.iter = 5 * opts.inter;
    
    res = gd(A, Y, opts, X, At);
end