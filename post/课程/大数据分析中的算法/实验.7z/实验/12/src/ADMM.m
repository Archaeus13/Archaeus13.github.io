function res = ADMM(A, y, opts, z)
    rho = opts.rho;
    tau = opts.tau;
    iter = opts.iter;
    loss = zeros(iter, 1);

    m = size(A, 1);

    [L0, U0] = lu(A' * A);

    M = diag(sqrt(y)) * (eye(m) - A * (U0 \ (L0 \ A'))) * diag(sqrt(y));
    M2r = 2 * M + rho * eye(m);
    [L, U] = lu(M2r);
    
    lam = zeros(m, 1);
    phi = ones(m, 1);

    z_n = abs(z(1)) * z / z(1);
    for j = 1:iter
        u = U \ (L \ (rho * phi - lam));
        phi = u + lam / rho;
        phi(phi == 0) = 1;
        phi = phi ./ abs(phi);   
        lam = lam + rho * tau * (u - phi);

        res = U0 \ (L0 \ (A' * (sqrt(y) .* u)));
        loss(j) = norm(abs(res(1)) * res / res(1) - z_n);
    end
    
    figure();
    plot(loss, LineWidth=1.5);
end