function res = gd(A, y, opts, z, At)
    if ~exist("At", "var")
        At = @(x) (A' * x) / size(A, 1);
        A = @(x) A * x;
    end
    
    flag = opts.draw_loss;

    % estimate eigen vector
    npower_iter = opts.npower_iter;
    z0 = randn(size(z)); z0 = z0 / norm(z0);
    for tt = 1:npower_iter
        z0 = At(y .* A(z0)); z0 = z0 / norm(z0);
    end
    
    normest = sqrt(sum(y, "all") / numel(y)); 
    res = normest * z0;

    mu = opts.mu;
    iter = opts.iter;

    if flag
        loss = zeros(iter, 1);
        z_n = abs(z(1, 1)) * z / z(1, 1);
    end
    
    sy = sqrt(y);

    for j = 1:iter
        Az = A(res);
        temp = sign(abs(Az) - sy) .* Az;
        grad = At(temp);
        res = res - mu(j) / normest ^ 2 * grad;
        res = abs(res(1, 1)) * res / res(1, 1);
        if flag
            loss(j) = norm(res - z_n);
        else
            if ~mod(j, opts.inter)
                subplot(2, 3, 1 + j / opts.inter);
                imshow(uint8(abs(res)));
                title("iter = " + j);
            end
        end
    end

    if flag 
        figure();
        plot(loss, LineWidth=1.5);
    end
end