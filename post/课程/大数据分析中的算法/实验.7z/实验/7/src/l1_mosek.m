function [x, out] = l1_mosek(x0, A, b, mu, opts)
    n = size(A, 2);

    % define question
    H = sparse(2 * n, 2 * n);
    H(n+1:2*n, n+1:2*n) = A' * A;
    f = [mu * ones(n , 1); -A' * b];
    
    % define constraints
    A0 = sparse([1:2*n, 1:2*n],[1:n, 1:n, n+1:2*n, n+1:2*n], ...
        [-ones(1, 3 * n), ones(1, n)]);
    b0 = zeros(2*n, 1);

    % define initialization
    x0 = [abs(x0); x0];

    [xl, res] = ...
        quadprog(H, f, A0, b0, [], [], ...
        -Inf * ones(2*n, 1), Inf * ones(2*n, 1), x0, opts);
    
    x = xl(n+1:2*n);
    out.z = xl(1:n);
    out.result_worse = res + b' * b / 2;
end