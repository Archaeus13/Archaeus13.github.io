function [X, out] = n_prox(m, n, Omega, M, mu, opts)
    tau = opts.tau;
    tol = opts.tol;
    max_iter = opts.max_iter;
    out.loss = zeros(max_iter, 1);

    [Om, Mm] = form_matrix(m, n, Omega, M);
    X = Mm;
    
    if ~opts.if_acc % normal ISTA
        for i = 1:max_iter
            out.loss(i) = resfun(X, mu, Mm, Om);
            Xh = X - 2 * tau * (X - Mm) .* Om;
            X = Sm(Xh, mu * tau);
            if i > 1 && out.loss(i-1) - out.loss(i) < tol ...
                    && out.loss(i-1) - out.loss(i) >= 0
                out.iter = i;
                out.loss = out.loss(1 : i);
                out.opt = resfun(X, mu, Mm, Om);
                return;
            end
        end
        out.iter = max_iter;
        out.opt = resfun(X, mu, Mm, Om);
    else % Fast ISTA
        gamma = 1;
        Y = X;
        for i = 1:max_iter
           out.loss(i) = resfun(X, mu, Mm, Om);
           Xh = Y - 2 * tau * (Y - Mm) .* Om;
           Xold = X;
           X = Sm(Xh, mu * tau);
           if i > 1 && out.loss(i-1) - out.loss(i) < tol ...
                   && out.loss(i-1) - out.loss(i) >= 0
               out.iter = i;
               out.loss = out.loss(1 : i);
               out.opt = resfun(X, mu, Mm, Om);
               return;
           end
           gamma_new = (1 + sqrt(1 + 4 * gamma^2)) / 2;
           Y = X + (gamma - 1) / gamma_new * (X - Xold);
           gamma = gamma_new;
       end
       out.iter = max_iter;
       out.opt = resfun(X, mu, Mm, Om);
    end
end

function [Om, Mm] = form_matrix(m, n, Omega, M)
    Om = zeros(m, n, 'logical');
    Mm = zeros(m, n);
    for t = 1:size(Omega, 2)
        k = Omega(t);
        j = mod(k - 1, n) + 1;
        i = (k - j) / n + 1;
        Om(i, j) = 1;
        Mm(i, j) = M(t);
    end
end

function res = Sm(X, p)
    [U, S, V] = svd(X);
    S = shrink(S, p);
    res = U * S * V';
end

function res = shrink(vec, p)
    if p < 0
        res = "Error";
        return;
    end
    res = (abs(vec) > p) .* (vec - p * sign(vec));
end

function res = resfun(X, mu, Mm, Om)
    S = svd(X);
    res = mu * sum(sum(S));
    res = res + norm((X - Mm) .* Om, "fro") ^2;
end
