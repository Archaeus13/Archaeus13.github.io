% min mu*||x||_1 + ||Ax-b||_2^2/2
close all;
clear;

% generate data
n = 1024;
m = 512;

% set seed and testlist for debugging
rng(1);
if_test = [1, 1, 1, 1, 1];

% initialize
A = randn(m,n);
u = sprandn(n,1,0.1);
b = A * u;
mu = 1e-2;

x0 = rand(n,1);

errfun = @(x1, x2) norm(x1-x2)/(1+norm(x1));
resfun = @(x) norm(A*x-b) ^ 2 / 2 + mu * norm(x, 1);

real = Inf;

if if_test(1)
    % call gurobi directly
    opts1 = []; % solver options
    tic;
    [x1, out1] = l1_gurobi(x0, A, b, mu, opts1);
    t1 = toc;
    real = resfun(x1);
end

if if_test(2)
    % call mosek directly
    opts2 = []; % solver options
    tic;
    [x2, out2] = l1_mosek(x0, A, b, mu, opts2);
    t2 = toc;
    real = min(real, resfun(x2));
end

if if_test(3)
    % proximal gradient
    opts3.tau = 3e-4; % step length
    opts3.tol = 1e-6; % tolerance to end iter
    opts3.max_iter = 10000; % max iters
    opts3.if_acc = 1; % if accelerate
    tic; 
    [x3, out3] = l1_prox(x0, A, b, mu, opts3);
    t3 = toc;
    figure();
    real = min(real, resfun(x3));
    plot(log(abs(out3.loss - real))/log(10), linewidth=1.5);
    xlabel("iter");
    ylabel("log10(loss)");
end

if if_test(4)
    % ADMM
    opts4.rho = 0.8; % Lagrange coefficient
    opts4.tau = 1.2; % step length
    opts4.tol = 1e-7; % tolerance to end iter
    opts4.max_iter = 10000; % max iters
    tic;
    [x4, out4] = l1_ADMM(x0, A, b, mu, opts4);
    t4 = toc;
    figure();
    real = min(real, resfun(x4));
    plot(log(abs(out4.loss - real))/log(10), linewidth=1.5);
    hold on;
    plot(log(abs(out4.dual_gap))/log(10), linewidth=1.5);
    legend('result err', 'dual gap');
    xlabel("iter");
    ylabel("log10(loss)");
end

if if_test(5)
    % PDHG
    opts5.delta = 0.03; % step length
    opts5.alpha = 0.02; % step length
    opts5.tol = 1e-6; % tolerance to end iter
    opts5.max_iter = 10000; % max iters
    tic;
    [x5, out5] = l1_PDHG(x0, A, b, mu, opts5);
    t5 = toc;
    figure();
    real = min(real, resfun(x5));
    plot(log(abs(out5.loss - real))/log(10), linewidth=1.5);
    xlabel("iter");
    ylabel("log10(loss)");
end


% print comparison results with cvx-call-mosek
if if_test(1)
    fprintf('call-gurobi: res: %8.7e, nrm1: %8.7e, cpu: %5.2f\n', ...
            resfun(x1), norm(x1, 1), t1);
end
if if_test(2)
    fprintf('call-mosek:  res: %8.7e, nrm1: %8.7e, cpu: %5.2f\n', ...
        resfun(x2), norm(x2, 1), t2);
    if if_test(1)
        fprintf('       err-to-gurobi: %4.3e\n', errfun(x1, x2));
    end
end
if if_test(3)
    fprintf('prox-grad:   res: %8.7e, nrm1: %8.7e, cpu: %5.2f\n', ...
        resfun(x3), norm(x3, 1), t3);
    if if_test(1)
        fprintf('       err-to-gurobi: %4.3e\n', errfun(x1, x3));
    end
end
if if_test(4)
    fprintf('ADMM:        res: %8.7e, nrm1: %8.7e, cpu: %5.2f\n', ...
        resfun(x4), norm(x4, 1), t4);
    if if_test(1)
        fprintf('       err-to-gurobi: %4.3e\n', errfun(x1, x4));
    end
end
if if_test(5)
    fprintf('PDHG:        res: %8.7e, nrm1: %8.7e, cpu: %5.2f\n', ...
        resfun(x5), norm(x5, 1), t5);
    if if_test(1)
        fprintf('       err-to-gurobi: %4.3e\n', errfun(x1, x5));
    end
end