function [x, out] = l1_gurobi(x0, A, b, mu, opts)
    n = size(A, 2);

    % define question
    Q = sparse(2 * n, 2 * n);
    Q(n+1:2*n, n+1:2*n) = A' * A / 2;
    model.Q = Q;

    model.obj = [mu * ones(n , 1); -A' * b];

    model.objcon = b' * b / 2;

    % define constraints
    model.lb = -Inf * ones(2 * n, 1);
    model.sense = '>';
    model.A = sparse([1:2*n, 1:2*n],[1:n, 1:n, n+1:2*n, n+1:2*n], ...
        [ones(1, 3 * n), -ones(1, n)]);

    % define initialization
    model.start = [abs(x0); x0];

    result = gurobi(model, opts);
    
    x = result.x(n+1:2*n);
    out.z = result.x(1:n);
    out.result_worse = result.objval;
end