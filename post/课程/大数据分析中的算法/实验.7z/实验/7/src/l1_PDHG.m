function [x, out] = l1_PDHG(x0, A, b, mu, opts)
    delta = opts.delta;
    alpha = opts.alpha;
    tol = opts.tol;
    max_iter = opts.max_iter;

    out.loss = zeros(max_iter, 1);
    x = x0;
    z = b;

    for i = 1:max_iter
        r = A * x - b;
        out.loss(i) = norm(r) ^ 2 / 2 + mu * norm(x, 1);
        z = (delta * r + z) / (delta + 1);
        xold = x;
        x = shrink(x - alpha * (A' * z), alpha * mu);
        if norm(xold - x,1) < tol
            out.iter = i;
            out.loss = out.loss(1 : i);
            return;
        end
    end
    out.iter = max_iter;    
end

function res = shrink(vec, p)
    if p < 0
        res = "Error";
        return;
    end
    res = (abs(vec) > p) .* (vec - p * sign(vec));
end