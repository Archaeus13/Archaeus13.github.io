function [x, out] = l1_prox(x0, A, b, mu, opts)
    tau = opts.tau;
    tol = opts.tol;
    max_iter = opts.max_iter;
    out.loss = zeros(max_iter, 1);
    if ~opts.if_acc % normal ISTA
        xold = x0;
        for i = 1:max_iter
            r = A * xold - b;
            out.loss(i) = sum(r .^ 2) / 2 + mu * norm(xold, 1);
            x = shrink(xold - tau * (A' * r), tau * mu);
            if norm(xold - x, 1) < tol
                out.iter = i;
                out.loss = out.loss(1 : i);
                return;
            end
            xold = x;
        end
        out.iter = max_iter;
    else % Fast ISTA
        gamma = 1;
        y = x0;
        xold = x0;
        for i = 1:max_iter
            r = A * y - b;
            out.loss(i) = sum(r .^ 2) / 2 + mu * norm(y, 1);
            x = shrink(y - tau * (A' * r), tau * mu);
            if norm(xold - x, 1) < tol
                out.iter = i;
                out.loss = out.loss(1 : i);
                return;
            end
            gamma_new = (1 + sqrt(1 + 4 * gamma^2)) / 2;
            y = x + (gamma - 1) / gamma_new * (x - xold);
            xold = x;
            gamma = gamma_new;
        end
        out.iter = max_iter;
    end
end

function res = shrink(vec, p)
    if p < 0
        res = "Error";
        return;
    end
    res = (abs(vec) > p) .* (vec - p * sign(vec));
end