function [X, out] = n_ADMM(m, n, Omega, M, mu, opts)
    rho = opts.rho;
    tau = opts.tau;
    tol = opts.tol;
    max_iter = opts.max_iter;
    out.loss = zeros(max_iter, 1);

    [Om, Mm] = form_matrix(m, n, Omega, M);
    Z = Mm;
    Y = zeros(m, n);

    Rp2 = rho * ones(m, n) + 2 * Om;

    for i = 1:max_iter
        X =  (rho * Z - Y + 2 * Mm)./ Rp2;
        out.loss(i) = resfun(X, mu, Mm, Om);
        if i > 1 && out.loss(i-1) - out.loss(i) < tol ...
                && out.loss(i-1) - out.loss(i) >= 0
            out.iter = i;
            out.loss = out.loss(1 : i);
            out.opt = resfun(X, mu, Mm, Om);
            return;
        end
        Z = Sm(X + Y / rho, mu / rho);
        Y = Y + rho * tau * (X - Z);
    end
    out.iter = max_iter;
    out.opt = resfun(X, mu, Mm, Om);
end

function [Om, Mm] = form_matrix(m, n, Omega, M)
    Om = zeros(m, n, 'logical');
    Mm = zeros(m, n);
    for t = 1:size(Omega, 2)
        k = Omega(t);
        j = mod(k - 1, n) + 1;
        i = (k - j) / n + 1;
        Om(i, j) = 1;
        Mm(i, j) = M(t);
    end
end

function res = Sm(X, p)
    [U, S, V] = svd(X);
    S = shrink(S, p);
    res = U * S * V';
end

function res = shrink(vec, p)
    if p < 0
        res = "Error";
        return;
    end
    res = (abs(vec) > p) .* (vec - p * sign(vec));
end

function res = resfun(X, mu, Mm, Om)
    S = svd(X);
    res = mu * sum(sum(S));
    res = res + norm((X - Mm) .* Om, "fro") ^2;
end
