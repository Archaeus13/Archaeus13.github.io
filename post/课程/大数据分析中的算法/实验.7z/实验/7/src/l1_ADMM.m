function [x, out] = l1_ADMM(x0, A, b, mu, opts)
    rho = opts.rho;
    tau = opts.tau;
    tol = opts.tol;
    max_iter = opts.max_iter;
    out.loss = zeros(max_iter, 1);
    out.dual_gap = zeros(max_iter, 1);

    x = x0;
    s = x;

    m = size(A, 1);
    T = rho * (A * A') + eye(m);
    R = chol(T); % T = R' * R; inv(T) = inv(R) * inv(R')
    
    for i = 1:max_iter
        lam = R \ (R' \ (A * (rho * s - x) + b));
        alam = A' * lam;
        s = proj(x/rho + alam, mu);
        x = x + tau * rho * (alam - s);
        out.loss(i) = mu * norm(x, 1) + norm(A * x - b) ^ 2 / 2;
        out.dual_gap(i) = out.loss(i) - lam' * b + norm(lam) ^ 2 / 2;
        if out.dual_gap(i) < tol && out.dual_gap(i) >= 0
            out.iter = i;
            out.loss = out.loss(1 : i);
            out.dual_gap = out.dual_gap(1 : i);
            return;
        end
    end
    out.iter = max_iter;
end

function res = proj(vec, p)
    if p < 0
        res = "Error";
        return;
    end
    res = min(max(vec, -p), p);
end