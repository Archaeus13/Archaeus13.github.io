% function Test_BP

% min mu*||x||_1 + ||Ax-b||_1

% generate data
n = 1024;
m = 512;

A = randn(m,n);
u = sprandn(n,1,0.1);
b = A*u;
mu = 1e-2;


x0 = rand(n,1);

errfun = @(x1, x2) norm(x1-x2)/(1+norm(x1));
resfun = @(x) norm(A*x-b,1);
nrm1fun = @(x) norm(x,1);

% cvx calling mosek
opts1 = []; %modify options
tic; 
[x1, out1] = l1_cvx_mosek(x0, A, b, mu, opts1);
t1 = toc;

% call mosek directly
opts3 = []; %modify options
tic; 
[x3, out3] = l1_mosek(x0, A, b, mu, opts3);
t3 = toc;

% other approaches

opts5 = []; %modify options
tic; 
[x5, out5] = l1_method1(x0, A, b, mu, opts5);
t5 = toc;


% print comparison results with cvx-call-mosek
fprintf('cvx:        res: %3.2e, nrm1: %3.2e\n', resfun(x1), nrm1fun(x1));
fprintf('call-mosek: res: %3.2e, nrm1: %3.2e, cpu: %5.2f, err-to-cvx-mosek: %3.2e\n', ...
        resfun(x3), nrm1fun(x3), t3, errfun(x1, x3));
fprintf('methodxxxx: res: %3.2e, nrm1: %3.2e, cpu: %5.2f, err-to-cvx-mosek: %3.2e\n', ...
        resfun(x5), nrm1fun(x5), t5, errfun(x1, x5));
