% min mu*||X||_* + sum_{ij in idx}(Xij - Mij)^2 / 2
close all;
clear;

% set seed for debugging
rng(1);

nnorm = @(X) sum(sum(svd(X)));

% generate data
m = 200; n = m; sr = 0.3; p = round(m * n * sr); r = 10;

% get problem
Omega = randperm(m*n); Omega = Omega(1:p); % Omega gives the position of samplings
xl = randn(m, r); xr = randn(n, r); A = xl*xr'; % A is the matrix to be completed
M  = A(Omega); % M is the samples from A

% ADMM
figure();
for mu = [0.1, 0.01, 0.001]
    opts.rho = 0.01;
    opts.tau = 1;
    opts.tol = 1e-8;
    opts.max_iter = 10000;

    tic;
    [X, out] = admm(m, n, Omega, M, mu, opts);
    t = toc;

    rel = out.loss / mu / nnorm(A) - 1;
    plot(rel, linewidth=2);
    hold on;
        
    fprintf("mu = " + mu + "\n");
    fprintf("iters = " + out.iter + ", time = " + t + "\n");
    fprintf("res = " + out.opt + ", A res = " + mu * nnorm(A) + "\n\n");
end
xlabel("iter");
ylabel("relative result");
legend("mu = 0.1", "mu = 0.01", "mu = 0.001", Location="northeast");

% accelerated ADMM
figure();
for mu = [0.1, 0.01, 0.001]
    opts.rho = 0.01;
    opts.tau = 1;
    opts.tol = 1e-8;
    opts.max_iter = 10000;
    opts.r = r;

    tic;
    [X, out] = admm_acc(m, n, Omega, M, mu, opts);
    t = toc;

    rel = out.loss / mu / nnorm(A) - 1;
    plot(rel, linewidth=2);
    hold on;
        
    fprintf("mu = " + mu + "\n");
    fprintf("iters = " + out.iter + ", time = " + t + "\n");
    fprintf("res = " + out.opt + ", A res = " + mu * nnorm(A) + "\n\n");
end
xlabel("iter");
ylabel("relative result");
legend("mu = 0.1", "mu = 0.01", "mu = 0.001", Location="northeast");