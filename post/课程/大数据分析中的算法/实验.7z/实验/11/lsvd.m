function [U, S, V] = lsvd(A, r, p)
    if ~exist("p", "var")
        p = r;
    end
    pr = sum(A .^ 2, 1);
    pr = pr / sum(pr);
    qr = pr;
    for i = 2:length(pr)
        qr(i) = qr(i - 1) + qr(i);
    end

    C = zeros(size(A, 1), r + p);
    for i = 1:(r + p)
        t = rand();
        for j = 1:length(qr)
            if t <= qr(j)
                it = j;
                break;
            end
        end
        C(:, i) = A(:, it) / sqrt((r + p) * pr(it));
    end

    [P, D] = schur(C' * C); % schur decom. and sorting
    d = diag(D);
    [d, I] = sort(d, 'descend');
    P = P(:, I);
    H = (C * P(:, 1:r)) ./ sqrt(d(1:r))';
    
    Y = A' * H;
    [V, S, W] = svd(Y, 0);
    U = H * W;
end