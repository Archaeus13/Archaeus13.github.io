function [U, S, V] = rsvd(A, r, p, q)
    if ~exist("p", "var")
        p = r;
    end
    if ~exist("q", "var")
        q = 1;
    end
    Omega = randn(size(A, 2), r + p);
    Y = A * Omega;
    for i = 1:q
        Y = A' * Y;
        Y = A * Y;
    end
    [Q, ~] = qr(Y, 0);
    B = Q' * A;
    [U, S, V] = svd(B, 0);
    U = U(:, 1:r);
    S = S(1:r, 1:r);
    V = V(:, 1:r);
    U = Q * U;
end