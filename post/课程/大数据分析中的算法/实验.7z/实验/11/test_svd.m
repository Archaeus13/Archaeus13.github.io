rng(1);

m = 2048;
n = 512;
p = 20;
A = randn(m, p) * randn(p, n);

disp("case " + m + "*" + n);

for r = 5:5:20
    tic;
    [U1, S1, V1] = lsvd(A, r);
    t1 = toc;
    A1 = U1 * S1 * V1';
    tic;
    [U2, S2, V2] = rsvd(A, r);
    t2 = toc;
    A2 = U2 * S2 * V2';
    tic;
    [U3, S3, V3] = rsvd(A, r, r, 2);
    t3 = toc;
    A3 = U3 * S3 * V3';

    disp("r = " + r);
    disp("lsvd,        err = " + norm(A - A1) + ", t = " + t1);
    disp("rsvd, q = 1, err = " + norm(A - A2) + ", t = " + t2);
    disp("rsvd, q = 2, err = " + norm(A - A3) + ", t = " + t3);
end

B = double(rgb2gray(imread("a.jpg")));

disp(newline + "case " + size(B, 1) + "*" + size(B, 2))

for r = 5:5:20
    tic;
    [U1, S1, V1] = lsvd(B, r);
    t1 = toc;
    B1 = U1 * S1 * V1';
    tic;
    [U2, S2, V2] = rsvd(B, r);
    t2 = toc;
    B2 = U2 * S2 * V2';
    tic;
    [U3, S3, V3] = rsvd(B, r, r, 2);
    t3 = toc;
    B3 = U3 * S3 * V3';

    disp("r = " + r);
    disp("lsvd,        err = " + norm(B - B1) + ", t = " + t1);
    disp("rsvd, q = 1, err = " + norm(B - B2) + ", t = " + t2);
    disp("rsvd, q = 2, err = " + norm(B - B3) + ", t = " + t3);
end

figure();

subplot(2, 2, 1);
imshow(uint8(B));
title("original");

subplot(2, 2, 2);
imshow(uint8(B1));
title("lsvd, r = " + r);

subplot(2, 2, 3);
imshow(uint8(B2));
title("rsvd, r = " + r + ", q = 1");

subplot(2, 2, 4);
imshow(uint8(B3));
title("rsvd, r = " + r + ", q = 2");