function show_res(res, filename, if_print, if_draw)
    load(filename, 'trains', 'stations', 'miles', 'bias_train', 'edges');
    NV = size(edges, 1);
    N = length(trains);
    n = length(stations);
    T = (NV - 2) / (2 * n - 2) - 1;

    function vertex = index_to_vertex(index)
        if index == 1
            vertex.type = "sigma";
            vertex.station = -1;
            vertex.time = -1;
            return;
        end
        if index == NV
            vertex.type = "tau";
            vertex.station = -1;
            vertex.time = -1;
            return;
        end
        pos = floor((index - 2) / (T + 1));
        vertex.time = index - 2 - pos * (T + 1);
        vertex.station = floor((pos + 1) / 2) + 1;
        if mod(pos, 2)
            vertex.type = "arrival";
        else
            vertex.type = "begin";
        end
    end

    if if_print
        for i = 1:N
            for i0 = bias_train(i) + 1:bias_train(i + 1)
                if res(i0)
                    a = find(edges(:, i0), 1);
                    vb = index_to_vertex(a);
                    if vb.type == "begin"
                        fprintf("train " + trains(i));
                        fprintf(" start from " + stations(vb.station));
                        fprintf(" at " + vb.time + "\n");
                    end
                    if vb.type == "arrival"
                        fprintf("train " + trains(i));
                        fprintf(" arrive at " + stations(vb.station));
                        fprintf(" at " + vb.time + "\n");
                    end
                end
            end
        end
    end

    if if_draw
        figure;
        for i = 1:N
            if sum(res(bias_train(i) + 1:bias_train(i + 1))) < 1
                continue;
            end
            ts = zeros(2 * n - 2, 1);
            ys = zeros(2 * n - 2, 1);
            now = 1;
            for i0 = bias_train(i) + 1:bias_train(i + 1)
               if res(i0)
                   a = find(edges(:, i0), 1);
                   vb = index_to_vertex(a);
                   if vb.type == "begin" || vb.type == "arrival"
                       ts(now) = vb.time;
                       ys(now) = miles(vb.station);
                       now = now + 1;
                   end
               end
            end
            plot(ts, ys, LineWidth=1.5);
            text(ts(end), ys(end), trains(i));
            hold on;
        end
        grid on;
    end
end