function form_problem(trains, stations, miles, velocities, ...
    time_by_velocity, if_stop, T, m, M, s, problem_type)

    N = length(trains);
    n = length(stations);

    %% 构造下标与顶点的映射

    % 顶点是一个拥有 type station time 的结构体

    NV = (T + 1) * (2 * n - 2) + 2;
    
    %{
    function vertex = index_to_vertex(index)
        if index == 1
            vertex.type = "sigma";
            vertex.station = -1;
            vertex.time = -1;
            return;
        end
        if index == NV
            vertex.type = "tau";
            vertex.station = -1;
            vertex.time = -1;
            return;
        end
        pos = floor((index - 2) / (T + 1));
        vertex.time = index - 2 - pos * (T + 1);
        vertex.station = floor((pos + 1) / 2) + 1;
        if mod(pos, 2)
            vertex.type = "arrival";
        else
            vertex.type = "begin";
        end
    end
    %}
    
    % sigma: index = 1
    % tau: index = NV
    % bias: index - (vertex.time + 1)
    function bias = vertex_to_bias(vertex)
        switch vertex.type
            case "begin"
                bias = 1 + (vertex.station * 2 - 2) * (T + 1);
            case "arrival"
                bias = 1 + (vertex.station * 2 - 3) * (T + 1);
        end
    end


    %% 边集数量计算

    % n 站对应每辆火车的 2n-1 组边
    edge_num = zeros(N, 2 * n - 1, "int32"); % 每组的边数

    for i = 1:N % 对每辆车
        % 起始到首发站共 T+1 条边
        edge_num(i, 1) = T + 1; % 这类第 t 条边 表示 t 时刻出发
        % 终点站到结束共 T+1 条边
        edge_num(i, end) = T + 1; % 这类第 t 条边 表示 t 时刻到达

        for j = 1:n-1
            % 第 j 站开到第 j + 1 站的边
            % 最早 0 发车 最晚 T - f(vi)j 发车
            edge_num(i, 2*j) =  T - time_by_velocity(velocities(i), j) + 1;
        end
        for j = 2:n-1
            % 停在第 j 站的边
            if if_stop(i, j)
                % 0 时刻到 T - M 时刻都能连接上标为其加 m 到其加 M
                % 随后每往前一分钟少一条边 直到 0
                edge_num(i, 2*j-1) = (T - M + 1) * (M - m + 1) ...
                    + (M - m + 1) * (M - m) / 2;
            else
                edge_num(i, 2*j-1) = T + 1; % 不停则直接连接
            end
        end
    end
    
    %% 构造图的边集

    % bias_train 代表每辆列车对应的边数所引起的偏移
    % 第 i 辆对应的边为下标 bias_train(i) + 1 到 bias_train(i + 1)
    bias_train = zeros(N + 1, 1);
    for i = 1:N
        bias_train(i + 1) = bias_train(i) + sum(edge_num(i, :));
    end
    NE = bias_train(N + 1);

    % edges 的每列代表一条边
    % 每列有两个非零元素 边出发处为 -1 到达处为 1
    % 考虑每行的 1 即得
    edges = sparse(NV, NE);

    bias = 0;
    for i = 1:N
        for j = 1:2*n-1
            % 考虑每一类的第 k 条边 分类给出含义
            if j == 1
                temp_v.type = "begin";
                temp_v.station = 1;
                temp = vertex_to_bias(temp_v);
                for k = 1:edge_num(i, j)
                    edges(1, bias + k) = -1;
                    edges(temp + k, bias + k) = 1;
                end
            elseif j == 2*n-1
                temp_v.type = "arrival";
                temp_v.station = n;
                temp = vertex_to_bias(temp_v);
                for k = 1:edge_num(i, j)
                    edges(temp + k, bias + k) = -1;
                    edges(NV, bias + k) = 1;
                end
            elseif mod(j, 2) % arrival to begin
                temp_v.type = "arrival";
                temp_v.station = (j + 1) / 2;
                temp = vertex_to_bias(temp_v);
                temp_v.type = "begin";
                temp2 = vertex_to_bias(temp_v);
                if if_stop(i, temp_v.station)
                    temp3 = 1;
                    for k = 1:T+1
                        for l = k+m : min(k+M, T+1)
                            edges(temp + k, bias + temp3) = -1;
                            edges(temp2 + l, bias + temp3) = 1;
                            temp3 = temp3 + 1;
                        end
                    end
                    % disp(temp3 - edge_num(i, j)); % should be 1
                else
                    for k = 1:edge_num(i, j)
                        edges(temp + k, bias + k) = -1;
                        edges(temp2 + k, bias + k) = 1;
                    end
                end
            else % begin to arrival 
                temp_v.type = "begin";
                temp_v.station = j / 2;
                temp = vertex_to_bias(temp_v);
                temp_v.type = "arrival";
                temp_v.station = temp_v.station + 1;
                temp2 = vertex_to_bias(temp_v);
                % add time bias
                temp2 = temp2 + time_by_velocity(velocities(i), ...
                    temp_v.station - 1);
                for k = 1:edge_num(i, j)
                    edges(temp + k, bias + k) = -1;
                    edges(temp2 + k, bias + k) = 1;
                end
            end
            bias = bias + edge_num(i, j);
        end
    end

    %% 构造冲突顶点集
    
    % 只需考虑每连续 s 个顶点冲突的情况
    % 若更短则被某一种包含
    % 共有 2 * n - 2 排顶点 每排产生 (T + 1) - s + 1 组冲突
    
    group_num = T + 2 - s;
    conflict = zeros((2 * n - 2) * group_num, s, "int32");

    for i = 1:2*n-2
        bias = (i - 1) * (T + 1) + 1;
        for j = 1:group_num
            conflict((i - 1) * group_num + j, :) = ...
                (j:(j + s - 1)) + bias;
        end
    end

    %% 通过问题类型构造权重

    weights = zeros(NE, 1);

    bias = 0;
    for i = 1:N
        for j = 1:2*n-1
            % 考虑每一类的第 k 条边 分类给出含义
            if j == 1
                % 无论哪种 优先尽量多车
                for k = 1:edge_num(i, j)
                    weights(bias + k) = (N - 1) * max(n * M, T + 1) + 1;
                end
            elseif j == 2*n-1
                if problem_type == "MinFinish"
                    % 最短终止时间 越晚权重越低
                    for k = 1:edge_num(i, j)
                        weights(bias + k) = -k;
                    end
                end
            elseif mod(j, 2) && problem_type == "MinStop" % arrival to begin
                if if_stop(i, (j + 1) / 2)
                    temp = 1;
                    for k = 1:T+1
                        for l = k+m : min(k+M, T+1)
                            % 最短停留时间 停止越长权重越低
                            weights(bias + temp) = k - l;
                            temp = temp + 1;
                        end
                    end
                end
            elseif mod(j, 2) && problem_type == "MaxStop" % arrival to begin
                if if_stop(i, (j + 1) / 2)
                    temp = 1;
                    for k = 1:T+1
                        for l = k+m : min(k+M, T+1)
                            % 最短停留时间 停止越长权重越低
                            weights(bias + temp) = l - k;
                            temp = temp + 1;
                        end
                    end
                end
            end
            bias = bias + edge_num(i, j);
        end
    end


    %% 保存结果

    save problem.mat trains stations miles bias_train edges conflict weights;
end