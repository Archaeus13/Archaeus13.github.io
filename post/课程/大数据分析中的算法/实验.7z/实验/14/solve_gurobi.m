function res = solve_gurobi(filename)
    load(filename, 'bias_train', 'edges', 'conflict', 'weights');

    [NV, NE] = size(edges);
    N = length(bias_train) - 1;
    C = size(conflict, 1); % 冲突组数

    % 条件数 每个火车初始顶点与中间顶点 + 所有冲突
    NC = (NV - 1) * N + C;

    %% 预处理 所有 delta-(v) 与 delta+(v)
    Dp = (edges == -1);
    Dm = (edges == 1);

    %% 通过约束构造 A 与 b

    A = sparse(NC, NE);
    rhs = zeros(NC, 1);
    sense = char(zeros(NC, 1));
    
    count = 1;

    % 对每辆列车
    for i = 1:N
        mask = bias_train(i) + 1:bias_train(i + 1);
        % 出发点约束
        A(count, mask) = Dp(1, mask);
        rhs(count) = 1;
        sense(count) = '<';
        count = count + 1;

        % 途径点约束
        for j = 2:NV-1
            A(count, mask) = Dp(j, mask);
            A(count, mask) = A(count, mask) - Dm(j, mask);
            rhs(count) = 0;
            sense(count) = '=';
            count = count + 1;
        end
        disp(i + " done");
    end
    
    % 对每组冲突顶点
    for i = 1:C
        A(count, :) = sum(Dm(conflict(i, :), :), 1);
        rhs(count) = 1;
        sense(count) = '<';
        count = count + 1;
    end


    %% 求解与构造结果
    
    model.A = A;
    model.rhs = rhs;
    model.obj = -weights;
    model.sense = sense;
    model.vtype = 'B';

    R = gurobi(model);
    res = R.x;
end