function res = solve_lagrange(filename, iter, eta)
    load(filename, 'bias_train', 'edges', 'conflict', 'weights', 'stations');

    weights = weights';
    
    [NV, NE] = size(edges);
    N = length(bias_train) - 1;
    C = size(conflict, 1); % 冲突组数
    
    %% 预处理 所有 delta+(v) 与 delta-(v) 并计算冲突
    Dp = (edges == -1);
    Dm = (edges == 1);

    conflict_masks = sparse(1, 1, false, C, NE);

    % 每行代表一个冲突对应的所有边
    for i = 1:C
        conflict_masks(i, :) = sum(Dm(conflict(i, :), :), 1);
    end

    %% 预处理 反向邻接表 (每个顶点找所有指向它的边与对应起点)

    % 最多有 T + 1 条进入的边
    T = (NV - 2) / (2 * length(stations) - 2) - 1;
    edge_before = zeros(N, NV, T + 1, "int32");
    vertex_before = zeros(N, NV, T + 1, "int32");

    for i = 1:N
        for j = 2:NV
            % 超出对应部分的全为 0
            temp = find(Dm(j, (bias_train(i) + 1):bias_train(i + 1)));
            temp = temp + bias_train(i);
            edge_before(i, j, 1:length(temp)) = temp;
            for k = 1:length(temp)
                vertex_before(i, j, k) = find(Dp(:, temp(k)), 1);
            end
        end
    end

    %% 迭代求解
    lam = zeros(C, 1);

    for t = 1:iter
        % 初始化结果
        res = zeros(1, NE, 'logical');
        
        % 对每个 i 求解 DAG 最短路径问题
        % 此处节点已经为拓扑排序  

        for i = 1:N
            bias = bias_train(i);
            mask = (bias_train(i) + 1):bias_train(i + 1);

            % 由乘子计算修正的权重
            w_m = weights(mask) - sum(lam .* conflict_masks(:, mask), 1);

            l_now = ones(1, NV) * (-inf);
            pr_now = zeros(1, NV, "int32");
            edg_now = zeros(1, NV, "int32");
            l_now(1) = 0;
            
            for j = 2:NV
                for k = 1:T+1
                    % 所有列车 i 对应的进入 j 的边
                    kb = edge_before(i, j, k);
                    if ~kb
                        break;
                    end
                    j_b = vertex_before(i, j, k);
                    lnew = l_now(j_b) + w_m(kb - bias);
                    if lnew > l_now(j)
                        pr_now(j) = j_b;
                        edg_now(j) = kb;
                        l_now(j) = lnew;
                    end
                end
            end

            now = NV;
            while pr_now(now)
                res(edg_now(now)) = 1;
                now = pr_now(now);
            end

            % 更新乘子 不能放在循环外
            lam = max(0, lam + eta / N * (sum(res .* conflict_masks, 2) - 1));
        end

        % if mod(t, 100) == 0
        %     disp(t + " done");
        %     show_res(res, "problem.mat", 0, 1);
        % end
    end

    %% 解可行化

    while true
        con = res .* conflict_masks;
        pos = sum(con, 2) > 1;
        if sum(pos) == 0
            break;
        end
        con = con(pos, :);
        m = zeros(N, 1);
        for i = 1:N
            m(i) = sum(sum(con(:, (bias_train(i) + 1):bias_train(i + 1))));
        end
        [~, i] = max(m);
        res((bias_train(i) + 1):bias_train(i + 1)) = 0;
    end

end