trains = ["G1", "G3", "G5", "G7", "G9", "G11", "G13", "G15", "G17", ...
    "G19", "G21", "G23", "G25", "G27", "G29", "G31"];
stations = ["A", "B", "C", "D", "E", "F", "G"];
velocities = [350 * ones(1, 6, "uint16"), 300 * ones(1, 10, "uint16")];

if_stop = ones(16, 7, "logical");
if_stop(1, :) = [1,0,0,0,0,1,1];
if_stop(2, :) = [1,1,1,0,1,0,1];
if_stop(3, :) = [1,1,0,1,0,1,1];
if_stop(4, :) = [1,1,0,0,1,0,1];
if_stop(5, :) = [1,1,0,0,0,1,1];
if_stop(6, :) = [1,1,0,0,1,0,1];

T = 160; s = 5; m = 2; M = 15;
miles = [0, 50, 100, 170, 210, 250, 300];

renew = false;

if ~exist("problem.mat", "file") || renew
    form_problem(trains, stations, miles, velocities, @time_by_velocity, if_stop, T, m, M, s, "MinFinish");
    fprintf("Generation Done\n\n");
end

fprintf("Gurobi\n");
res = solve_gurobi("problem.mat");
show_res(res, "problem.mat", 1, 1);
fprintf("\n");

fprintf("Lagrange\n");
res = solve_lagrange("problem.mat", 100, 1e-5);
show_res(res, "problem.mat", 1, 1);
fprintf("\n");

fprintf("ALM\n");
res = solve_augmented("problem.mat", 2000, 1e-1, 1e-3);
show_res(res, "problem.mat", 1, 1);
fprintf("\n");

function r = time_by_velocity(v, j)
    if v == 300
        vec = [10, 20, 14, 8, 8, 10];
    else
        vec = [9, 18, 12, 7, 7, 8];
    end
    r = vec(j);
end