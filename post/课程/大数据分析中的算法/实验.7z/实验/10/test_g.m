rng(1);

if ~exist('X_gis_train', 'var')
    [y_gis_train, X_gis_train] = libsvmread('gisette_scale.data'); % read train data
    [y_gis_test, X_gis_test] = libsvmread('gisette_scale_t.data'); % read test data
end

lam = 10;

test = [1, 1, 1, 1];

if test(1)
    opts.lr = 0.0001;
    opts.eps = 0.001;
    opts.b = 32;
    opts.tol = 1e-7;
    opts.max_iter = 1000;
    opts.s = 50;
    w = adagrad(X_gis_train, y_gis_train, X_gis_test, y_gis_test, lam, opts);
end

if test(2)
    opts.lr = 0.0001;
    opts.eps = 0.001;
    opts.r1 = 0.9;
    opts.r2 = 0.9;
    opts.b = 32;
    opts.tol = 1e-7;
    opts.max_iter = 1000;
    opts.s = 50;
    w = adam(X_gis_train, y_gis_train, X_gis_test, y_gis_test, lam, opts);
end

if test(3)
    opts.lr = 0.0001;
    opts.m = 100;
    opts.b = 32;
    opts.tol = 1e-7;
    opts.max_iter = 1000;
    opts.s = 50;
    w = svrg(X_gis_train, y_gis_train, X_gis_test, y_gis_test, lam, opts);
end

if test(4)
    opts.lr = 0.0001;
    opts.m = 5;
    opts.b = 32;
    opts.tol = 1e-7;
    opts.max_iter = 1000;
    opts.s = 50;
    w = lbfgs(X_gis_train, y_gis_train, X_gis_test, y_gis_test, lam, opts);
end