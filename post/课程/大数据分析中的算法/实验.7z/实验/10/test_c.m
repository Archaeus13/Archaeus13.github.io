rng(1);

if ~exist('X_cov_train', 'var')
    [y_cov, X_cov] = libsvmread('covtype_scale.data'); % read data
    y_cov = y_cov * 2 - 3; % {1, 2} to {-1, 1}
    n = length(y_cov);
    r = randsample(n, int32(0.3 * n)); % split train and test
    X_cov_test = X_cov(r, :);
    y_cov_test = y_cov(r);
    X_cov_train = X_cov(setdiff(1:n, r), :);
    y_cov_train = y_cov(setdiff(1:n, r));
    clear X_cov y_cov r n;
end

lam = 0.001;

test = [1, 1, 1, 1];

if test(1)
    opts.lr = 0.5;
    opts.eps = 0.0001;
    opts.b = 32;
    opts.tol = 1e-7;
    opts.max_iter = 5000;
    opts.s = 100;
    w = adagrad(X_cov_train, y_cov_train, X_cov_test, y_cov_test, lam, opts);
end

if test(2)
    opts.lr = 0.05;
    opts.eps = 0.0001;
    opts.r1 = 0.9;
    opts.r2 = 0.9;
    opts.b = 32;
    opts.tol = 1e-7;
    opts.max_iter = 5000;
    opts.s = 100;
    w = adam(X_cov_train, y_cov_train, X_cov_test, y_cov_test, lam, opts);
end

if test(3)
    opts.lr = 0.5;
    opts.m = 100;
    opts.b = 32;
    opts.tol = 1e-7;
    opts.max_iter = 2000;
    opts.s = 100;
    w = svrg(X_cov_train, y_cov_train, X_cov_test, y_cov_test, lam, opts);
end

if test(4)
    opts.lr = 0.005;
    opts.m = 5;
    opts.b = 32;
    opts.tol = 1e-7;
    opts.max_iter = 5000;
    opts.s = 100;
    w = lbfgs(X_cov_train, y_cov_train, X_cov_test, y_cov_test, lam, opts);
end