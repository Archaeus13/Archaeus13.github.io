function w = adagrad(X_train, y_train, X_test, y_test, lam, opts)
    % X_train: features of train data
    % y_train: label of train data
    % X_test: features of test data
    % y_test: label of test data
    % lam: regularization
    % opts: options
        % opts.lr: learning rate
        % opts.eps: to avoid dividing by 0
        % opts.b: batch size
        % opts.tol: tolerance of grad
        % opts.max_iter: max iters
        % opts.s: steps to plot acc
    
    tic; % timing

    max_length = int32(opts.max_iter / opts.s);
    times = zeros(1, max_length);
    iters = zeros(1, max_length);
    train_acc = zeros(1, max_length); % train acc
    test_acc = zeros(1, max_length); % test acc
    train_loss = zeros(1, max_length); % train loss
    test_loss = zeros(1, max_length); % test loss
    count = 0;

    [n, d] = size(X_train);
    n_test = size(X_test, 1);


    w = zeros(d, 1); % initialize by 0;

    grd = @(w, x, y, l) y * (tanh((w' * x) * y) ^ 2 - 1) * x + 2 * l * w;

    G = zeros(d, 1);
    for i = 1:opts.max_iter
        % estimate g
        is = randsample(n, opts.b);
        g = zeros(d, 1);
        for j = is'
            g = g + grd(w, X_train(j, :)', y_train(j), lam);
        end
        g = g / opts.b;

        % judge if stop
        if norm(g) < opts.tol
            break;
        end

        % count iter
        G = G + g .* g;
        w = w - opts.lr * g ./ sqrt(G + opts.eps);
  
        if mod(i, opts.s) == 1
            % count loss
            count = count + 1;
            times(count) = toc;
            iters(count) = i;
            train_res = sign(X_train * w);
            train_res(train_res == 0) = 1;
            train_acc(count) = sum(int32(train_res) == int32(y_train)) / n;
            test_res = sign(X_test * w);
            test_res(test_res == 0) = 1;
            test_acc(count) = sum(int32(test_res) == int32(y_test)) / n_test;
            train_loss(count) = sum(1 - tanh(y_train .* (X_train * w))) / n + lam * norm(w) ^ 2;
            test_loss(count) = sum(1 - tanh(y_test .* (X_test * w))) / n_test + lam * norm(w) ^ 2;
        end
    end

    % draw result
    times = times(1:count);
    iters = iters(1:count);
    train_acc = train_acc(1:count);
    test_acc = test_acc(1:count);
    train_loss = train_loss(1:count);
    test_loss = test_loss(1:count);

    times(end) = toc;
    iters(end) = i;
    train_res = sign(X_train * w);
    train_res(train_res == 0) = 1;
    train_acc(end) = sum(int32(train_res) == int32(y_train)) / n;
    test_res = sign(X_test * w);
    test_res(test_res == 0) = 1;
    test_acc(end) = sum(int32(test_res) == int32(y_test)) / n_test;
    train_loss(count) = sum(1 - tanh(y_train .* (X_train * w))) / n + lam * norm(w) ^ 2;
    test_loss(count) = sum(1 - tanh(y_test .* (X_test * w))) / n_test + lam * norm(w) ^ 2;

    figure();
    yyaxis left;
    plot(iters, train_acc, iters, test_acc, LineWidth=1.5);
    xlabel("iters");
    ylabel("acc");
    yyaxis right;
    plot(iters, times, LineWidth=1.5);
    ylabel("time");
    legend(["train", "test", "time"], Location="southeast");
    title("Adagrad acc");

    figure();
    yyaxis left;
    plot(iters, train_loss, iters, test_loss, LineWidth=1.5);
    xlabel("iters");
    ylabel("loss");
    yyaxis right;
    plot(iters, times, LineWidth=1.5);
    ylabel("time");
    legend(["train", "test", "time"], Location="east");
    title("Adagrad loss");
end