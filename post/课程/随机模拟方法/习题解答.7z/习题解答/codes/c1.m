now = 2;
im = 12;
err = zeros(1, im + 1);
real = 1 - cos(1);
x = rand(now, 1);
res = sum(sin(x)) / now;
err(1) = abs(real - res);
fprintf("N = %7d,\t err = %e\n", now, err(1))
for i = 1:22
    now = now * 2;
    x = rand(now, 1);
    res = sum(sin(x)) / now;
    err(i + 1) = abs(real - res);
    ord = log(err(i) / err(i + 1)) / log(2);
    fprintf("N = %7d,\t err = %e,\t ord = %f\n", now, err(i + 1), ord);
end
plot(1:23, log(err) / log(2), 1:23, -(1:23)/2)