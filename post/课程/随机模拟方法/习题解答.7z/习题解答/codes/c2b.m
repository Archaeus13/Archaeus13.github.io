lambda = 1000;
N1 = floor(lambda - sqrt(lambda));
N2 = ceil(lambda + sqrt(lambda));
x = ((N1:N2) - lambda) / sqrt(lambda);
plot(x, poisspdf(N1:N2, lambda) * sqrt(lambda), x, normpdf(x), ...
    LineWidth=1);
legend(["poiss", "norm"]);
title("lambda = " + num2str(lambda));
axis([-1, 1, 0.2, 0.4]);