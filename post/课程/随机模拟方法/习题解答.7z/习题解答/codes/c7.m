a = 10;
b = 12;

T = 1000000;
f1 = @(x) exp(- x^2 / a);
f2 = @(x) exp(- x^2 / b);
F1 = 0;
F2 = 0;
now = 0;

N = 30;
result = zeros(1, N);
for k = 1:N
    F1 = 0;
    F2 = 0;
    epsilon = k * 0.1;
    for i = 1:T
        now = mod(now + randn() * sqrt(epsilon), 20) - 10;
        F1 = F1 + f1(now);
        F2 = F2 + f2(now);
    end
    result(k) = F1 / F2;
end

plot((1:N)*0.1, result, LineWidth=1.5);