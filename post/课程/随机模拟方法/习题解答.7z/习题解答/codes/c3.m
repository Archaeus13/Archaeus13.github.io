for i = 1:5
    tic;
    method1(300000000);
    fprintf("%f\t", toc);
end
fprintf("\n");
for i = 1:5
    tic;
    method2(300000000);
    fprintf("%f\t", toc);
end

function res = method1(N)
    temp = [randn(1, N); randn(1, N); randn(1, N)];
    s = sqrt(sum(temp .^ 2));
    res = temp ./ s;
end

function res = method2(N)
    theta = rand(1, N);
    phi = rand(1, N) * 2 * pi;
    theta = acos(1 - 2 * theta);
    res = [sin(theta) .* sin(phi); sin(theta) .* cos(phi); cos(theta)];
end