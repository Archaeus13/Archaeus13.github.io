lambda = 5;
N = 50;
plot(0:N, binopdf(0:N, N, lambda / N), 0:N, poisspdf(0:N, lambda), ...
    LineWidth=1);
legend(["bino", "poiss"]);
title("N = " + num2str(N));