clear;
close all;

% no solution
p = @(x) exp(-x);
solve_p(p, 1, -10, 2, 10, -20, 20, 1, 1e-12);

p = @(x) 1 ./ x;

% degeneration + degeneration
solve_p(p, 1, 2, 1, 2, -20, 20, 1, 1e-12);

% rarefaction + degeneration
solve_p(p, 1, 2, 5, 2 + log(5), -6, 0, 5, 1e-12);

% shock + degeneration
solve_p(p, 5, 4, 2, 4 - 3 / sqrt(10), -6, 0, 5, 1e-12);

% degeneration + rarefaction
solve_p(p, 4, 2 - log(4), 1, 2, 0, 6, 5, 1e-12);

% rarefaction + rarefaction
solve_p(p, 1, 3, 2, 4, -6, 6, 5, 1e-12);

% shock + rarefaction
solve_p(p, 5, 4, 2, 4, -6, 6, 5, 1e-12);

% degeneration + shock
solve_p(p, 3, 4 + 2/sqrt(15), 5, 4, 0, 6, 5, 1e-12);

% rarefaction + shock
solve_p(p, 2, 4, 5, 4, -6, 6, 5, 1e-12);

% shock + shock
solve_p(p, 5, 6, 2, 4, -6, 6, 5, 1e-12);