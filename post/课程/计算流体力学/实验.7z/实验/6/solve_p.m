function solve_p(p, vl, ul, vr, ur, xl, xr, t, tol)
    % solve function v_t = u_x, u_t = p(v)_x
    % p' < 0, p'' > 0, v > 0
    % (u(x, 0), v(x, 0)) = (ul, vl) if x <= 0
    % (u(x, 0), v(x, 0)) = (ur, vr) if x > 0
    % draw the result at time t in range [xl, xr]

    disp("(vL, uL) = (" + vl + ", " + ul + ")");
    disp("(vR, uR) = (" + vr + ", " + ur + ")");
    
    %% compute diff & int
    syms x;
    assume(x > 0);
    y = p(x);
    dp = diff(y, 1);
    P = int(simplify(sqrt(-dp)));
    l1 = finverse(-sqrt(-dp));
    l2 = finverse(sqrt(-dp));

    dp = matlabFunction(dp);
    P = matlabFunction(P);

    IP = @(a, b) P(b) - P(a);
    lam1 = @(a) -sqrt(-dp(a));
    lam2 = @(a) sqrt(-dp(a));
    l1 = matlabFunction(l1);
    l2 = matlabFunction(l2);
    
    clear x y P dp;
    
    %% find intersection point

    fL = @(v) ul + (v > vl) .* IP(vl, v) ...
        - (v < vl) .* sqrt((v - vl) .* (p(vl) - p(v)));
    
    fR = @(v) ur - (v > vr) .* IP(vr, v) ...
        + (v < vr) .* sqrt((vr - v) .* (p(v) - p(vr)));
    
    figure();
    hold on;
    plot(0.1:0.1:max(20, vl), fL(0.1:0.1:max(20, vl)), ...
        LineWidth=1.5, color=[1, 0, 0]);
    plot(0.1:0.1:max(20, vr), fR(0.1:0.1:max(20, vr)), ...
        LineWidth=1.5, color=[0.3, 0.3, 1]);
    plot(vl, ul, "*", Linewidth=3, color=[1, 0, 0]);
    plot(vr, ur, "*", Linewidth=3, color=[0.3, 0.3, 1]);
    title("fL(v) and fR(v) with (vL, vR), (uL, uR)");
    xlabel("v");
    ylabel("u");
    legend('fL', 'fR');

    disp("Draw fL and fR.");

    vm = find_intersect_positive(fL, fR, tol, 1e13);
    if vm == 0
        disp("No solution found." + newline);
        figure();
        title("result");
        axis([xl, xr, 0, 1]);
        text((xl + xr) / 2, 0.5, "No solution found.");
        return;
    end

    %% find wave type and get wave

    um = (fL(vm) + fR(vm)) / 2;
    disp("(vm, um) = (" + vm + ", " + um + ")");
    disp("error of fL and fR at vm: " + abs(fL(vm) - fR(vm)));

    if vm - vl > tol
        disp("I: rarefaction wave");
        v1 = @(xi) (xi < lam1(vl)) .* vl + ...
            (xi >= lam1(vl)) .* (xi < lam1(vm)) .* l1(xi) + ...
            (xi >= lam1(vm)) .* vm;
        u1 = @(xi) (xi < lam1(vl)) .* ul + ...
            (xi >= lam1(vl)) .* (xi < lam1(vm)) .* (ul + IP(vl, l1(xi))) + ...
            (xi >= lam1(vm)) .* um;
    else
        if vm - vl < -tol
            disp("I: shock wave");
            s1 = (ul - um) / (vm - vl);
            v1 = @(xi) (xi < s1) .* vl + (xi >= s1) .* vm;
            u1 = @(xi) (xi < s1) .* ul + (xi >= s1) .* um;
        else
             disp("I: degeneration");
             v1 = @(xi) xi * 0 + vl;
             u1 = @(xi) xi * 0 + ul;
        end
    end
    if vm - vr > tol
        disp("II: rarefaction wave" + newline);
        v2 = @(xi) (xi < lam2(vm)) .* vm + ...
            (xi >= lam2(vm)) .* (xi < lam2(vr)) .* l2(xi) + ...
            (xi >= lam2(vr)) .* vr;
        u2 = @(xi) (xi < lam2(vm)) .* um + ...
            (xi >= lam2(vm)) .* (xi < lam2(vr)) .* (ur - IP(vr, l2(xi))) + ...
            (xi >= lam2(vr)) .* ur;

    else
        if vm - vr < -tol
            disp("II: shock wave" + newline);
            s2 = (ur - um) / (vm - vr);
            v2 = @(xi) (xi < s2) .* vm + (xi >= s2) .* vr;
            u2 = @(xi) (xi < s2) .* um + (xi >= s2) .* ur;
 
        else
             disp("II: degeneration" + newline);
             v2 = @(xi) xi * 0 + vr;
             u2 = @(xi) xi * 0 + ur;
        end
    end

    %% solution

    x = xl:((xr - xl) / 1000):xr;
    xi = x / t;
    v = (xi <= 0) .* v1(xi) + (xi > 0) .* v2(xi);
    v(isnan(v)) = vm;
    u = (xi <= 0) .* u1(xi) + (xi > 0) .* u2(xi);
    u(isnan(u)) = um;

    figure();
    title("result at T = " + t);
    yyaxis left;
    xlabel("x");
    plot(x, v, LineWidth=1.5);
    axis([xl, xr, min(v) - 0.1, max(v) + 0.1]);
    ylabel("v(x, T)");
    yyaxis right;
    plot(x, u, LineWidth=1.5);
    axis([xl, xr, min(u) - 0.1, max(u) + 0.1]);
    ylabel("u(x, T)");
end

function res = find_intersect_positive(fL, fR, tol, tol_r)
    % fL increase, fR decrease

    %% get left and right
    dif = @(x) fL(x) - fR(x);
    res = 1;
    if dif(res) > 0
        left = 0;
        right = 1;
    else
        left = 1;
        right = 2;
        while dif(right) <= 0
            left = right;
            right = right * 2;
            if right > tol_r
                res = 0;
                return;
            end
        end
    end

    %% binary search
    while right - left >= tol 
        res = (left + right) / 2;
        if dif(res) > 0
            right = res;
        else
            left = res;
        end
    end
    res = (left + right) / 2;
    if res < tol
        res = 0;
    end
end