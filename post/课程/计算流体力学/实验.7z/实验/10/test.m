clear;
close all;

tt = [1, 1];

if tt(1)
    r0 = @(x) (x <= 0.5) * 0.445 + (x > 0.5) * 0.5;
    m0 = @(x) (x <= 0.5) * 0.311;
    E0 = @(x) (x <= 0.5) * 8.928 + (x > 0.5) * 1.4275;
    x0 = 0; x1 = 1;
    h = 0.004; tau = 0.0004; T = 0.14;

    res = ULT(r0, m0, E0, x0, x1, h, tau, T, @(x)abs(x), "1");
    figure;
    subplot(3, 1, 1);
    plot(x0:h:x1, res(1, :), LineWidth=1.5, Color="g");
    title("\rho");
    subplot(3, 1, 2);
    plot(x0:h:x1, res(2, :) ./ res(1, :), LineWidth=1.5, Color="b");
    title("u");
    subplot(3, 1, 3);
    plot(x0:h:x1, res(3, :), LineWidth=1.5, Color = "r");
    title("E");

    res = ULT(r0, m0, E0, x0, x1, h, tau, T, @(x)abs(x), "1C");
    figure;
    subplot(3, 1, 1);
    plot(x0:h:x1, res(1, :), LineWidth=1.5, Color="g");
    title("\rho");
    subplot(3, 1, 2);
    plot(x0:h:x1, res(2, :) ./ res(1, :), LineWidth=1.5, Color="b");
    title("u");
    subplot(3, 1, 3);
    plot(x0:h:x1, res(3, :), LineWidth=1.5, Color = "r");
    title("E");

    res = ULT(r0, m0, E0, x0, x1, h, tau, T, @(x)abs(x), "2");
    figure;
    subplot(3, 1, 1);
    plot(x0:h:x1, res(1, :), LineWidth=1.5, Color="g");
    title("\rho");
    subplot(3, 1, 2);
    plot(x0:h:x1, res(2, :) ./ res(1, :), LineWidth=1.5, Color="b");
    title("u");
    subplot(3, 1, 3);
    plot(x0:h:x1, res(3, :), LineWidth=1.5, Color = "r");
    title("E");
end

if tt(2)
    r0 = @(x) (x <= 0.3) * 1 + (x > 0.3) * 0.125;
    m0 = @(x) x * 0;
    E0 = @(x) (x <= 0.3) * 2.5 + (x > 0.3) * 0.25;
    x0 = 0; x1 = 1;
    h = 0.004; tau = 0.0004; T = 0.2;

    res = ULT(r0, m0, E0, x0, x1, h, tau, T, @(x)abs(x), "2");
    figure;
    subplot(3, 1, 1);
    plot(x0:h:x1, res(1, :), LineWidth=1.5, Color="g");
    title("\rho");
    subplot(3, 1, 2);
    plot(x0:h:x1, res(2, :) ./ res(1, :), LineWidth=1.5, Color="b");
    title("u");
    subplot(3, 1, 3);
    plot(x0:h:x1, res(3, :), LineWidth=1.5, Color = "r");
    title("E");

    res = ULT(r0, m0, E0, x0, x1, h, tau, T, @(x)abs(x), "1C");
    figure;
    subplot(3, 1, 1);
    plot(x0:h:x1, res(1, :), LineWidth=1.5, Color="g");
    title("\rho");
    subplot(3, 1, 2);
    plot(x0:h:x1, res(2, :) ./ res(1, :), LineWidth=1.5, Color="b");
    title("u");
    subplot(3, 1, 3);
    plot(x0:h:x1, res(3, :), LineWidth=1.5, Color = "r");
    title("E");

    res = ULT(r0, m0, E0, x0, x1, h, tau, T, @(x)abs(x), "2");
    figure;
    subplot(3, 1, 1);
    plot(x0:h:x1, res(1, :), LineWidth=1.5, Color="g");
    title("\rho");
    subplot(3, 1, 2);
    plot(x0:h:x1, res(2, :) ./ res(1, :), LineWidth=1.5, Color="b");
    title("u");
    subplot(3, 1, 3);
    plot(x0:h:x1, res(3, :), LineWidth=1.5, Color = "r");
    title("E");
end