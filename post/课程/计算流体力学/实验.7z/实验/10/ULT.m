function res = ULT(r0, m0, E0, x0, x1, h, tau, T, Q, type)
    lam = (T / round(T / tau)) / h;

    % initialize result
    x = x0:h:x1;
    n = length(x);
    r = r0(x);
    m = m0(x);
    E = E0(x);
    
    % initialize vars
    f = zeros(3, n);
    R1 = ones(3, n - 1);
    R2 = ones(3, n - 1);
    R3 = ones(3, n - 1);

    for i = 1:int32(T / tau)
        % 5-point scheme

        %% count f, f(*, j) is f at point j
        % together with u and H
        
        u = m ./ r;

        f(1, :) = m;
        f(2, :) = 0.8 * m .* u + 0.4 * E;

        H = 1.4 * E ./ r - 0.2 * u .^ 2;

        f(3, :) = m .* H;
        
        
        %% count a and R, R(*, j) is R at point j + 1/2
        % also a, uh, Hh, ch, al, gt, s, nu

        % uh
        sr = sqrt(r);
        sra = (sr(1:end-1) + sr(2:end)) / 2;
        sru = sr .* u;
        srua = (sru(1:end-1) + sru(2:end)) / 2;
        uh = srua ./ sra;

        % Hh
        srH = sr .* H;
        srHa = (srH(1:end-1) + srH(2:end)) / 2;
        Hh = srHa ./ sra;

        % ch
        uhuhd2 = uh .^ 2 / 2;
        ch = sqrt(0.4 * (Hh - uhuhd2));

        % a
        a1 = uh - ch;
        a2 = uh;
        a3 = uh + ch;

        % R
        uhch = uh .* ch;
        R1(2, :) = a1;
        R2(2, :) = a2;
        R3(2, :) = a3;
        R1(3, :) = Hh - uhch;
        R2(3, :) = uhuhd2;
        R3(3, :) = Hh + uhch;

        %% count al

        rd = r(2:end) - r(1:end-1);
        md = m(2:end) - m(1:end-1);
        Ed = E(2:end) - E(1:end-1);

        uhrd = uh .* rd;
        C1 = 0.4 * (Ed + uh .* uhrd / 2 - uh .* md) ./ ch .^ 2;
        C2 = (md - uhrd) ./ ch;
        al1 = (C1 - C2) / 2;
        al2 = rd - C1;
        al3 = (C1 + C2) / 2;

        %% count nu, gt and s

        nu1 = lam * a1;
        nu2 = lam * a2;
        nu3 = lam * a3;

        gt1 = (Q(nu1) - nu1 .^ 2) .* al1 / 2;
        gt2 = (Q(nu2) - nu2 .^ 2) .* al2 / 2;
        gt3 = (Q(nu3) - nu3 .^ 2) .* al3 / 2;
        s1 = sign(gt1);
        s2 = sign(gt2);
        s3 = sign(gt3);


        %% count be
        % be(j) is be at point j + 3/2
        if type == "2"
            % G(j) is G at point j + 3/2, also fb
            G1 = s1(2:end-1) .* max(0, ...
                min(s1(2:end-1) .* gt1(1:end-2), ...
                min(abs(gt1(2:end-1)), s1(2:end-1) .* gt1(3:end))));
            G2 = s2(2:end-1) .* max(0, ...
                min(s2(2:end-1) .* gt2(1:end-2), ...
                min(abs(gt2(2:end-1)), s2(2:end-1) .* gt2(3:end))));
            G3 = s3(2:end-1) .* max(0, ...
                min(s3(2:end-1) .* gt3(1:end-2), ...
                min(abs(gt3(2:end-1)), s3(2:end-1) .* gt3(3:end))));

            be1 = Q(nu1(2:end-1)) .* al1(2:end-1) - 2 * G1;
            be2 = Q(nu2(2:end-1)) .* al2(2:end-1) - 2 * G2;
            be3 = Q(nu3(2:end-1)) .* al3(2:end-1) - 2 * G3;
        else
            % g(j) is g at point j + 1
            g1 = s1(2:end) .* max(0, ...
                min(abs(gt1(2:end)), s1(2:end) .* gt1(1:end-1)));
            g2 = s2(2:end) .* max(0, ...
                min(abs(gt2(2:end)), s2(2:end) .* gt2(1:end-1)));
            g3 = s3(2:end) .* max(0, ...
                min(abs(gt3(2:end)), s3(2:end) .* gt3(1:end-1)));

            if type == "1C"
                % modify g2
                ss2 = sign(al2);
                si2 = (1 - Q(nu2)) / 2;
                gbb2 = ss2(2:end) .* max(0, ...
                    min(ss2(2:end) .* si2(1:end-1) .* al2(1:end-1), ...
                    abs(al2(2:end) .* si2(2:end))));
                div2 = abs(al2(2:end)) + abs(al2(1:end-1));
                th2 = abs(al2(2:end) - al2(1:end-1)) ./ div2;
                th2(ss2(2:end) == 0) = 0;
                g2 = g2 + th2 .* gbb2;
            end

            % gam(j) is gam at point j + 3/2
            gam1 = (g1(2:end) - g1(1:end-1)) ./ al1(2:end-1);
            gam1(al1(2:end-1) == 0) = 0;
            gam2 = (g2(2:end) - g2(1:end-1)) ./ al2(2:end-1);
            gam2(al2(2:end-1) == 0) = 0;
            gam3 = (g3(2:end) - g3(1:end-1)) ./ al3(2:end-1);
            gam3(al3(2:end-1) == 0) = 0;

            be1 = Q(nu1(2:end-1) + gam1) .* al1(2:end-1) ...
                - g1(1:end-1) - g1(2:end);
            be2 = Q(nu2(2:end-1) + gam2) .* al2(2:end-1) ...
                - g2(1:end-1) - g2(2:end);
            be3 = Q(nu3(2:end-1) + gam3) .* al3(2:end-1) ...
                - g3(1:end-1) - g3(2:end);
        end

        %% count iter
        fb = (f(:, 2:end-2) + f(:, 3:end-1) - ...
            (be1 .* R1(:, 2:end-1) + be2 .* R2(:, 2:end-1) ...
            + be3 .* R3(:, 2:end-1)) / lam ) / 2;
        r(3:end-2) = r(3:end-2) - lam * (fb(1, 2:end) - fb(1, 1:end-1));
        m(3:end-2) = m(3:end-2) - lam * (fb(2, 2:end) - fb(2, 1:end-1));
        E(3:end-2) = E(3:end-2) - lam * (fb(3, 2:end) - fb(3, 1:end-1));
    end

    res = [r; m; E];
end