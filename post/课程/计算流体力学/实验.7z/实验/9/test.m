clear;
close all;

tt = [0, 0, 1, 1];

if tt(1)
    N = 12;
    err = zeros(N, 3);
    x0 = 0; x1 = 2 * pi;
    for i = 1:N
        Ni = 2 ^ i;
        h = 2 * pi / Ni;
        tau = 1 / 2 ^ (N + 4);
        res = mm_iter(@(x) sin(x), 1, x0, x1, h, tau, 1, true);
        err(i, 1) = norm(res - sin((x0:h:x1) - 1)) / sqrt(length(res));
        err(i, 2) = norm(res - sin((x0:h:x1) - 1), 1) / length(res);
        err(i, 3) = norm(res - sin((x0:h:x1) - 1), "inf");
    end
    figure();
    plot(1:N, log(err(:, 1))/log(2), 1:N, log(err(:, 2))/log(2), ...
        1:N, log(err(:, 3))/log(2), LineWidth=1.5);
    title("test order on sin(x)");
    legend("L2", "L1", "L\infty");
    xlabel("-log_2(h/(2\pi))");
    ylabel("log_2(err)");
end

if tt(2)
    N = 12;
    err = zeros(N, 2);
    x0 = -1; x1 = 2;
    for i = 1:N
        Ni = 2 ^ i;
        h = 3 / Ni;
        tau = 1 / 2 ^ (N + 4);
        res = mm_iter(@(x) double(abs(x) < 0.2), 1, x0, x1, h, tau, 1, false);
        err(i, 1) = norm(res - double(abs((x0:h:x1) - 1) < 0.2)) / sqrt(length(res));
        err(i, 2) = norm(res - double(abs((x0:h:x1) - 1) < 0.2), 1) / length(res);
    end
    figure();
    plot(1:N, log(err(:, 1))/log(2), 1:N, log(err(:, 2))/log(2), LineWidth=1.5);
    title("test order on step function");
    legend("L2", "L1");
    xlabel("-log_2(h/3)");
    ylabel("log_2(err)");
end

if tt(3)
    u0 = @(x) exp(-100 * (x - 0.5) .^ 2) .* sin(80 * x);
    h = 1 / 200; tau = h * 0.6;
    figure();
    res = mm_iter(u0, 1, 0, 4, h, tau, 2, false);
    subplot(1, 3, 1);
    plot(0:h:1, u0(0:h:1), 0:h:1, res(end-400:end-200), LineWidth=1.2);
    title("t = 2");
    res = mm_iter(u0, 1, 0, 6, h, tau, 4, false);
    subplot(1, 3, 2);
    plot(0:h:1, u0(0:h:1), 0:h:1, res(end-400:end-200), LineWidth=1.2);
    title("t = 4");
    res = mm_iter(u0, 1, 0, 10, h, tau, 8, false);
    subplot(1, 3, 3);
    plot(0:h:1, u0(0:h:1), 0:h:1, res(end-400:end-200), LineWidth=1.2);
    title("t = 8");
end

if tt(4)
    xi = @(x) (x >= -0.7) .* (x - 0.3) + (x < -0.7) .* (x + 1.7);
    u0 = @(x) (xi(x) <= -1/3) .* (-xi(x) .* sin(1.5 * pi * xi(x) .^ 2)) ...
        + (abs(xi(x)) < -1/3) .* abs(sin(2 * pi * xi(x))) ...
        + (xi(x) >= 1/3) .* (2 * xi(x) - 1 - sin(3 * pi * xi(x)) / 6);
    h = 1 / 250; tau = h * 0.6;
    figure();
    res = mm_iter(u0, 1, -1, 1, h, tau, 2, true);
    subplot(1, 3, 1);
    plot(-1:h:1, u0(-1:h:1), -1:h:1, res, LineWidth=1.2);
    title("t = 2");
    res = mm_iter(u0, 1, -1, 1, h, tau, 4, true);
    subplot(1, 3, 2);
    plot(-1:h:1, u0(-1:h:1), -1:h:1, res, LineWidth=1.2);
    title("t = 4");
    res = mm_iter(u0, 1, -1, 1, h, tau, 8, true);
    subplot(1, 3, 3);
    plot(-1:h:1, u0(-1:h:1), -1:h:1, res, LineWidth=1.2);
    title("t = 8");
end


