function res = mm_iter(u0, a, x0, x1, h, tau, T, cyc)
    % cyc means cyc border condition 
    lam = (T / round(T / tau)) / h;
    x = x0:h:x1;
    res = u0(x);
    du = res;
    s = res;
    dups = res;
    for i = 1:int32(T / tau)
        du(1:end-1) = res(2:end) - res(1:end-1);
        du(end) = du(1);
        s(2:end) = minmod(du(2:end), du(1:end-1));
        s(1) = s(end);
        ups = res + 0.5 * s;
        dups(2:end) = ups(2:end) - ups(1:end-1);
        dups(1) = dups(end);
        res(3:end-1) = res(3:end-1) - a * lam * dups(3:end-1);
        if cyc
            res(1) = res(1) - a * lam * dups(1);
            res(2) = res(2) - a * lam * dups(2);
            res(end) = res(end) - a * lam * dups(end);
        end
    end
end

function res = minmod(a, b)
    res = (sign(a) + sign(b)) / 2 .* min(abs(a), abs(b));
end