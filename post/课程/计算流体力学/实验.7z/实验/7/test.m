clear;
close all;

tt = [1, 1, 1, 1];

if tt(1)
    u0 = @(x, y) (x >= 0) * (y >= 0) * -1 ...
        + (x < 0) * (y >= 0) * -0.2 ...
        + (x < 0) * (y < 0) * 0.5 ...
        + (x >= 0) * (y < 0) * 0.8;
    x0 = -2; x1 = 2; y0 = -2; y1 = 2;
    h = 0.03; tau = 0.015; T = 1;

    res = LF_2d(u0, x0, x1, y0, y1, h, tau, T);
    figure();
    imagesc([x0, x1], [y1, y0], flip(res', 1), [-1, 0.8]);
    set(gca, 'YDir', 'normal');
    xlabel("x");
    ylabel("y");
    title("LF");
    colorbar;
    res = UW_2d(u0, x0, x1, y0, y1, h, tau, T);
    figure();
    imagesc([x0, x1], [y1, y0], flip(res', 1), [-1, 0.8]);
    set(gca, 'YDir', 'normal');
    xlabel("x");
    ylabel("y");
    title("upwind");
    colorbar;
    res = LW_2d(u0, x0, x1, y0, y1, h, tau, T);
    figure();
    imagesc([x0, x1], [y1, y0], flip(res', 1), [-1, 0.8]);
    set(gca, 'YDir', 'normal');
    xlabel("x");
    ylabel("y");
    title("LW");
    colorbar;
end

if tt(2)
    u0 = @(x, y) (x >= 0) * (y >= 0) * -0.2 ...
        + (x < 0) * (y >= 0) * -1 ...
        + (x < 0) * (y < 0) * 0.5 ...
        + (x >= 0) * (y < 0) * 0.8;
    x0 = -2; x1 = 2; y0 = -2; y1 = 2;
    h = 0.03; tau = 0.015; T = 1;

    res = LF_2d(u0, x0, x1, y0, y1, h, tau, T);
    figure();
    imagesc([x0, x1], [y1, y0], flip(res', 1), [-1, 0.8]);
    set(gca, 'YDir', 'normal');
    xlabel("x");
    ylabel("y");
    title("LF");
    colorbar;
    res = UW_2d(u0, x0, x1, y0, y1, h, tau, T);
    figure();
    imagesc([x0, x1], [y1, y0], flip(res', 1), [-1, 0.8]);
    set(gca, 'YDir', 'normal');
    xlabel("x");
    ylabel("y");
    title("upwind");
    colorbar;
    res = LW_2d(u0, x0, x1, y0, y1, h, tau, T);
    figure();
    imagesc([x0, x1], [y1, y0], flip(res', 1), [-1, 0.8]);
    set(gca, 'YDir', 'normal');
    xlabel("x");
    ylabel("y");
    title("LW");
    colorbar;
end

if tt(3)
    r0 = @(x) (x <= 0.5) * 0.445 + (x > 0.5) * 0.5;
    m0 = @(x) (x <= 0.5) * 0.311;
    E0 = @(x) (x <= 0.5) * 8.928 + (x > 0.5) * 1.4275;
    x0 = 0; x1 = 1;
    h = 0.003; tau = 0.0004;
    1; T = 0.14;

    res = LF_1d(r0, m0, E0, x0, x1, h, tau, T);
    figure;
    subplot(3, 1, 1);
    plot(x0:h:x1, res(1, :), LineWidth=1.5, Color="g");
    title("\rho");
    subplot(3, 1, 2);
    plot(x0:h:x1, res(2, :) ./ res(1, :), LineWidth=1.5, Color="b");
    title("u");
    subplot(3, 1, 3);
    plot(x0:h:x1, res(3, :), LineWidth=1.5, Color = "r");
    title("E");

    res = LW_1d(r0, m0, E0, x0, x1, h, tau, T);
    figure;
    subplot(3, 1, 1);
    plot(x0:h:x1, res(1, :), LineWidth=1.5, Color="g");
    title("\rho");
    subplot(3, 1, 2);
    plot(x0:h:x1, res(2, :) ./ res(1, :), LineWidth=1.5, Color="b");
    title("u");
    subplot(3, 1, 3);
    plot(x0:h:x1, res(3, :), LineWidth=1.5, Color = "r");
    title("E");

    res = MC_1d(r0, m0, E0, x0, x1, h, tau, T);
    figure;
    subplot(3, 1, 1);
    plot(x0:h:x1, res(1, :), LineWidth=1.5, Color="g");
    title("\rho");
    subplot(3, 1, 2);
    plot(x0:h:x1, res(2, :) ./ res(1, :), LineWidth=1.5, Color="b");
    title("u");
    subplot(3, 1, 3);
    plot(x0:h:x1, res(3, :), LineWidth=1.5, Color = "r");
    title("E");
end

if tt(4)
    r0 = @(x) (x <= 0.3) * 1 + (x > 0.3) * 0.125;
    m0 = @(x) x * 0;
    E0 = @(x) (x <= 0.3) * 2.5 + (x > 0.3) * 0.25;
    x0 = 0; x1 = 1;
    h = 0.0001; tau = 0.00003; T = 0.2;

    res = LF_1d(r0, m0, E0, x0, x1, h, tau, T);
    figure;
    subplot(3, 1, 1);
    plot(x0:h:x1, res(1, :), LineWidth=1.5, Color="g");
    title("\rho");
    subplot(3, 1, 2);
    plot(x0:h:x1, res(2, :) ./ res(1, :), LineWidth=1.5, Color="b");
    title("u");
    subplot(3, 1, 3);
    plot(x0:h:x1, res(3, :), LineWidth=1.5, Color = "r");
    title("E");

    res = LW_1d(r0, m0, E0, x0, x1, h, tau, T);
    figure;
    subplot(3, 1, 1);
    plot(x0:h:x1, res(1, :), LineWidth=1.5, Color="g");
    title("\rho");
    subplot(3, 1, 2);
    plot(x0:h:x1, res(2, :) ./ res(1, :), LineWidth=1.5, Color="b");
    title("u");
    subplot(3, 1, 3);
    plot(x0:h:x1, res(3, :), LineWidth=1.5, Color = "r");
    title("E");

    res = MC_1d(r0, m0, E0, x0, x1, h, tau, T);
    figure;
    subplot(3, 1, 1);
    plot(x0:h:x1, res(1, :), LineWidth=1.5, Color="g");
    title("\rho");
    subplot(3, 1, 2);
    plot(x0:h:x1, res(2, :) ./ res(1, :), LineWidth=1.5, Color="b");
    title("u");
    subplot(3, 1, 3);
    plot(x0:h:x1, res(3, :), LineWidth=1.5, Color = "r");
    title("E");
end