function res = LF_1d(r0, m0, E0, x0, x1, h, tau, T)
    lam = (T / round(T / tau)) / h;
    x = x0:h:x1;
    res(1, :) = r0(x);
    res(2, :) = m0(x);
    res(3, :) = E0(x);
    f1 = @(r) r(2,:);
    f2 = @(r) 0.8 * r(2,:) .^ 2 ./ r(1,:) + 0.4 * r(3,:);
    f3 = @(r) 1.4 * r(2,:) .* r(3,:) ./ r(1,:) - 0.2 * r(2,:) .^ 3 ./ r(1,:) .^ 2;
    n_res = res;
    for i = 1:int32(T / tau)
        n_res(1, 2:end-1) = (res(1, 1:end-2) + res(1, 3:end)) / 2 - ...
            lam / 2 * (f1(res(:, 3:end)) - f1(res(:, 1:end-2)));
        n_res(2, 2:end-1) = (res(2, 1:end-2) + res(2, 3:end)) / 2 - ...
            lam / 2 * (f2(res(:, 3:end)) - f2(res(:, 1:end-2)));
        n_res(3, 2:end-1) = (res(3, 1:end-2) + res(3, 3:end)) / 2 - ...
            lam / 2 * (f3(res(:, 3:end)) - f3(res(:, 1:end-2)));
        res = n_res;
    end
end