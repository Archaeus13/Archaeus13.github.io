function res = LW_2d(u0, x0, x1, y0, y1, h, tau, T)
    lam = (T / round(T / tau)) / h;
    x = x0:h:x1; y = y0:h:y1;
    res = zeros(length(x), length(y));
    for i = 1:length(x)
        for j = 1:length(y)
            res(i, j) = u0(x(i), y(j));
        end
    end
    for i = 1:int32(T / tau)
        f = res .^ 2 / 2;
        Dfx = f(3:end, :) - f(1:end-2, :);
        Dfy = f(:, 3:end) - f(:, 1:end-2);
        ujp = (res(1:end-1, :) + res(2:end, :)) / 2;
        ukp = (res(:, 1:end-1) + res(:, 2:end)) / 2;
        fxx = ujp(2:end, :) .^ 2 .* (res(3:end, :) - res(2:end-1, :)) ...
            - ujp(1:end-1, :) .^ 2 .* (res(2:end-1, :) - res(1:end-2, :));
        fyy = ukp(:, 2:end) .^ 2 .* (res(:, 3:end) - res(:, 2:end-1)) ...
            - ukp(:, 1:end-1) .^ 2 .* (res(:, 2:end-1) - res(:, 1:end-2));
        fxy2 = ujp(2:end, 2:end-1) .^ 2 .* (ujp(2:end, 3:end) - ujp(2:end, 1:end-2)) ...
            - ujp(1:end-1, 2:end-1) .^ 2 .* (ujp(1:end-1, 3:end) - ujp(1:end-1, 1:end-2));
        fyx2 = ukp(2:end-1, 2:end) .^ 2 .* (ukp(3:end, 2:end) - ukp(1:end-2, 2:end)) ...
            - ukp(2:end-1, 1:end-1) .^ 2 .* (ukp(3:end, 1:end-1) - ukp(1:end-2, 1:end-1));
        res(2:end-1, :) = res(2:end-1, :) - lam / 2 * Dfx + lam ^ 2 / 2 * fxx;
        res(:, 2:end-1) = res(:, 2:end-1) - lam / 2 * Dfy + lam ^ 2 / 2 * fyy;
        res(2:end-1, 2:end-1) = res(2:end-1, 2:end-1) + lam ^ 2 / 4 * (fxy2 + fyx2);
    end
end