function res = UW_2d(u0, x0, x1, y0, y1, h, tau, T)
    lam = (T / round(T / tau)) / h;
    x = x0:h:x1; y = y0:h:y1;
    res = zeros(length(x), length(y));
    for i = 1:length(x)
        for j = 1:length(y)
            res(i, j) = u0(x(i), y(j));
        end
    end
    for i = 1:int32(T / tau)
        f = res .^ 2 / 2;
        u_jm = res(1:end-1, :) + res(2:end, :);
        u_km = res(:, 1:end-1) + res(:, 2:end);
        f_jm = (u_jm > 0) .* f(1:end-1, :) + (u_jm <= 0) .* f(2:end, :); 
        f_km = (u_km > 0) .* f(:, 1:end-1) + (u_km <= 0) .* f(:, 2:end); 
        res(2:end-1, :) = res(2:end-1, :) ...
            - lam * (f_jm(2:end, :) - f_jm(1:end-1, :));
        res(:, 2:end-1) = res(:, 2:end-1) ...
            - lam * (f_km(:, 2:end) - f_km(:, 1:end-1));
    end
end