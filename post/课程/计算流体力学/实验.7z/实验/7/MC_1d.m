function res = MC_1d(r0, m0, E0, x0, x1, h, tau, T)
    lam = (T / round(T / tau)) / h;
    x = x0:h:x1;
    res(1, :) = r0(x);
    res(2, :) = m0(x);
    res(3, :) = E0(x);
    f1 = @(r) r(2,:);
    f2 = @(r) 0.8 * r(2,:) .^ 2 ./ r(1,:) + 0.4 * r(3,:);
    f3 = @(r) 1.4 * r(2,:) .* r(3,:) ./ r(1,:) - 0.2 * r(2,:) .^ 3 ./ r(1,:) .^ 2;
    n_res = res;
    flag = true;
    for i = 1:int32(T / tau)
        if flag
            F1 = 3:length(x);
            B1 = 2:length(x) - 1;
            F2 = 2:length(x) - 1;
            B2 = 1:length(x) - 2;
        else
            F2 = 3:length(x);
            B2 = 2:length(x) - 1;
            F1 = 2:length(x) - 1;
            B1 = 1:length(x) - 2;
        end
        flag = ~flag;
        n_res(1, 2:end-1) = res(1, 2:end-1) - ...
            lam * (f1(res(:, F1)) - f1(res(:, B1)));
        n_res(2, 2:end-1) = res(2, 2:end-1) - ...
            lam * (f2(res(:, F1)) - f2(res(:, B1)));
        n_res(3, 2:end-1) = res(3, 2:end-1) - ...
            lam * (f3(res(:, F1)) - f3(res(:, B1)));
        res(1, 2:end-1) = (res(1, 2:end-1) + n_res(1, 2:end-1)) / 2 - ...
            lam / 2 * (f1(n_res(:, F2)) - f1(n_res(:, B2)));
        res(2, 2:end-1) = (res(2, 2:end-1) + n_res(2, 2:end-1)) / 2 - ...
            lam / 2 * (f2(n_res(:, F2)) - f2(n_res(:, B2)));
        res(3, 2:end-1) = (res(3, 2:end-1) + n_res(3, 2:end-1)) / 2 - ...
            lam / 2 * (f3(n_res(:, F2)) - f3(n_res(:, B2)));
    end
end