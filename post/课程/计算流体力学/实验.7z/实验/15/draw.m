% plot figures in Homework 15 Exercise 4

figure();
x = 0:0.01:1;
for P = -2:1:2
    plot(x, x + P / 2 * x .* (x - 1), LineWidth=1.5);
    hold on;
end
legend("P=-2", "P=-1", "P=0", "P=1", "P=2", Location="northwest");
title("\xi(x) for Different P");

P = -2:0.02:2;
a = P / 2; b = 1 - P / 2;
c1 = -0.25;
x1 = (-b + sqrt(b .^ 2 - 4 * c1 * a)) ./ (2 * a);
x1(P == 0) = -c1;
c2 = -0.5;
x2 = (-b + sqrt(b .^ 2 - 4 * c2 * a)) ./ (2 * a);
x2(P == 0) = -c2;
c3 = -0.75;
x3 = (-b + sqrt(b .^ 2 - 4 * c3 * a)) ./ (2 * a);
x3(P == 0) = -c3;
figure();
plot(P, x1, LineWidth=1.5); hold on;
plot(P, x2, LineWidth=1.5); hold on;
plot(P, x3, LineWidth=1.5);
legend("x_1", "x_2", "x_3", Location="northwest");
title("grid point for Different P");