function res = weno(u0, h, tau, T, if_cyc, RK)
    % RK: 1 or 3 or 4
    if ~exist("RK", "var")
        RK = 3;
    end

    steps = int32(T / tau);
    u = [0, 0, 0, u0(-1:h:1), 0, 0, 0]; % 7-points scheme, need 3 outsiders
    deal_border(u, if_cyc);
    lam = tau / h;

    u1 = zeros(1, length(u));
    u2 = zeros(1, length(u));
    u3 = zeros(1, length(u));
    u4 = zeros(1, length(u));
    for i = 1:steps
        switch RK
            case 3
                u1(4:end-3) = u(4:end-3) + lam * hF(u);
                u1 = deal_border(u1, if_cyc);
                u2(4:end-3) = (u(4:end-3) * 3 + u1(4:end-3)) / 4 ...
                    + lam / 4 * hF(u1);
                u2 = deal_border(u2, if_cyc);
                u(4:end-3) = (u(4:end-3) + u2(4:end-3) * 2) / 3 ...
                    + lam * 2 / 3 * hF(u2);
                u = deal_border(u, if_cyc);
            case 4
                u1(4:end-3) = u(4:end-3) + lam / 2 * hF(u);
                u1 = deal_border(u1, if_cyc);
                u2(4:end-3) = u(4:end-3) + lam / 2 * hF(u1);
                u2 = deal_border(u2, if_cyc);
                u3(4:end-3) = u(4:end-3) + lam * hF(u2);
                u3 = deal_border(u3, if_cyc);
                u4(4:end-3) = u(4:end-3) + lam / 2 * hF(u3);
                u4 = deal_border(u4, if_cyc);
                u = (u1 + 2 * u2 + u3 + u4 - 2 * u) / 3;
            otherwise
                u(4:end-3) = u(4:end-3) + lam * hF(u);
                u = deal_border(u, if_cyc);
        end
    end
    res = u(4:end-3);
end

function u = deal_border(u, if_cyc)
    if if_cyc
        u(end-2:end) = u(5:7);
        u(1:3) = u(end-6:end-4);
    else
        u(end-2:end) = u(end-3);
        u(1:3) = u(4);
    end
end

function res = hF(u)
    f = u .^ 2 / 2;

    al = max(abs(u));

    fp = (f + al) / 2;
    fm = (f - al) / 2;

    % Df(i) means Df at i + 1/2
    Dfp = fp(2:end) - fp(1:end-1);
    Dfm = fm(2:end) - fm(1:end-1);

    phip = phi(Dfp(1:end-3), Dfp(2:end-2), Dfp(3:end-1), Dfp(4:end));
    phim = phi(Dfm(4:end), Dfm(3:end-1), Dfm(2:end-2), Dfm(1:end-3));
    hfp = (- fp(2:end-3) + 7 * fp(3:end-2) ...
        + 7 * fp(4:end-1) - fp(5:end)) / 12 - phip;
    hfm = (- fm(1:end-4) + 7 * fm(2:end-3) ...
        + 7 * fm(3:end-2) - fm(4:end-1)) / 12 + phim;
    Dhfp = hfp(2:end) - hfp(1:end-1);
    Dhfm = hfm(2:end) - hfm(1:end-1);
    res = - Dhfp(1:end-1) - Dhfm(2:end);
end

function res = phi(a, b, c, d)
    eps = 1e-6;
    IS0 = 13 * (a - b) .^ 2 + 3 * (a - 3 * b) .^ 2;
    IS1 = 13 * (b - c) .^ 2 + 3 * (b + c) .^ 2;
    IS2 = 13 * (c - d) .^ 2 + 3 * (3 * c - d) .^ 2;
    al0 = 1 ./ (eps + IS0) .^ 2;
    al1 = 6 ./ (eps + IS1) .^ 2;
    al2 = 3 ./ (eps + IS2) .^ 2;
    S = al0 + al1 + al2;
    w0 = al0 ./ S;
    w2 = al2 ./ S;
    res = w0 .* (a - 2 * b + c) / 3 + (w2 - 0.5) .* (b - 2 * c + d) / 6;
end