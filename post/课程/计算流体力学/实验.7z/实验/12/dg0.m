function res = dg0(u0, h, tau, T, if_cyc, RK, flux)
    % RK: 1 or 3 or 4
    % flux: uw (upwind) or G (Godunov)
    if ~exist("flux", "var")
        flux = "G";
    end
    if ~exist("RK", "var")
        RK = 3;
    end

    %% preperation for Gauss integration

    % g1, g2, g3 means weight / h to count average int
    % also doesn't change with j

    g1 = 5 / 18; g2 = 4 / 9; g3 = g1;

    %% initialization
    
    x = -1:h:1;
    xmid = (x(2:end) + x(1:end-1)) / 2;
    bias = sqrt(3 / 5) * h / 2;
    u = zeros(1, length(x) + 1);
    u(2:end-1) = g1 * u0(xmid - bias) + g2 * u0(xmid) + g3 * u0(xmid + bias);
    
    u = deal_border(u, if_cyc);

    %% iterate
    
    u1 = zeros(1, length(u));
    u2 = zeros(1, length(u));
    u3 = zeros(1, length(u));
    u4 = zeros(1, length(u));

    steps = int32(T / tau);
    lam = tau / h;

    for i = 1:steps
        switch RK
            case 3
                u1(2:end-1) = u(2:end-1) + lam * hF(u, flux);
                u1 = deal_border(u1, if_cyc);
                u2(2:end-1) = (u(2:end-1) * 3 + u1(2:end-1)) / 4 ...
                    + lam / 4 * hF(u1, flux);
                u2 = deal_border(u2, if_cyc);
                u(2:end-1) = (u(2:end-1) + u2(2:end-1) * 2) / 3 ...
                    + lam * 2 / 3 * hF(u2, flux);
                u = deal_border(u, if_cyc);
            case 4
                u1(2:end-1) = u(2:end-1) + lam / 2 * hF(u, flux);
                u1 = deal_border(u1, if_cyc);
                u2(2:end-1) = u(2:end-1) + lam / 2 * hF(u1, flux);
                u2 = deal_border(u2, if_cyc);
                u3(2:end-1) = u(2:end-1) + lam * hF(u2, flux);
                u3 = deal_border(u3, if_cyc);
                u4(2:end-1) = u(2:end-1) + lam / 2 * hF(u3, flux);
                u4 = deal_border(u4, if_cyc);
                u = (u1 + 2 * u2 + u3 + u4 - 2 * u) / 3;
            otherwise
                u(2:end-1) = u(2:end-1) + lam * hF(u, flux);
                u = deal_border(u, if_cyc);
        end
    end
    res = u(2:end-1);
end

function u = deal_border(u, if_cyc)
    if if_cyc
        u(1) = u(end-1);
        u(end) = u(2);
    else
        u(1) = u(2);
        u(end) = u(end-1);
    end
end

function res = hF(u, flux)
    %% count f hat
    L = u(1:end-1);
    R = u(2:end);

    if flux == "uw"
        M = (L + R) / 2;
        fh = ((M >= 0) .* L .^ 2 + (M < 0) .* R .^ 2) / 2;
    else
        L2 = L .^ 2; R2 = R .^ 2;
        fh = ((L > R) .* max(L2, R2) ...
            + (L <= R) .* (L .* R > 0) .* min(L2, R2)) / 2;
    end

    %% count things about f hat
    res = fh(1:end-1) - fh(2:end);
end