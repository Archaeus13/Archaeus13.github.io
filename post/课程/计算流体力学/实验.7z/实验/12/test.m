%% 1D Burgers
%{
u0 = @(x) double(x < 0);
h = 0.04;
tau = 0.0005;
T = 0.8;
x = -1:h:1;
if_cyc = false;
RK = 3;
range = [-1, 1, min(u0(x)), max(u0(x))];

% test error for DG2
err = zeros(1, 4);
ureal = @(x) double (x < 0.4);
for i = 1:4
    h = 0.04 / 2 ^ i;
    x = -1:h:1;
    res = dg2(u0, h, tau, T, if_cyc, RK);
    res = sum(res, 1);
    err(i) = sqrt(mean((res - ureal(x(2:end))) .^ 2));
end

plot(log(err));

% compare different methods
figure();
subplot(2, 2, 1);
plot(x, weno(u0, h, tau, T, if_cyc, RK), LineWidth=1.5);
axis(range);
title("WENO5");
subplot(2, 2, 2);
plot(x(2:end), dg0(u0, h, tau, T, if_cyc, RK), LineWidth=1.5);
axis(range);
title("DG0");
subplot(2, 2, 3);
plot(x(2:end), sum(dg1(u0, h, tau, T, if_cyc, RK), 1), LineWidth=1.5);
axis(range);
title("DG1");
subplot(2, 2, 4);
plot(x(2:end), sum(dg2(u0, h, tau, T, if_cyc, RK), 1), LineWidth=1.5);
axis(range);
title("DG2");
%}

%% 2D Euler
res = ult_ramp(0.01, 0.01, 0.0001, 0.2, @(x)abs(x), "1");
rho = reshape(res(1, :, :), size(res, 2), size(res, 3));
m = reshape(res(2, :, :), size(res, 2), size(res, 3));
n = reshape(res(3, :, :), size(res, 2), size(res, 3));
E = reshape(res(4, :, :), size(res, 2), size(res, 3));

figure();

subplot(2, 2, 1);
imagesc([0, 4], [1, 0], flip(rho', 1));
set(gca, 'YDir', 'normal');
colorbar;
xlabel("x");
ylabel("y");
title("\rho");

subplot(2, 2, 2);
imagesc([0, 4], [1, 0], flip((m ./ rho)', 1));
set(gca, 'YDir', 'normal');
colorbar;
xlabel("x");
ylabel("y");
title("u");

subplot(2, 2, 3);
imagesc([0, 4], [1, 0], flip((n ./ rho)', 1));
set(gca, 'YDir', 'normal');
colorbar;
xlabel("x");
ylabel("y");
title("v");

subplot(2, 2, 4);
imagesc([0, 4], [1, 0], flip(E', 1));
set(gca, 'YDir', 'normal');
colorbar;
xlabel("x");
ylabel("y");
title("E");
