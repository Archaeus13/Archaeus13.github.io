function res = ult_ramp(hx, hy, tau, T, Q, type)

    % initialize result
    x = 0:hx:4;
    y = 0:hy:1;
    
    lx = tau / hx;
    ly = tau / hy;

    M = length(x);
    N = length(y);

    X = repmat(x', 1, N);
    Y = repmat(y, M, 1);

    L = Y >= (sqrt(3) * (X - 1/6));
    
    % A(j, 1) means A with index -2
    % A(j, 2) means A with index -1
    % to deal with reflection border
    Mx = floor(1 / 6 / hx) + 1; % before Nx const, after Nx reflection
    % disp(Mx);
    
    res = zeros(4, M, N + 2);
    res(1, :, 3:end) = L * 8 + ~L * 1.4; % rho
    res(2, :, 3:end) = L * 57.1597; % m = rho u
    res(3, :, 3:end) = L * -33.0012; % n = rho v
    res(4, :, 3:end) = L * 563.544 + ~L * 2.5; % E
    res = deal_border(res, 0, Mx, hx, hy, M);
    
    flag = true;
    count = 1;
    for t = tau:tau:T
        % parting Ly into left and right to deal with different border
        if flag
            res(:, :, 3:end-2) = Lx(res(:, :, 3:end-2), lx, Q, type);
            res = deal_border(res, t, Mx, hx, hy, M);
            res(:, 3:Mx, 3:end) = Ly(res(:, 3:Mx, 3:end), ly, Q, type);
            res(:, Mx+1:end-2, :) = Ly(res(:, Mx+1:end-2, :), ly, Q, type);
        else
            res(:, 3:Mx, 3:end) = Ly(res(:, 3:Mx, 3:end), ly, Q, type);
            res(:, Mx+1:end-2, :) = Ly(res(:, Mx+1:end-2, :), ly, Q, type);
            res(:, :, 3:end-2) = Lx(res(:, :, 3:end-2), lx, Q, type);
            res = deal_border(res, t, Mx, hx, hy, M);
        end
        flag = ~flag;

        count = count + 1;
        if mod(count, 50) == 0
            disp(count);
        end
    end

    res = res(:, :, 3:end);
end

function res = deal_border(res, t, Mx, hx, hy, M)
    % border at x > 1 / 6, y < 0
    res(:, Mx+1:end-2, 1) = res(:, Mx+1:end-2, 5);
    res(:, Mx+1:end-2, 2) = res(:, Mx+1:end-2, 4);
    res(3, Mx+1:end-2, 1:2) = -res(3, Mx+1:end-2, 1:2);

    % border at y = 1
    x_m = (1 + 20 * t) / sqrt(3) + 1 / 6;
    x_lm = (1 - hy + 20 * t) / sqrt(3) + 1 / 6;
    M1 = floor(x_m / hx) + 1;
    M2 = floor(x_lm / hx) + 1;
    res(:, Mx+1:M1, end) = repmat([8; 57.1597; -33.0012; 563.544], 1, M1 - Mx);
    res(:, M1+1:M-2, end) = repmat([1.4; 0; 0; 2.5], 1, M - 2 - M1);
    res(:, Mx+1:M2, end-1) = repmat([8; 57.1597; -33.0012; 563.544], 1, M2 - Mx);
    res(:, M2+1:M-2, end-1) = repmat([1.4; 0; 0; 2.5], 1, M - 2 - M2);
end

function res = Lx(res, lam, Q, type)
        % 5-point scheme
        % iter for all ys in res

        M = size(res, 2);
        N = size(res, 3);

        % get rho, m, n, E
        r = reshape(res(1, :, :), M, N);
        m = reshape(res(2, :, :), M, N);
        n = reshape(res(3, :, :), M, N);
        E = reshape(res(4, :, :), M, N);

        % initialize vars
        f = zeros(4, M, N);
        R1 = ones(4, M - 1, N);
        R2 = ones(4, M - 1, N);
        R3 = ones(4, M - 1, N);
        R4 = ones(4, M - 1, N);

        %% count f, f(*, j, k) is f at point j, k
        % together with u and H
        
        u = m ./ r;
        v = n ./ r;
        p = 0.4 * E - 0.2 * r .* (u .^ 2 + v .^ 2);
        H = (E + p) ./ r;

        f(1, :, :) = m;
        f(2, :, :) = m .* u + p;
        f(3, :, :) = m .* v;
        f(4, :, :) = m .* H;
        
        
        %% count a and R, R(*, j, k) is R at point j + 1/2, k
        % also a, uh, vh, Hh, ch, al, gt, s, nu

        % uh, vh
        sr = sqrt(r);
        sra = sr(1:end-1, :) + sr(2:end, :);

        sru = sr .* u;
        srua = sru(1:end-1, :) + sru(2:end, :);
        uh = srua ./ sra;

        srv = sr .* v;
        srva = srv(1:end-1, :) + srv(2:end, :);
        vh = srva ./ sra;

        % Hh
        srH = sr .* H;
        srHa = srH(1:end-1, :) + srH(2:end, :);
        Hh = srHa ./ sra;

        % ch
        uu = uh .^ 2;
        uuvvd2 = (uu + vh .^ 2) / 2;
        ch = sqrt(0.4 * (Hh - uuvvd2));

        % a
        a1 = uh - ch;
        a2 = uh;
        a3 = uh;
        a4 = uh + ch;

        % R
        uhch = uh .* ch;
        
        R1(2, :, :) = a1;
        R1(3, :, :) = vh;
        R1(4, :, :) = Hh - uhch;

        R2(2, :, :) = uh;
        R2(3, :, :) = vh;
        R2(4, :, :) = uuvvd2;

        R3(1, :, :) = 0;
        R3(2, :, :) = 0;
        R3(4, :, :) = vh;

        R4(2, :, :) = a4;
        R4(3, :, :) = vh;
        R4(4, :, :) = Hh + uhch;

        %% count al

        rd = r(2:end, :) - r(1:end-1, :);
        md = m(2:end, :) - m(1:end-1, :);
        nd = n(2:end, :) - n(1:end-1, :);
        Ed = E(2:end, :) - E(1:end-1, :);

        al3 = nd - vh .* rd;
        al2 = 0.4 * (rd .* (Hh - uu) + uh .* md - Ed + al3 .* vh) ./ ch .^ 2;
        al1 = ((rd .* a4 - md) ./ ch - al2) / 2;
        al4 = rd - al1 - al2;

        %% count nu, gt and s

        nu1 = lam * a1;
        nu2 = lam * a2;
        nu3 = lam * a3;
        nu4 = lam * a4;

        gt1 = (Q(nu1) - nu1 .^ 2) .* al1 / 2;
        gt2 = (Q(nu2) - nu2 .^ 2) .* al2 / 2;
        gt3 = (Q(nu3) - nu3 .^ 2) .* al3 / 2;
        gt4 = (Q(nu4) - nu4 .^ 2) .* al4 / 2;
        s1 = sign(gt1);
        s2 = sign(gt2);
        s3 = sign(gt3);
        s4 = sign(gt4);


        %% count be
        % be(j, k) is be at point j + 3/2, k
        if type == "2"
            % G(j, k) is G at point j + 3/2, k; also fb
            G1 = s1(2:end-1, :) .* max(0, ...
                min(s1(2:end-1, :) .* gt1(1:end-2, :), ...
                min(abs(gt1(2:end-1, :)), s1(2:end-1, :) .* gt1(3:end, :))));
            G2 = s2(2:end-1, :) .* max(0, ...
                min(s2(2:end-1, :) .* gt2(1:end-2, :), ...
                min(abs(gt2(2:end-1, :)), s2(2:end-1, :) .* gt2(3:end, :))));
            G3 = s3(2:end-1, :) .* max(0, ...
                min(s3(2:end-1, :) .* gt3(1:end-2, :), ...
                min(abs(gt3(2:end-1, :)), s3(2:end-1, :) .* gt3(3:end, :))));
            G4 = s4(2:end-1, :) .* max(0, ...
                min(s4(2:end-1, :) .* gt4(1:end-2, :), ...
                min(abs(gt4(2:end-1, :)), s4(2:end-1, :) .* gt4(3:end, :))));

            be1 = Q(nu1(2:end-1, :)) .* al1(2:end-1, :) - 2 * G1;
            be2 = Q(nu2(2:end-1, :)) .* al2(2:end-1, :) - 2 * G2;
            be3 = Q(nu3(2:end-1, :)) .* al3(2:end-1, :) - 2 * G3;
            be4 = Q(nu4(2:end-1, :)) .* al4(2:end-1, :) - 2 * G4;
        else
            % g(j, k) is g at point j + 1, k
            g1 = s1(2:end, :) .* max(0, ...
                min(abs(gt1(2:end, :)), s1(2:end, :) .* gt1(1:end-1, :)));
            g2 = s2(2:end, :) .* max(0, ...
                min(abs(gt2(2:end, :)), s2(2:end, :) .* gt2(1:end-1, :)));
            g3 = s3(2:end, :) .* max(0, ...
                min(abs(gt3(2:end, :)), s3(2:end, :) .* gt3(1:end-1, :)));
            g4 = s4(2:end, :) .* max(0, ...
                min(abs(gt4(2:end, :)), s4(2:end, :) .* gt4(1:end-1, :)));

            if type == "1C"
                % modify g2 and g3
                ss2 = sign(al2);
                si2 = (1 - Q(nu2)) / 2;
                gbb2 = ss2(2:end, :) .* max(0, ...
                    min(ss2(2:end, :) .* si2(1:end-1, :) .* al2(1:end-1, :), ...
                    abs(al2(2:end, :) .* si2(2:end, :))));
                div2 = abs(al2(2:end, :)) + abs(al2(1:end-1, :));
                th2 = abs(al2(2:end, :) - al2(1:end-1, :)) ./ div2;
                th2(ss2(2:end, :) == 0) = 0;
                g2 = g2 + th2 .* gbb2;

                ss3 = sign(al3);
                si3 = (1 - Q(nu3)) / 2;
                gbb3 = ss3(2:end, :) .* max(0, ...
                    min(ss3(2:end, :) .* si3(1:end-1, :) .* al3(1:end-1, :), ...
                    abs(al3(2:end, :) .* si3(2:end, :))));
                div3 = abs(al3(2:end, :)) + abs(al3(1:end-1, :));
                th3 = abs(al3(2:end, :) - al3(1:end-1, :)) ./ div3;
                th3(ss3(2:end, :) == 0) = 0;
                g3 = g3 + th3 .* gbb3;
            end

            % gam(j, k) is gam at point j + 3/2, k
            gam1 = (g1(2:end, :) - g1(1:end-1, :)) ./ al1(2:end-1, :);
            gam1(al1(2:end-1, :) == 0) = 0;
            gam2 = (g2(2:end, :) - g2(1:end-1, :)) ./ al2(2:end-1, :);
            gam2(al2(2:end-1, :) == 0) = 0;
            gam3 = (g3(2:end, :) - g3(1:end-1, :)) ./ al3(2:end-1, :);
            gam3(al3(2:end-1, :) == 0) = 0;
            gam4 = (g4(2:end, :) - g4(1:end-1, :)) ./ al4(2:end-1, :);
            gam4(al4(2:end-1, :) == 0) = 0;

            be1 = Q(nu1(2:end-1, :) + gam1) .* al1(2:end-1, :) ...
                - g1(1:end-1, :) - g1(2:end, :);
            be2 = Q(nu2(2:end-1, :) + gam2) .* al2(2:end-1, :) ...
                - g2(1:end-1, :) - g2(2:end, :);
            be3 = Q(nu3(2:end-1, :) + gam3) .* al3(2:end-1, :) ...
                - g3(1:end-1, :) - g3(2:end, :);
            be4 = Q(nu4(2:end-1, :) + gam4) .* al4(2:end-1, :) ...
                - g4(1:end-1, :) - g4(2:end, :);
        end

        be1 = reshape(be1, 1, M-3, N);
        be2 = reshape(be2, 1, M-3, N);
        be3 = reshape(be3, 1, M-3, N);
        be4 = reshape(be4, 1, M-3, N);

        %% count iter
        fb = (f(:, 2:end-2, :) + f(:, 3:end-1, :) - ...
            (be1 .* R1(:, 2:end-1, :) + be2 .* R2(:, 2:end-1, :) ...
            + be3 .* R3(:, 2:end-1, :) + be4 .* R4(:, 2:end-1, :) ...
                ) / lam ) / 2;

        res(:, 3:end-2, :) = res(:, 3:end-2, :) ...
            - lam * (fb(:, 2:end, :) - fb(:, 1:end-1, :));
end

function res = Ly(res, lam, Q, type)
        % 5-point scheme
        % iter for all ys in res

        M = size(res, 2);
        N = size(res, 3);

        % get rho, m, n, E
        r = reshape(res(1, :, :), M, N);
        m = reshape(res(2, :, :), M, N);
        n = reshape(res(3, :, :), M, N);
        E = reshape(res(4, :, :), M, N);

        % initialize vars
        f = zeros(4, M, N);
        R1 = ones(4, M, N - 1);
        R2 = ones(4, M, N - 1);
        R3 = ones(4, M, N - 1);
        R4 = ones(4, M, N - 1);

        %% count f, f(*, j, k) is f at point j, k
        % together with u and H
        
        u = m ./ r;
        v = n ./ r;
        p = 0.4 * E - 0.2 * r .* (u .^ 2 + v .^ 2);
        H = (E + p) ./ r;

        f(1, :, :) = n;
        f(2, :, :) = n .* u;
        f(3, :, :) = n .* v + p;
        f(4, :, :) = n .* H;
        
        
        %% count a and R, R(*, j, k) is R at point j + 1/2, k
        % also a, uh, vh, Hh, ch, al, gt, s, nu

        % uh, vh
        sr = sqrt(r);
        sra = (sr(:, 1:end-1) + sr(:, 2:end)) / 2;

        sru = sr .* u;
        srua = (sru(:, 1:end-1) + sru(:, 2:end)) / 2;
        uh = srua ./ sra;

        srv = sr .* v;
        srva = (srv(:, 1:end-1) + srv(:, 2:end)) / 2;
        vh = srva ./ sra;

        % Hh
        srH = sr .* H;
        srHa = (srH(:, 1:end-1) + srH(:, 2:end)) / 2;
        Hh = srHa ./ sra;

        % ch
        vv = vh .^ 2;
        uuvvd2 = (uh .^ 2 + vv) / 2;
        ch = sqrt(0.4 * (Hh - uuvvd2));

        % a
        a1 = vh - ch;
        a2 = vh;
        a3 = vh;
        a4 = vh + ch;

        % R
        vhch = vh .* ch;
        
        R1(2, :, :) = uh;
        R1(3, :, :) = a1;
        R1(4, :, :) = Hh - vhch;

        R2(1, :, :) = 0;
        R2(3, :, :) = 0;
        R2(4, :, :) = vh;

        R3(2, :, :) = uh;
        R3(3, :, :) = vh;
        R3(4, :, :) = uuvvd2;

        R4(2, :, :) = uh;
        R4(3, :, :) = a4;
        R4(4, :, :) = Hh + vhch;

        %% count al

        rd = r(:, 2:end) - r(:, 1:end-1);
        md = m(:, 2:end) - m(:, 1:end-1);
        nd = n(:, 2:end) - n(:, 1:end-1);
        Ed = E(:, 2:end) - E(:, 1:end-1);

        al2 = md - uh .* rd;
        al3 = 0.4 * (rd .* (Hh - vv) + vh .* nd - Ed + al2 .* uh) ./ ch .^ 2;
        al1 = ((rd .* a4 - nd) ./ ch - al3) / 2;
        al4 = rd - al1 - al3;

        %% count nu, gt and s

        nu1 = lam * a1;
        nu2 = lam * a2;
        nu3 = lam * a3;
        nu4 = lam * a4;

        gt1 = (Q(nu1) - nu1 .^ 2) .* al1 / 2;
        gt2 = (Q(nu2) - nu2 .^ 2) .* al2 / 2;
        gt3 = (Q(nu3) - nu3 .^ 2) .* al3 / 2;
        gt4 = (Q(nu4) - nu4 .^ 2) .* al4 / 2;
        s1 = sign(gt1);
        s2 = sign(gt2);
        s3 = sign(gt3);
        s4 = sign(gt4);


        %% count be
        % be(j, k) is be at point j + 3/2, k
        if type == "2"
            % G(j, k) is G at point j + 3/2, k; also fb
            G1 = s1(:, 2:end-1) .* max(0, ...
                min(s1(:, 2:end-1) .* gt1(:, 1:end-2), ...
                min(abs(gt1(:, 2:end-1)), s1(:, 2:end-1) .* gt1(:, 3:end))));
            G2 = s2(:, 2:end-1) .* max(0, ...
                min(s2(:, 2:end-1) .* gt2(:, 1:end-2), ...
                min(abs(gt2(:, 2:end-1)), s2(:, 2:end-1) .* gt2(:, 3:end))));
            G3 = s3(:, 2:end-1) .* max(0, ...
                min(s3(:, 2:end-1) .* gt3(:, 1:end-2), ...
                min(abs(gt3(:, 2:end-1)), s3(:, 2:end-1) .* gt3(:, 3:end))));
            G4 = s4(:, 2:end-1) .* max(0, ...
                min(s4(:, 2:end-1) .* gt4(:, 1:end-2), ...
                min(abs(gt4(:, 2:end-1)), s4(:, 2:end-1) .* gt4(:, 3:end))));

            be1 = Q(nu1(:, 2:end-1)) .* al1(:, 2:end-1) - 2 * G1;
            be2 = Q(nu2(:, 2:end-1)) .* al2(:, 2:end-1) - 2 * G2;
            be3 = Q(nu3(:, 2:end-1)) .* al3(:, 2:end-1) - 2 * G3;
            be4 = Q(nu4(:, 2:end-1)) .* al4(:, 2:end-1) - 2 * G4;
        else
            % g(j, k) is g at point j + 1, k
            g1 = s1(:, 2:end) .* max(0, ...
                min(abs(gt1(:, 2:end)), s1(:, 2:end) .* gt1(:, 1:end-1)));
            g2 = s2(:, 2:end) .* max(0, ...
                min(abs(gt2(:, 2:end)), s2(:, 2:end) .* gt2(:, 1:end-1)));
            g3 = s3(:, 2:end) .* max(0, ...
                min(abs(gt3(:, 2:end)), s3(:, 2:end) .* gt3(:, 1:end-1)));
            g4 = s4(:, 2:end) .* max(0, ...
                min(abs(gt4(:, 2:end)), s4(:, 2:end) .* gt4(:, 1:end-1)));

            if type == "1C"
                % modify g2 and g3
                ss2 = sign(al2);
                si2 = (1 - Q(nu2)) / 2;
                gbb2 = ss2(:, 2:end) .* max(0, ...
                    min(ss2(:, 2:end) .* si2(:, 1:end-1) .* al2(:, 1:end-1), ...
                    abs(al2(:, 2:end) .* si2(:, 2:end))));
                div2 = abs(al2(:, 2:end)) + abs(al2(:, 1:end-1));
                th2 = abs(al2(:, 2:end) - al2(:, 1:end-1)) ./ div2;
                th2(ss2(:, 2:end) == 0) = 0;
                g2 = g2 + th2 .* gbb2;

                ss3 = sign(al3);
                si3 = (1 - Q(nu3)) / 2;
                gbb3 = ss3(:, 2:end) .* max(0, ...
                    min(ss3(:, 2:end) .* si3(:, 1:end-1) .* al3(:, 1:end-1), ...
                    abs(al3(:, 2:end) .* si3(:, 2:end))));
                div3 = abs(al3(:, 2:end)) + abs(al3(:, 1:end-1));
                th3 = abs(al3(:, 2:end) - al3(:, 1:end-1)) ./ div3;
                th3(ss3(:, 2:end) == 0) = 0;
                g3 = g3 + th3 .* gbb3;
            end

            % gam(j, k) is gam at point j + 3/2, k
            gam1 = (g1(:, 2:end) - g1(:, 1:end-1)) ./ al1(:, 2:end-1);
            gam1(al1(:, 2:end-1) == 0) = 0;
            gam2 = (g2(:, 2:end) - g2(:, 1:end-1)) ./ al2(:, 2:end-1);
            gam2(al2(:, 2:end-1) == 0) = 0;
            gam3 = (g3(:, 2:end) - g3(:, 1:end-1)) ./ al3(:, 2:end-1);
            gam3(al3(:, 2:end-1) == 0) = 0;
            gam4 = (g4(:, 2:end) - g4(:, 1:end-1)) ./ al4(:, 2:end-1);
            gam4(al4(:, 2:end-1) == 0) = 0;

            be1 = Q(nu1(:, 2:end-1) + gam1) .* al1(:, 2:end-1) ...
                - g1(:, 1:end-1) - g1(:, 2:end);
            be2 = Q(nu2(:, 2:end-1) + gam2) .* al2(:, 2:end-1) ...
                - g2(:, 1:end-1) - g2(:, 2:end);
            be3 = Q(nu3(:, 2:end-1) + gam3) .* al3(:, 2:end-1) ...
                - g3(:, 1:end-1) - g3(:, 2:end);
            be4 = Q(nu4(:, 2:end-1) + gam4) .* al4(:, 2:end-1) ...
                - g4(:, 1:end-1) - g4(:, 2:end);
        end

        be1 = reshape(be1, 1, M, N-3);
        be2 = reshape(be2, 1, M, N-3);
        be3 = reshape(be3, 1, M, N-3);
        be4 = reshape(be4, 1, M, N-3);

        %% count iter
        fb = (f(:, :, 2:end-2) + f(:, :, 3:end-1) - ...
            (be1 .* R1(:, :, 2:end-1) + be2 .* R2(:, :, 2:end-1) ...
            + be3 .* R3(:, :, 2:end-1) + be4 .* R4(:, :, 2:end-1) ...
                ) / lam ) / 2;

        res(:, :, 3:end-2) = res(:, :, 3:end-2) ...
            - lam * (fb(:, :, 2:end) - fb(:, :, 1:end-1));
end