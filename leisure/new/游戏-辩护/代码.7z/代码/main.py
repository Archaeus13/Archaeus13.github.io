"""
    Author: Archaeus
    Version: 1.0
    Packages: os, time, msvcrt
    OS: Windows
"""

from parts import *

quit_game = False
name, status = intro()
while not quit_game:
    if status == 0:
        quit_game, status = cycle_1(name)
    elif status == 1:
        quit_game, status = cycle_2(name)
    elif status == 2:
        quit_game, status = cycle_3(name)
    elif status == 3:
        quit_game, status = cycle_4(name)
    elif status == 4:
        quit_game, status = cycle_5(name)
    elif status == 5:
        quit_game, status = final_choice(name)
    elif status == 6:
        quit_game, status = cycle_e(name)
    elif status == 7:
        quit_game, status = cycle_r()
    elif status == 8:
        quit_game, status = real_end(name)
    elif status == 9:
        quit_game, status = after()