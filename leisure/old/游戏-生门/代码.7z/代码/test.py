from hero import Hero
from block import Block
from react import *
import pygame
from sys import exit

pygame.init()
screen = pygame.display.set_mode((1200, 700))
pygame.display.set_caption("test")
hero = Hero(300, 300)
blocks = []
b1 = Block(-10, 530, 1220, 200)
b2 = Block(700, 270, 100, 100, 'block0')
b3 = Block(700, 430, 100, 100, 'block1', 3)
b4 = Block(1000, 330, 100, 100, 'block0')
b5 = Block(380, 170, 100, 100, 'block0')
s1 = Block(1060, 280, 40, 50, 'spike')
s2 = Block(730, 220, 40, 50, 'spike')
n1 = Note(300, 505, '按AD以左右移动')
n2 = Note(600, 505, '有些箱子可以推动')
n3 = Note(750, 505, '按K以跳跃')
n4 = Note(1010, 305, '注意躲避尖刺')
door = Door(430, 120)
blocks=[b1,b2,b3,b4,b5,s1,s2]
spikes=[s1,s2]
notes=[n1,n2,n3,n4]

while True:
	screen.fill((255,255,255))
	framerate = pygame.time.Clock()
	framerate.tick(60)
	for event in pygame.event.get():
		if event.type == pygame.QUIT:
			exit()
		hero.check_event(event)
	door.if_near(hero)
	door.draw(screen)
	for note in notes:
		note.react(hero,screen)
		note.draw(screen)
	if not hero.check_update_draw(spikes, blocks, screen):
		exit()

	for block in blocks:
		block.draw(screen)
	
	
	pygame.display.flip()
	
