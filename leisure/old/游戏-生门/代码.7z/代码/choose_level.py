import pygame
from text import Text
from opening import opening

def choose_level(screen, level, stats):
	'''选择关卡界面'''
	if level == 'choose':
		if stats.opening == 0:
			stats.opening = 1
			return 'opening'
		screen.fill((255,255,255))
		opening_button = Text(200, 30, screen, '-序幕 提灯者-')
		opening_button.show_text()
		back_button = Text(1150, 670, screen, "返回")
		back_button.show_text()
		if stats.chapter1:
			chapter1_button = Text(200, 100, screen, '-第一章 深渊-')
			chapter1_button.show_text()
		if stats.chapter1_1:
			chapter1_1_button = Text(400, 100, screen, '幽闭恐惧')
			chapter1_1_button.show_text()
		if stats.chapter1_2:
			chapter1_2_button = Text(600, 100, screen, '猫和猫和猫')
			chapter1_2_button.show_text()
		pygame.display.flip()
		
		while True:
			for event in pygame.event.get():
				if event.type == pygame.QUIT:
					return ''
				elif event.type == pygame.MOUSEBUTTONDOWN:
					pos = pygame.mouse.get_pos()
					if back_button.rect.collidepoint(pos):
						back_button.change_color(200,200,200)
						pygame.display.update()
						pygame.time.wait(200)
						return ''
					if opening_button.rect.collidepoint(pos):
						opening_button.change_color(200,200,200)
						pygame.display.update()
						pygame.time.wait(200)
						return 'opening'
					if stats.chapter1:
						if chapter1_button.rect.collidepoint(pos):
							chapter1_button.change_color(200,200,200)
							pygame.display.update()
							pygame.time.wait(200)
							return 'chapter1_1'
					if stats.chapter1_1:
						if chapter1_1_button.rect.collidepoint(pos):
							chapter1_1_button.change_color(200,200,200)
							pygame.display.update()
							pygame.time.wait(200)
							return 'chapter1_1'
					if stats.chapter1_2:
						if chapter1_2_button.rect.collidepoint(pos):
							chapter1_2_button.change_color(200,200,200)
							pygame.display.update()
							pygame.time.wait(200)
							return 'chapter1_2'

	if level == 'opening':
		return opening(screen, stats)

	#if level = 'chapter1_1':
	#	return chapter1_1(screen, stats)
