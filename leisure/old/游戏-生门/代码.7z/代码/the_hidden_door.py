from sys import exit 
from stats import Stats
from title_page import title_page
from choose_level import choose_level
from help_settings import help_settings
import pygame

if_renew_music = True
stats = Stats()
pygame.init()
screen = pygame.display.set_mode((1200, 700))
pygame.display.set_caption("生门")

while True:
	title_choice = title_page(screen, if_renew_music, stats)
	if title_choice == 0:
		stats.update()
		exit()
	elif title_choice**2 == 1:
		if title_choice == 1:
			level = 'choose'
		else:
			level = 'secret'
		while level:
			level = choose_level(screen, level, stats)
		if_renew_music = True
	elif title_choice == 2:
		help_settings(screen, stats)
		if_renew_music = False
	elif title_choice == 3:
		#collection()
		if_renew_music = False

