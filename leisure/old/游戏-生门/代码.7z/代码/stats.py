class Stats():
	'''需要在游戏外存储的内容'''

	def __init__(self):
		'''从存储文件中读取'''
		st = open('stats.txt')
		contents = st.read()
		st.close()
		self.if_play_music = int(contents[0])
		self.if_play_sound = int(contents[1])
		self.opening = int(contents[2])
		self.chapter1 = int(contents[3])
		self.chapter1_1 = int(contents[4])
		self.chapter1_2 = int(contents[5])

	def update(self):
		'''更新存储文件'''
		st = open('stats.txt', 'w')
		st.write(str(self.if_play_music))
		st.write(str(self.if_play_sound))
		st.write(str(self.opening))
		st.write(str(self.chapter1))
		st.write(str(self.chapter1_1))
		st.write(str(self.chapter1_2))
		st.close()

	def clear(self):
		'''还原为未解锁状态'''
		self.opening = 0
		self.chapter1 = 0
		self.chapter1_1 = 0
		self.chapter1_2 = 0
