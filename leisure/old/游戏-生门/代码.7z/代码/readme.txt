运行 the_hidden_door 展示标题界面 demo
运行 test 展示关卡 demo