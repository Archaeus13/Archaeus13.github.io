#define INFTY 10000
#include <iostream>
#include <fstream>
using namespace std;

class Graph {
	private:
	int vexnum; //�洢��������ı��� 
	double** length; //�洢�������������ı��� 
	int edgenum; //�洢�������ı��� 
	int** edge; //�洢���бߵı��� 
	double** equation; //�洢�������򷽳���ı��� 
	bool Connect(int m, int n, bool** a, bool* visit); //�ж�����ѡ�ı��������±��Ƿ�ɻ� 
	void ST(int T[]); //��ѡ�߼���Ϊ��С������ 
	void Clear(int L[]); //��������Ľ�� 
	int Next(int j, int T[], int l); //Ѱ�һ��е���һ�� 
	void Clear2(int L[]); //����ͨ·��Ľ�� 
	int Next2(int j, int T[], int l); //Ѱ��ͨ·�е���һ�� 
	void SetEquation1(void); //�������������һ���� 
	void SetEquation2(void); //������������ڶ����� 
	void SetEquation3(void); //�������һ������ 
	void PrintEquation(void); //��ӡ������
	int Degree(int v); //�������
	double Parallel(double a, double b); //�򵥲������� 
	bool CaseA(void); //�˻�����Ļ���
	bool CaseB(void); //�򵥴������Ļ���
	bool CaseC(void); //����-Y�任���� 
	
	public:
	void Init(const char* filename); //���ļ����ɵ���ͼ
	void Destroy(void); //ɾ��ͼ 
	void Print(void); //��ӡ�洢�Ľ�����
	void PrintEdge(void); //��ӡ���б�
	void SetEquation(void); //��������ӡ�������򷽳���
	void EquationCode(void); //���������򷽳����ӡΪMathematica���� 
	void Simplify(void); //����������� 
	void Reconstruct(void); //�ع���������
};

void Graph::Init(const char* filename) {
	int i, j, k = 0;
	ifstream file;
	file.open(filename, ios::in);
	file >> vexnum;
	file >> edgenum;
	
	length = new double*[vexnum];
	for (i = 0; i < vexnum; i++) {
		length[i] = new double[vexnum];
		for (int j = 0; j < vexnum; j++)
			length[i][j] = INFTY;
	}
	
	int a, b;
	double c;
	while (!file.eof()) {
		file >> a;
		file >> b;
		file >> c;
		length[a][b] = length[b][a] = c;
	}
	
	edge = new int*[edgenum];
	for (i = 0; i < vexnum; i++)
		for (j = i+1; j <vexnum; j++)
			if (length[i][j] != INFTY) {
				edge[k] = new int[2];
				edge[k][0] = i;
				edge[k++][1] = j;
			}
			
	equation = new double*[edgenum];
	for (i = 0; i < edgenum; i++) equation[i] = new double[edgenum+1];
}

void Graph::Destroy(void) {
	int i;
	for (i = 0; i < vexnum; i++) delete[] length[i];
	delete[] length;
	length = new double*[vexnum];
	for (i = 0; i < edgenum; i++) delete[] edge[i];
	delete[] edge;
	for (i = 0; i < edgenum; i++) delete[] equation[i];
	delete[] equation;
}

void Graph::Print(void) {
	for (int i = 0; i < vexnum; i++) {
		for (int j = 0; j < vexnum; j++){
			if (length[i][j] == INFTY) cout << "#    ";
			else printf("%-5.2f", length[i][j]);
		}
		cout << endl;
	}
	cout << endl;
}

void Graph::PrintEdge(void) {
	for (int i = 0; i < edgenum; i++) 
		cout << '(' << edge[i][0] << ',' << edge[i][1] << ") ";
	cout << endl << endl;
}

void Graph::SetEquation1(void) {
	int i, j;
	for (i = 0; i < edgenum; i++)
		for (j = 0; j <= edgenum; j++)
			equation[i][j] = 0;
	for (i = 0; i < vexnum - 2; i++) 
		for (j = 0; j < edgenum; j++) {
			if (edge[j][0] == i+2) equation[i][j] = 1; 
			if (edge[j][1] == i+2) equation[i][j] = -1;
		}
}

bool Graph::Connect(int m, int n, bool** a, bool* visit) {
	if (m == n) return 1;
	visit[m] = 1;
	int w = -1, i;
	for (i = 0; i < vexnum; i++) if (a[m][i]) {
		w = i;
		break;
	}
	while(w != -1) {
		if(!visit[w]) if (Connect(w, n, a, visit)) return 1;
	    w = -1;
	    for (i++; i < vexnum; i++) if (a[m][i]) {
		    w = i;
		    break;
	    }
	}
	return 0;
}

void Graph::ST(int T[]) {
	int i, j, k, t0, t1;
	bool **t, *visit;
	t = new bool*[vexnum];
	visit = new bool[vexnum];
	for (i = 0; i < vexnum; i++) t[i] = new bool[vexnum];
	for (i = 0; i < vexnum; i++) for (j = 0; j < vexnum; j++) t[i][j] = 0;
	j = 0;
	for (i = 0; i < edgenum; i++) {
		for (k = 0; k < vexnum; k++) visit[k] = 0;
		t0 = edge[i][0];
		t1 = edge[i][1];
		if (!Connect(t0, t1, t, visit)) {
			t[t0][t1] = t[t1][t0] = 1;
			T[j++] = i;
		}
	}
}

void Graph::Clear(int L[]) {
	int a[vexnum], i, j;
	bool t = 1;
	while (t) {
		t = 0;
		for (i = 0; i < vexnum; i++) a[i] = 0;
		for (i = 0; i < vexnum; i++)
			if (L[i] != -1) {
				a[edge[L[i]][0]]++;
				a[edge[L[i]][1]]++;
			}
		for (i = 0; i < vexnum; i++)
			if (a[i] == 1) {
				t = 1;
				for (j = 0; j < vexnum; j++) if (L[j] != -1)
					if (edge[L[j]][0] == i || edge[L[j]][1] == i)
						L[j] = -1;
			}
	}
}

int Graph::Next(int j, int L[], int l) {
	for (int i = 0; i < vexnum; i++)
		if (L[i] != -1 && L[i] != j)
			if (edge[L[i]][0] == edge[j][l] || edge[L[i]][1] == edge[j][l])
				return L[i];
}

void Graph::SetEquation2(void) {
	int T[vexnum-1], L[vexnum], i = vexnum-2, j, k, p, pre, l;
	bool t;
	ST(T);
	for (j = 0; j < edgenum; j++) {
		t = 1;
		for (k = 0; k < vexnum-1; k++) if(T[k] == j) t = 0;
		if (t) {
			for (k = 0; k < vexnum-1; k++) L[k] = T[k];
			L[vexnum-1] = j;
			Clear(L);
			l = 1;
			pre = j;
			p = Next(j, L, l);
			if (edge[j][0] < edge[j][1]) equation[i][j] = length[edge[j][0]][edge[j][1]];
			else equation[i][j] = -length[edge[j][0]][edge[j][1]];
			while (p != j) {
				if (edge[p][0] == edge[pre][l]) l = 1;
				else l = 0;
				if (edge[p][1-l] < edge[p][l]) equation[i][p] = length[edge[p][0]][edge[p][1]];
				else equation[i][p] = -length[edge[p][0]][edge[p][1]];
				pre = p;
				p = Next(p, L, l);
			}
			i++;
		}
	}
}

void Graph::Clear2(int L[]) {
	int a[vexnum], i, j;
	bool t = 1;
	while (t) {
		t = 0;
		for (i = 0; i < vexnum; i++) a[i] = 0;
		for (i = 0; i < vexnum-1; i++)
			if (L[i] != -1) {
				a[edge[L[i]][0]]++;
				a[edge[L[i]][1]]++;
			}
		for (i = 2; i < vexnum; i++)
			if (a[i] == 1) {
				t = 1;
				for (j = 0; j < vexnum-1; j++) if (L[j] != -1)
					if (edge[L[j]][0] == i || edge[L[j]][1] == i)
						L[j] = -1;
			}
	}
}

int Graph::Next2(int j, int L[], int l) {
	for (int i = 0; i < vexnum-1; i++)
		if (L[i] != -1 && L[i] != j)
			if (edge[L[i]][0] == edge[j][l] || edge[L[i]][1] == edge[j][l])
				return L[i];
	return -1;
}

void Graph::SetEquation3(void) {
	int T[vexnum-1], p, pre = 0, l = 1;
	ST(T);
	Clear2(T);
	while (T[pre] == -1) pre++;
	p = Next2(pre, T, l);
	if (edge[pre][1-l] < edge[pre][l]) equation[edgenum-1][pre] = length[edge[pre][0]][edge[pre][1]];
	else equation[edgenum-1][pre] = -length[edge[pre][0]][edge[pre][1]];
	while (p != -1) {
		if (edge[p][0] == edge[pre][l]) l = 1;
		else l = 0;
		if (edge[p][1-l] < edge[p][l]) equation[edgenum-1][p] = length[edge[p][0]][edge[p][1]];
		else equation[edgenum-1][p] = -length[edge[p][0]][edge[p][1]];
		pre = p;
		p = Next2(p, T, l);
	}
	equation[edgenum-1][edgenum] = 1;
}

void Graph::PrintEquation(void) {
	for (int i = 0; i < edgenum; i++) {
		for (int j = 0; j < edgenum; j++)
			printf(" %.2f%c", equation[i][j], j+'A');
		printf("=%.2f\n", equation[i][edgenum]);
	}
	cout << endl;
}

void Graph::SetEquation(void) {
	SetEquation1();
	SetEquation2();
	SetEquation3();
	PrintEquation();
}

void Graph::EquationCode(void) {
	int i, j;
	cout << "LinearSolve[{";
	for (i = 0; i < edgenum; i++) {
		cout << '{';
		for (j = 0; j < edgenum; j++) {
			cout << equation[i][j];
			if (j != edgenum-1) cout << ',';
		}
		cout << '}';
		if (i != edgenum-1) cout << ',';
	}
	cout << "},{";
	for (i = 0; i < edgenum; i++) {
		cout << equation[i][edgenum];
		if (i != edgenum-1) cout << ',';
	}
	cout << "}];" << endl << endl;
}

double Graph::Parallel(double a, double b) {
	if (a == INFTY) return b;
	if (b == INFTY) return a;
	return a*b/(a+b);
}

int Graph::Degree(int v) {
	int result = 0;
	for (int j = 0; j < vexnum; j++)
		if (length[v][j] != INFTY) result++;
	return result;
}

bool Graph::CaseA(void) {
	for (int i = 2; i < vexnum; i++) {
		if (length[i][i] != INFTY) {
			length[i][i] = INFTY;
			return 1;
		}
		if (Degree(i) == 1) {
			for (int j = 0; j < vexnum; j++)
				if (length[i][j] != INFTY) {
					length[i][j] = length[j][i] = INFTY;
					return 1;
				}
		}
	}
	return 0;
}

bool Graph::CaseB(void) {
	double sum;
	int c = 0;
	int t[2];
	for (int i = 2; i < vexnum; i++) 
		if (Degree(i) == 2) {
			for (int j = 0; j < vexnum; j++)
				if (length[i][j] != INFTY) {
					sum += length[i][j];
					t[c++] = j;
					length[i][j] = length[j][i] = INFTY;
				}
			length[t[1]][t[0]] = length[t[0]][t[1]] = Parallel(sum, length[t[0]][t[1]]);
			return 1;
		}
	return 0;
}

bool Graph::CaseC(void) {
	int c = 0;
	int t[3];
	double l[3], Y;
	for (int i = 2; i < vexnum; i++) 
		if (Degree(i) == 3) {
			for (int j = 0; j < vexnum; j++)
				if (length[i][j] != INFTY) {
					l[c] = length[i][j];
					t[c++] = j;
					length[i][j] = length[j][i] = INFTY;
				}
			Y = l[0]*l[1]+l[1]*l[2]+l[2]*l[0];
			length[t[1]][t[0]] = length[t[0]][t[1]] = Parallel(Y/l[2], length[t[0]][t[1]]);
			length[t[1]][t[2]] = length[t[2]][t[1]] = Parallel(Y/l[0], length[t[2]][t[1]]);
			length[t[2]][t[0]] = length[t[0]][t[2]] = Parallel(Y/l[1], length[t[0]][t[2]]);
			return 1;
		}
	return 0;
}

void Graph::Simplify(void) {
	while (CaseA() || CaseB() || CaseC());
}

void Graph::Reconstruct(void) {
	int i, j, k = 0, sum = 0;
	
	int newvexnum = 0, vexexist[vexnum];
	for (i = 0; i < vexnum; i++)
		if (Degree(i)) {
			vexexist[newvexnum++] = i;
			sum += Degree(i);
		}
	double newlength[newvexnum][newvexnum];
	for (i = 0; i < newvexnum; i++)
		for (j = 0; j < newvexnum; j++) {
			newlength[i][j] = length[vexexist[i]][vexexist[j]];
		}
	for (i = 0; i < vexnum; i++) delete[] length[i];
	delete[] length;
	length = new double*[newvexnum];
	for (i = 0; i < newvexnum; i++) {
		length[i] = new double[newvexnum];
		for (int j = 0; j < newvexnum; j++)
			length[i][j] = newlength[i][j];
	}
	vexnum = newvexnum;

	for (i = 0; i < edgenum; i++) delete[] edge[i];
	delete[] edge;
	edgenum = sum / 2;
	edge = new int*[edgenum];
	for (i = 0; i < vexnum; i++)
		for (j = i+1; j <vexnum; j++)
			if (length[i][j] != INFTY) {
				edge[k] = new int[2];
				edge[k][0] = i;
				edge[k++][1] = j;
			}
	
	for (i = 0; i < edgenum; i++) delete[] equation[i];
	delete[] equation;
	equation = new double*[edgenum];
	for (i = 0; i < edgenum; i++) equation[i] = new double[edgenum+1];
}

void PrintMenu(void) {
	cout << "0 �˳�" << endl;
	cout << "1 ��ӡ�洢�Ľ�����" << endl;
	cout << "2 ��ӡ���б�" << endl;
	cout << "3 ��������ӡ�������򷽳���" << endl;
	cout << "4 ���������򷽳����ӡΪMathematica����" << endl;
	cout << "5 �����������" << endl;
	cout << "6 �ع���������" << endl;
}

int main(void) {
	Graph g;
	g.Init("star.txt"); //�޸Ĵ˴��ļ������ɲ��Բ�ͬ���� 
	char c;
	while (1) {
		PrintMenu();
		cin >> c;
		cin.get();
		switch (c) {
			case '0':
				g.Destroy();
				return 0;
			
			case '1':
				g.Print();
				break;
			
			case '2':
				g.PrintEdge();
				break;
				
			case '3':
				g.SetEquation();
				break;
				
			case '4':
				g.EquationCode();
				break;
				
			case '5':
				g.Simplify();
				break;
				
			case '6':
				g.Reconstruct();
				break;
			
			default:
				cout << "ERROR" << endl;
		}
	}
}
