function res = c9_RKF45(f, y0, x0, h0, delta, max_iter)
    if (~exist('max_iter', 'var'))
        max_iter = -1;
    end
    x = [];
    y = [];
    x_now = x0;
    y_now = y0;
    h = h0;
    count = 0;
    while isfinite(y_now)
        x = [x x_now];
        y = [y y_now];
        F1 = h * f(x_now, y_now);
        F2 = h * f(x_now + h/4, y_now + F1/4);
        F3 = h * f(x_now + h*3/8, y_now + F1*3/32 + F2*9/32);
        F4 = h * f(x_now + h*12/13, y_now + F1*1932/2197 - F2*7200/2197 ...
            + F3*7296/2197);
        F5 = h * f(x_now + h, y_now + F1*439/216 - F2*8 + F3*3680/513 ...
            - F4*845/4104);
        F6 = h * f(x_now + h/2, y_now - F1*8/27 + F2*2 - F3*3544/2565 ...
            + F4*1859/4104 - F5*11/40);
        x_now = x_now + h;
        y_cmp = y_now + F1*16/135 + F3*6656/12825 + F4*28561/56430 ...
            - F5*9/50 + F6*2/55;
        y_now = y_now + F1*25/216 + F3*1408/2565 + F4*2197/4104 - F5/5;
        err = abs(y_now - y_cmp);
        h = 0.9 * h * (delta / err) ^ 0.2;
        count = count + 1;
        if count == max_iter
            break;
        end
    end
    res(1,:) = x;
    res(2,:) = y;
end