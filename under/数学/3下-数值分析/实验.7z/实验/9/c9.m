fprintf("Task1:\n");
f = @(x, y) exp(x * y) + cos(y - x);
res = c9_RKF45(f, 3, 1, 0.01, 1e-10);
plot(res(1,:), res(2,:), "linewidth", 2);
fprintf("result range: [1, %f]\n", res(1, end));
x = input("input x in range above: ");
if (x >= 1 && x < res(1, end))
    i = 1;
    while res(1, i) < x
        i = i + 1;
    end
    if i == 1
        fprintf("y = 3\n");
    else
        x_b = res(1, i-1);
        x_a = res(1, i);
        y_b = res(2, i-1);
        y_a = res(2, i);
        y = ((y_b-y_a) * x + x_b*y_a - y_b*x_a) / (x_b-x_a);
        fprintf("y = %f\n", y);
    end
else
    fprintf("ERROR: number not in range\n");
end

fprintf("\nTask2:\n");
fprintf("N \terr          \tord\n");
f = @(t,x) (t - exp(-t)) / (x + exp(x));
x_1 = -0.155782424588460;
x0 = -0.534416297250012;
t0 = 0.6;
h = 0.4 / 8;
r = c9_AB(f, x0, t0, h, 1);
err_old = abs(r(2, end) - x_1);
fprintf("8 \t%e\n", err_old);
for i = 1:4
    h = h / 2;
    r = c9_AB(f, x0, t0, h, 1);
    err = abs(r(2, end) - x_1);
    ord = log (err_old / err) / log(2);
    fprintf("%d\t%e\t%f\n", int32(0.4/h), err, ord);
    err_old = err;
end