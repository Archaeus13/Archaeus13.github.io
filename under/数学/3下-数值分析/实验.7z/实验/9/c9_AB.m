function res = c9_AB(f, y0, x0, h, x_max)
    x = x0:h:x_max;
    y = zeros(1, length(x));
    y(1) = y0;
    for i = 1:4
        F1 = h * f(x(i), y(i));
        F2 = h * f(x(i) + h/4, y(i) + F1/4);
        F3 = h * f(x(i) + h*3/8, y(i) + F1*3/32 + F2*9/32);
        F4 = h * f(x(i) + h*12/13, y(i) + F1*1932/2197 - F2*7200/2197 ...
            + F3*7296/2197);
        F5 = h * f(x(i) + h, y(i) + F1*439/216 - F2*8 + F3*3680/513 ...
            - F4*845/4104);
        y(i + 1) = y(i) + F1*25/216 + F3*1408/2565 + F4*2197/4104 - F5/5;
    end
    for i = 5:length(x) - 1
        y(i + 1) = y(i) + h / 720 * ( f(x(i), y(i)) * 1901 ...
            - f(x(i-1), y(i-1)) * 2774 + f(x(i-2), y(i-2)) * 2616 ...
            - f(x(i-3), y(i-3)) * 1274 + f(x(i-4), y(i-4)) * 251 );
    end
    res(1,:) = x;
    res(2,:) = y;
end