function R = c7_R(f, a, b, M)
    R = zeros(M + 1);
    h = (b - a) / 2;
    R(1, 1) = h * (f(b) - f(a));
    for i = 2:M+1
        sum = 0;
        for j = a+h : 2*h : b-h
            sum = sum + f(j);
        end
        R(i, 1) = R(i-1, 1) / 2 + h * sum;
        h = h / 2;
    end
    for i = 2:M+1
        t = 1 / (4 ^ (i - 1) - 1);
        for j = i:M+1
            R(j, i) = R(j, i-1) * (t + 1) - R(j-1, i-1) * t;
        end
    end
end