f1 = @(x) sin(x) / ((x ~= 0) * x + (x == 0)) + (x == 0);
res1 = 0.9460830703671841;
f2 = @(x) (cos(x) - exp(x)) / ((x ~= 0) * sin(x) + (x == 0)) - (x == 0);
res2 = -2.246591720728612;
f3 = @(x) exp(-1/x) / ((x ~= 0) * x + (x == 0));
res3 = 0.2193839343983438;
N = 6;
fprintf("Task1:\n");
R = c7_R(f1, 0, 1, N);
for i = 1:N+1
    for j = 1:i
        fprintf("%f\t", R(i,j));
    end
    fprintf("\n");
end
fprintf("\nTask1 Error:\n");
for i = 1:N+1
    for j = 1:i
        fprintf("%e\t", abs(res1 - R(i,j)));
    end
    fprintf("\n");
end
fprintf("\nTask2:\n");
R = c7_R(f2, -1, 1, N);
for i = 1:N+1
    for j = 1:i
        fprintf("%f\t", R(i,j));
    end
    fprintf("\n");
end
fprintf("\nTask2 Error:\n");
for i = 1:N+1
    for j = 1:i
        fprintf("%e\t", abs(res2 - R(i,j)));
    end
    fprintf("\n");
end
fprintf("\nTask3:\n");
R = c7_R(f3, 0, 1, N);
for i = 1:N+1
    for j = 1:i
        fprintf("%f\t", R(i,j));
    end
    fprintf("\n");
end
fprintf("\nTask3 Error:\n");
for i = 1:N+1
    for j = 1:i
        fprintf("%e\t", abs(res3 - R(i,j)));
    end
    fprintf("\n");
end