x_real = @(t) sin(t);
max_err = zeros(1, 41);
figure();
for lambda = -30:10
    f = @(t, x) lambda * x + cos(t) - lambda * sin(t);
    flag = ismember(lambda, 3:6);
    if flag
        subplot(2, 2, lambda - 2);
    end
    max_err(lambda + 31) = c8_heun(f, 0.01, 0, 5, 0, x_real, flag);
    if flag
        title("lambda = " + num2str(lambda));
    end
end
figure();
plot(-30:10, log(max_err) / log(10));
xlabel('lambda');
ylabel('log10(err)');