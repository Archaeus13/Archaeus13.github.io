function e = c8_heun(f, h, a, b, xa, x_real, if_plot)
    t = a:h:b;
    M = length(t);
    x = zeros(1, M);
    x(1) = xa;
    for i = 1:M-1
        s = t(i);
        y = x(i);
        F1 = h * f(s, y);
        F2 = h * f(s + h / 2, y + F1 / 2);
        F3 = h * f(s + h / 2, y + F2 / 2);
        F4 = h * f(s + h, y + F3);
        x(i + 1) = y + (F1 + 2 * F2 + 2 * F3 + F4) / 6;
    end
    xr = x_real(t);
    e = max(abs(x - xr));
    if (if_plot)
        plot(t, x, 'b', 'linewidth', 2);
        hold on;
        plot(t, xr, 'r:', 'linewidth', 2);
        legend('approx', 'real');
        xlabel('t');
        ylabel('x');
        hold off;
    end
end