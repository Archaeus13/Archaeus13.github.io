fprintf("Task1:\n");
u = @(x) 0 * x;
v = @(x) -1 + 0 * x;
w = @(x) 0 * x;
f_real = @(x) 7 * sin(x) + 3 * cos(x);
fprintf('N\terr         \tord\n');
N = 10;
y = c11_dif(0, 3, pi/2, 7, N, u, v, w);
x = 0:(pi/(2*N+2)):(pi/2);
y_real = f_real(x);
err_old = max(abs(y - y_real));
fprintf('10\t%e\n', err_old);
for i = 1:4
    N = N * 2;
    y = c11_dif(0, 3, pi/2, 7, N, u, v, w);
    x = 0:(pi/(2*N+2)):(pi/2);
    y_real = f_real(x);
    err = max(abs(y - y_real));
    ord = log (err_old / err) / log(2);
    fprintf('%d\t%e\t%f\n', N, err, ord);
    err_old = err;
end

fprintf("\nTask2:\n");
u = @(x) 2 * exp(x);
v = @(x) -1 + 0 * x;
w = @(x) 0 * x;
f_real = @(x) exp(x) + cos(x);
fprintf('N\terr         \tord\n');
N = 10;
y = c11_dif(0, 2, 1, exp(1)+cos(1), N, u, v, w);
x = 0:(1/(N+1)):1;
y_real = f_real(x);
err_old = max(abs(y - y_real));
fprintf('10\t%e\n', err_old);
for i = 1:4
    N = N * 2;
    y = c11_dif(0, 2, 1, exp(1)+cos(1), N, u, v, w);
    x = 0:(1/(N+1)):1;
    y_real = f_real(x);
    err = max(abs(y - y_real));
    ord = log (err_old / err) / log(2);
    fprintf('%d\t%e\t%f\n', N, err, ord);
    err_old = err;
end