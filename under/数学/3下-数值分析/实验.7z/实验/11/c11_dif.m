function y = c11_dif(xa, ya, xb, yb, N, u, v, w)
    h = (xb - xa) / (N + 1);
    x = xa+h:h:xb-h;
    u = u(x);
    v = v(x);
    w = w(x);
    A = zeros(N);
    b = zeros(N, 1);
    for i = 1:N-1
        A(i, i) = 2 + v(i) * h^2;
        A(i, i+1) = h * w(i) / 2 - 1;
        A(i+1, i) = -h * w(i+1) / 2 - 1;
        b(i) =  -u(i) * h^2;
    end
    b(1) = b(1) + ya * (h * w(1) / 2 + 1);
    A(N, N) = 2 + v(N) * h^2;
    b(N) = -u(N) * h^2 - yb * (h * w(N) / 2 - 1);
    y = [ya, (A \ b)', yb];
end