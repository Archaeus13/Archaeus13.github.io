for i = 0:10
    c0_count(i / 10.0);
end
for i = 1:30
    c0_count(i*10);
end