function k = c0_estimateK(x)
    a = int32(x);
    if a == 0
        sum = pi * pi / 6;
    else
        sum = 0;
        for i = 1:a
            sum = sum + 1 / double(i);
        end
        sum = sum / double(a);
    end
    k = 1;
    while sum > 1e-6
        sum = sum - 1.0 / (k*(k+double(a)));
        k = k + 1;
    end
end