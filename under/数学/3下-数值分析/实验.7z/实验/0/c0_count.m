function res = c0_count(x)
    res = 0;
    k = 0;
    maxk = c0_estimateK(x);
    while k < maxk
        k = k + 1;
        res = res + 1/(k*(k+x));
    end
    disp([num2str(x), '  ', num2str(res), '  ', num2str(maxk - 1)]);
end