function err = c3_cubic(N)
    h = 1 / double(N);
    y = exp(0:h:1);
    A = zeros(N + 1);
    b = zeros(N + 1, 1);
    A(1, 1) = h / 3;
    A(1, 2) = h / 6;
    b(1) = (y(2) - y(1)) / h - 1;
    for i = 2:N
        A(i, i-1) = h;
        A(i, i+1) = h;
        A(i, i) = 4 * h;
        b(i) = 6 / h * (y(i+1) - 2 * y(i) + y(i-1));
    end
    A(N+1, N) = h / 6;
    A(N+1, N+1) = h / 3;
    b(N+1) = (y(N) - y(N+1)) / h + exp(1);
    z = sparse(A) \ b;
    err = 0;
    for i = 1:N
        t = (2 * i - 1) * h / 2;
        res = exp(t);
        sim = (z(i+1) - z(i)) / (6 * h);
        sim = sim*h/2 + z(i) / 2;
        sim = sim*h/2 - h * z(i+1)/6 - h * z(i)/3 + (y(i+1) - y(i)) / h;
        sim = sim*h/2 + y(i);
        now = abs(res - sim);
        if now > err
            err = now;
        end
    end
end