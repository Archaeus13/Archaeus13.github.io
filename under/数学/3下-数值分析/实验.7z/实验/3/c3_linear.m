function err = c3_linear(N)
    step = 1 / double(2*N);
    err = 0;
    for i = step:2*step:1
        now = exp(i) - (exp(i-step) + exp(i+step)) / 2;
        if abs(now) > err
            err = abs(now);
        end
    end
end