function res = c6_trap(f, a, b, N)
    val = f([a:(b-a)/N:b]);
    val(1) = val(1) / 2;
    val(N+1) = val(N+1) / 2;
    res = sum(val) * (b - a) / N;
end