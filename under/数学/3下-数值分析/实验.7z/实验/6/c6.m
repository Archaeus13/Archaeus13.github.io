f1 = @(x) exp(-x.^2);
res1 = 0.7468241328124279;
f2 = @(x) (1 + x.^2) .^(-1);
res2 = 1.325817663668032;
f3 = @(x) (2 + cos(x)) .^(-1);
res3 = 3.627598728470767;
fprintf("Trap:\n");
fprintf('N\t\terr1\t\t\tord1\t\t\terr2\t\t\tord2\t\t\terr3\t\t\tord3\n');
N = 2;
err1_old = abs(c6_trap(f1, 0, 1, N) - res1);
err2_old = abs(c6_trap(f2, 0, 4, N) - res2);
err3_old = abs(c6_trap(f3, 0, 2 * pi, N) - res3);
fprintf('2\t\t%e\t\t\t\t\t%e\t\t\t\t\t%e\n', err1_old, err2_old, err3_old);
for i = 1:6
    N = N * 2;
    err1 = abs(c6_trap(f1, 0, 1, N) - res1);
    err2 = abs(c6_trap(f2, 0, 4, N) - res2);
    err3 = abs(c6_trap(f3, 0, 2 * pi, N) - res3);
    ord1 = log (err1_old / err1) / log(2);
    ord2 = log (err2_old / err2) / log(2);
    ord3 = log (err3_old / err3) / log(2);
    fprintf('%d\t\t%e\t\t%f\t\t%e\t\t%f\t\t%e\t\t%f\n', ...
        N, err1, ord1, err2, ord2, err3, ord3);
    err1_old = err1;
    err2_old = err2;
    err3_old = err3;
end
fprintf("\nGauss:\n");
fprintf('N\t\terr1\t\t\tord1\t\t\terr2\t\t\tord2\t\t\terr3\t\t\tord3\n');
N = 2;
err1_old = abs(c6_gauss(f1, 0, 1, N) - res1);
err2_old = abs(c6_gauss(f2, 0, 4, N) - res2);
err3_old = abs(c6_gauss(f3, 0, 2 * pi, N) - res3);
fprintf('2\t\t%e\t\t\t\t\t%e\t\t\t\t\t%e\n', err1_old, err2_old, err3_old);
for i = 1:6
    N = N * 2;
    err1 = abs(c6_gauss(f1, 0, 1, N) - res1);
    err2 = abs(c6_gauss(f2, 0, 4, N) - res2);
    err3 = abs(c6_gauss(f3, 0, 2 * pi, N) - res3);
    ord1 = log (err1_old / err1) / log(2);
    ord2 = log (err2_old / err2) / log(2);
    ord3 = log (err3_old / err3) / log(2);
    fprintf('%d\t\t%e\t\t%f\t\t%e\t\t%f\t\t%e\t\t%f\n', ...
        N, err1, ord1, err2, ord2, err3, ord3);
    err1_old = err1;
    err2_old = err2;
    err3_old = err3;
end