function res = c6_gauss(f, a, b, N)
    point = [a:(b-a)/N:b];
    res = 0;
    con = sqrt(3/5);
    for i = 1:N
        x = point(i);
        y = point(i+1);
        c = (x + y) / 2;
        d = (y - x) / 2;
        res = res + f(c + d * con) * 5 + f(c - d * con) * 5 + f(c) * 8;
    end
    res = res * (b - a) / (18 * N);
end