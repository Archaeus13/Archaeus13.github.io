function Funcollect = c1_lagrange
    Funcollect.lagrange_uni = @lagrange_uni;
    Funcollect.lagrange_ch = @lagrange_ch;
    Funcollect.count_res = @count_res;
    Funcollect.count_err = @count_err;
end

function err = lagrange_uni(N, if_draw)
    X = zeros(1, N + 1);
    for i = 0:N
        X(i + 1) = 5 - 10 * i / double(N);
    end
    Xin = zeros(1, 101);
    for i = 0:100
        Xin(i + 1) = double(i) / 10 - 5;
    end
    Yout = count_res(X, Xin);
    if if_draw ~= 0
        figure('name', 'uniform result');
        plot(Xin, Yout, 'r');
        hold on;
        Yin = zeros(1, 101);
        for i = 1:101
            Yin(i) = 1 / (1 + Xin(i) * Xin(i));
        end
        plot(Xin, Yin, 'b');
    end
    err = count_err(Xin, Yout);
end

function err = lagrange_ch(N, if_draw)
    X = zeros(1, N + 1);
    for i = 0:N
        X(i + 1) = -5 * cos((2 * i + 1) * pi / (2 * N  + 2));
    end
    Xin = zeros(1, 101);
    for i = 0:100
        Xin(i + 1) = double(i) / 10 - 5;
    end
    Yout = count_res(X, Xin);
    if if_draw ~= 0
        figure('name', 'chebyshev result');
        plot(Xin, Yout, 'r');
        hold on;
        Yin = zeros(1, 101);
        for i = 1:101
            Yin(i) = 1 / (1 + Xin(i) * Xin(i));
        end
        plot(Xin, Yin, 'b');
    end
    err = count_err(Xin, Yout);
end

function res = count_res(X, Xin)
    l = length(X);
    Y = zeros(1, l);
    for i = 1:l
        Y(i) = 1 / (1 + X(i) * X(i));
    end
    lout = length(Xin);
    res = zeros(1, lout);
    for k = 1:lout
        for i = 1:l
            sum = 1;
            for j = 1:l
                if j ~= i
                    sum = sum * (Xin(k) - X(j)) / (X(i) - X(j));
                end
            end
            res(k) = res(k) + sum * Y(i);
        end
    end
end

function err = count_err(Xin, Yout)
    err = 0;
    for i = 1:length(Xin)
        err_now = 1 / (1 + Xin(i) * Xin(i)) - Yout(i);
        if abs(err_now) > err
            err = abs(err_now);
        end
    end
end