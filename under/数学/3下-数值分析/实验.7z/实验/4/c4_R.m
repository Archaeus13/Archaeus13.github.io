function D = c4_R(f, x, M)
    D = zeros(M + 1);
    h = 1;
    for i = 1:M+1
        D(i, 1) = phi(f, h, x);
        h = h / 2;
    end
    for k = 2 : M+1
        for n = k : M+1
            r = 1 / (4^(k - 1) - 1);
            D(n, k) = (r + 1) * D(n,k-1) - r * D(n-1,k-1);
        end
    end
end

function y = phi(f, h, x)
    y = (f(x + h) - f(x - h)) / (2 * h);
end