disp('Task 1:');
f = @(x)log(x);
M = 3;
D = c4_R(f, 3, M);
for i = 1:M+1
    for j = 1:i
        fprintf('%ld\t', D(i,j));
    end
    fprintf('\n');
end
fprintf('\n');

disp('Task 2:');
f = @(x)tan(x);
M = 4;
D = c4_R(f, asin(0.8), M);
for i = 1:M+1
    for j = 1:i
        fprintf('%ld\t', D(i,j));
    end
    fprintf('\n');
end
fprintf('\n');

disp('Task 3:');
f = @(x)sin(x^2 + x/3);
M = 5;
D = c4_R(f, 0, M);
for i = 1:M+1
    for j = 1:i
        fprintf('%ld\t', D(i,j));
    end
    fprintf('\n');
end