function Funcollect = c2_newton
    Funcollect.newton_uni = @newton_uni;
    Funcollect.newton_ch = @newton_ch;
    Funcollect.count_res = @count_res;
    Funcollect.count_err = @count_err;
end

function err = newton_uni(N, if_draw)
    X = zeros(1, N + 1);
    for i = 0:N
        X(i + 1) = 1 - 2 * i / double(N);
    end
    Xin = -1:0.02:1;
    Yout = count_res(X, Xin);
    if if_draw ~= 0
        figure('name', 'uniform result');
        plot(Xin, Yout, 'r');
        hold on;
        Yin = zeros(1, 101);
        for i = 1:101
            Yin(i) = 1 / (1 + 25 * Xin(i) * Xin(i));
        end
        plot(Xin, Yin, 'b');
    end
    err = count_err(Xin, Yout);
end

function err = newton_ch(N, if_draw)
    X = zeros(1, N + 1);
    for i = 0:N
        X(i + 1) = -cos((2 * i + 1) * pi / (2 * N  + 2));
    end
    Xin = -1:0.02:1;
    Yout = count_res(X, Xin);
    if if_draw ~= 0
        figure('name', 'chebyshev result');
        plot(Xin, Yout, 'r');
        hold on;
        Yin = zeros(1, 101);
        for i = 1:101
            Yin(i) = 1 / (1 + 25 * Xin(i) * Xin(i));
        end
        plot(Xin, Yin, 'b');
    end
    err = count_err(Xin, Yout);
end

function res = count_res(X, Xin)
    l = length(X);
    Y = zeros(1, l);
    for i = 1:l
        Y(i) = 1 / (1 + 25 * X(i) * X(i));
    end
   
    c = zeros(1, l);
    c(1) = Y(1);
    for k = 2:l
        d = X(k) - X(k-1);
        u = c(k - 1);
        for i = k-2:-1:1
            u = u * (X(k) - X(i)) + c(i);
            d = d * (X(k) - X(i));
        end
        c(k) = (Y(k) - u) / d;
    end
    
    lout = length(Xin);
    res = zeros(1, lout);
    for t = 1:lout
        res(t) = c(l);
        for i = l-1:-1:1
            res(t) = res(t) * (Xin(t) - X(i)) + c(i);
        end
    end
end

function err = count_err(Xin, Yout)
    err = 0;
    for i = 1:length(Xin)
        err_now = 1 / (1 + 25 * Xin(i) * Xin(i)) - Yout(i);
        if abs(err_now) > err
            err = abs(err_now);
        end
    end
end