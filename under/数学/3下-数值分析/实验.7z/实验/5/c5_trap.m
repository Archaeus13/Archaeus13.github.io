function res = c5_trap(f, r, N)
   arr = f([0:r/N:r]);
   res = arr(1) + arr(N+1); 
   for i = 2:N
       res = res + 2 * arr(i);
   end
   res = res * r / (2 * N);
end