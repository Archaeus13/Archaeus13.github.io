function res = c5_simp(f, r, N)
   arr = f([0:r/N:r]);
   res = arr(1) + arr(N+1); 
   for i = 1:N/2
       res = res + 2 * arr(2*i - 1) + 4 * arr(2 * i);
   end
   res = res * r / (3 * N);
end