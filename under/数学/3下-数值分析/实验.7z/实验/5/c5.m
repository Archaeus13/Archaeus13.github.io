fprintf('Task1:\n');
f = @(x) sin(x);
r = 4;
res = 1.653643620863612;
fprintf('N\t\terr1\t\t\tord1\t\t\terr2\t\t\tord2\n');
N = 2;
err1_old = abs(c5_simp(f, r, N) - res);
err2_old = abs(c5_trap(f, r, N) - res);
fprintf('2\t\t%e\t\t\t\t\t%e\n', err1_old, err2_old);
for i = 1:11
    N = N * 2;
    err1 = abs(c5_simp(f, r, N) - res);
    err2 = abs(c5_trap(f, r, N) - res);
    ord1 = log (err1_old / err1) / log(2);
    ord2 = log (err2_old / err2) / log(2);
    fprintf('%d\t\t%e\t\t%f\t\t%e\t\t%f\n', N, err1, ord1, err2, ord2);
    err1_old = err1;
    err2_old = err2;
end
fprintf('\nTask2:\n');
f = @(x)(1+25*x.^2).^(-1);
a = c5_lagrange;
res = 0.5493603067780064;
fprintf('N\tres1\t\t\terr1\t\t\tres2\t\t\terr2\n');
for i = 1:8
    res1 = a.lagrange_uni(f, 5*i);
    res2 = a.lagrange_ch(f, 5*i);
    err1 = abs(res - res1);
    err2 = abs(res - res2);
    fprintf('%d\t%f\t\t%e\t\t%f\t\t%e\n', 5*i, res1, err1, res2, err2);
end

