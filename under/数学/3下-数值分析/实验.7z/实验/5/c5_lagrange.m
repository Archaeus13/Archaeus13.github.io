function Funcollect = c5_lagrange
    Funcollect.lagrange_uni = @lagrange_uni;
    Funcollect.lagrange_ch = @lagrange_ch;
end

function res = lagrange_uni(f, N)
    X = [-1:2/N:1];
    Xin = f(X);
    res = count_res(X, Xin);
end

function res = lagrange_ch(f, N)
    X = zeros(1, N + 1);
    for i = 0:N
        X(i + 1) = -cos((i + 1) * pi / (N + 2));
    end
    Xin = f(X);
    res = count_res(X, Xin);
end

function res = count_res(X, Xin)
    syms x;
    N = length(Xin);
    p = 0;
    for i = 1:N
        temp = 1;
        for j = 1:N
            if j ~= i
                temp = temp * (x - X(j)) / (X(i) - X(j));
            end
        end
        p = p + temp * Xin(i);
    end
    res = double(int(p, x, -1, 1));
end