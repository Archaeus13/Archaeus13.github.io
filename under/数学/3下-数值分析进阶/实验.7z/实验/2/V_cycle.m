function v = V_cycle(f, sigma, omega, N, nu1, nu2, level)
    L = 2^N;
    h = 1 / L;
    v = zeros(1, L + 1);
    for i = 1:nu1
        v = wJacobiIter(v, f, sigma, omega);
    end
    if level > 0
        r = v;
        r(2:L) = f(2:L) - ((2 + sigma * h^2) * r(2:L) ...
            - r(1:L-1) - r(3:L+1)) / h^2;
        r(3:2:L-1) = r(3:2:L-1) / 2 + (r(2:2:L-2) + r(4:2:L)) / 4;
        r(1:2:L+1) = ...
            V_cycle(r(1:2:L+1), sigma, omega, N-1, nu1, nu2, level-1);
        r(2:2:L) = (r(1:2:L-1) + r(3:2:L+1)) / 2;
        v = v + r;
    end
    for i = 1:nu2
        v = wJacobiIter(v, f, sigma, omega);
    end
end

function v = wJacobiIter(v, f, sigma, omega)
    h = 1 / (length(v) - 1);
    v(2:end-1) = (1 - omega) * v(2:end-1) + omega * ...
        (v(1:end-2) + v(3:end) + h^2 * f(2:end-1)) / (2 + sigma * h^2);
end