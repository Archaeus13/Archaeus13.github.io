omega = 2/3;
sigma = 1;

N = 11;
x = 0:(1/2^N):1;
f = sin(2 * pi * x);
y = sin(2 * pi * x) / (pi^2 * 4 + sigma);
figure;
for l = 1:7
    res = V_cycle(f, sigma, omega, N, 100, 100, l);
    plot(x, res, "linewidth", 1.5, "DisplayName", "level = " + num2str(l));
    hold on;
end
plot(x, y, "black", "linewidth", 1.5, "DisplayName", "real");
legend;

N = 13;
x = 0:(1/2^N):1;
f = sin(2 * pi * x);
y = sin(2 * pi * x) / (pi^2 * 4 + sigma);
err1 = zeros(1, 11);
for l = 0:10
    res = V_cycle(f, sigma, omega, N, 200, 200, l);
    err1(l+1) = log(max(abs(y - res))) / log(10);
end

N = 11;
x = 0:(1/2^N):1;
f = 6 - 4 * x - 3 * x.^2 + x.^3;
y = x .* (1 - x) .* (2 - x);
figure;
for l = 1:7
    res = V_cycle(f, sigma, omega, N, 100, 100, l);
    plot(x, res, "linewidth", 1.5, "DisplayName", "level = " + num2str(l));
    hold on;
end
plot(x, y, "black", "linewidth", 1.5, "DisplayName", "real");
legend;

N = 13;
x = 0:(1/2^N):1;
f = 6 - 4 * x - 3 * x.^2 + x.^3;
y = x .* (1 - x) .* (2 - x);
err2 = zeros(1, 11);
for l = 0:10
    res = V_cycle(f, sigma, omega, N, 200, 200, l);
    err2(l+1) = log(max(abs(y - res))) / log(10);
end

figure;
plot(0:10, err1, 0:10, err2, "linewidth", 1.5);
legend("equation 1", "equation 2");