x = 0:1/64:1;
f = 0 * x;
res = 0 * x;
sigma = 0;
steps = 100;

method = "weighted-Jacobi";
omega = 2/3;
figure;
for k = 1:7:64
    v0 = sin(k * x * pi);
    loss = iteration(v0, f, sigma, steps, method, res, omega);
    plot(0:steps, log(loss) / log(10), 'DisplayName', "k = " + num2str(k));
    hold on;
end
legend;
hold off;

method = "Gauss-Seidel";
figure;
for k = 1:7:64
    v0 = sin(k * x * pi);
    loss = iteration(v0, f, sigma, steps, method, res, omega);
    plot(0:steps, log(loss) / log(10), 'DisplayName', "k = " + num2str(k));
    hold on;
end
legend;
hold off;

method = "red-black";
figure;
for k = 1:7:64
    v0 = sin(k * x * pi);
    loss = iteration(v0, f, sigma, steps, method, res, omega);
    plot(0:steps, log(loss) / log(10), 'DisplayName', "k = " + num2str(k));
    hold on;
end
legend;
hold off;