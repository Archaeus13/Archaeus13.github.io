function loss = iteration(v0, f, sigma, steps, method, res, omega)
    loss = zeros(1, steps + 1);
    v = v0;
    loss(1) = max(abs(v - res));
    for i = 1:steps
        if method == "weighted-Jacobi"
           v = wJacobiIter(v, f, sigma, omega);
        end
        if method == "Gauss-Seidel"
            v = GaussSeidel(v, f, sigma);
        end
        if method == "red-black"
            v = RBGaussSeidel(v, f, sigma);
        end
        loss(i + 1) = max(abs(v - res));
    end
end

function v = wJacobiIter(v, f, sigma, omega)
    h = 1 / (length(v) - 1);
    v(2:end-1) = (1 - omega) * v(2:end-1) + omega * ...
        (v(1:end-2) + v(3:end) + h^2 * f(2:end-1)) / (2 + sigma * h^2);
end

function v = GaussSeidel(v, f, sigma)
    h = 1 / (length(v) - 1);
    for i = 2:length(v)-1
        v(i) = (v(i-1) + v(i+1) + h^2 * f(i)) / (2 + sigma * h^2);
    end
end

function v = RBGaussSeidel(v, f, sigma)
    h = 1 / (length(v) - 1);
    v(3:2:end-1) = (v(2:2:end-2) + v(4:2:end) + h^2 * f(3:2:end-1)) / ...
        (2 + sigma * h^2);
    v(2:2:end-1) = (v(1:2:end-2) + v(3:2:end) + h^2 * f(2:2:end-1)) / ...
        (2 + sigma * h^2);
end