#pragma once
#include <iostream>
#include <vector>

#define RHO 0.3
#define SIGMA 0.5
#define MAX_ITER 500
#define TOL 1e-5


using namespace std;

double wp_search(vector<double>(*df)(vector<double>), double (*f)(vector<double>),
    vector<double> x0, vector<double> d);

int min_grad(vector<double>(*df)(vector<double>), double (*f)(vector<double>),
    vector<double>& x0);

int min_con_grad(vector<double>(*df)(vector<double>), double (*f)(vector<double>),
    vector<double>& x0);

int min_qua_newton(vector<double>(*df)(vector<double>), double (*f)(vector<double>),
    vector<double>& x0, int sr);

int min_grad1(vector<double>(*df)(vector<double>), double (*f)(vector<double>),
    vector<double>& x0);

int min_con_grad1(vector<double>(*df)(vector<double>), double (*f)(vector<double>),
    vector<double>& x0);

int min_qua_newton1(vector<double>(*df)(vector<double>), double (*f)(vector<double>),
    vector<double>& x0, int sr);