﻿#include "function.h"

#define d_abs(x) (x > 1e-7 ? 1 : (x < -1e-7 ? -1 : 0))

double f1(vector<double> x) {
    double ret = 0;
    for (int i = 0; i < x.size(); i++) ret += pow(x[i], 4);
    return ret;
}

vector<double> df1(vector<double> x) {
    for (int i = 0; i < x.size(); i++) x[i] = 4 * pow(x[i], 3);
    return x;
}

double f2(vector<double> x) {
    double ret = 0;
    for (int i = 1; i < x.size(); i++) ret += (x[i] - i * x[i - 1]) * (x[i] - i * x[i - 1]);
    ret += (x[0] - 1) * (x[0] - 1);
    return ret;
}

vector<double> df2(vector<double> x) {
    const int dim = x.size();
    vector<double> g(dim);
    g[0] = 2 * (x[0] - 1);
    for (int i = 1; i < x.size(); i++) {
        g[i] += 2 * (x[i] - i * x[i - 1]);
        g[i - 1] += 2 * i * (i * x[i - 1] - x[i]);
    }
    return g;
}

double f3(vector<double> x) {
    double ret = 0;
    for (int i = 1; i < x.size(); i++) ret += abs(x[i - 1] + 2 * x[i]);
    ret += abs(x[0] - 3);
    return ret;
}

vector<double> df3(vector<double> x) {
    const int dim = x.size();
    vector<double> g(dim);
    g[0] = d_abs(x[0] - 3);
    for (int i = 1; i < x.size(); i++) {
        g[i - 1] += d_abs(x[i - 1] + 2 * x[i]);
        g[i] += 2 * d_abs(x[i - 1] + 2 * x[i]);
    }
    return g;
}

double f4(vector<double> x) {
    double ret = 0;
    for (int i = 0; i < x.size() - 1; i++)
        ret += 100 * pow(x[i + 1] - x[i] * x[i], 2) + (x[i] - 1) * (x[i] - 1);
    return ret;
}

vector<double> df4(vector<double> x) {
    const int dim = x.size();
    vector<double> g(dim);
    for (int i = 0; i < x.size() - 1; i++) {
        g[i] += 400 * x[i] * (x[i] * x[i] - x[i + 1]) + 2 * (x[i] - 1);
        g[i + 1] += 200 * (x[i + 1] - x[i] * x[i]);
    }
    return g;
}

int main(void) {
    vector<double> x0;
    
    cout << "f1: " << endl;

    x0 = { 1,-3,10,-4,-5,50 };
    cout << endl;
    cout << "gradient iter:" << min_grad(df1, f1, x0) << endl;
    for (int i = 0; i < x0.size(); i++) cout << x0[i] << ' ';
    cout << endl << "f(x)= " << f1(x0) << endl;

    x0 = { 1,-3,10,-4,-5,50 };
    cout << endl;
    cout << "con-gradient iter:" << min_con_grad(df1, f1, x0) << endl;
    for (int i = 0; i < x0.size(); i++) cout << x0[i] << ' ';
    cout << endl << "f(x)= " << f1(x0) << endl;

    x0 = { 1,-3,10,-4,-5,50 };
    cout << endl;
    cout << "sr1 quasi newton iter:" << min_qua_newton(df1, f1, x0, 1) << endl;
    for (int i = 0; i < x0.size(); i++) cout << x0[i] << ' ';
    cout << endl << "f(x)= " << f1(x0) << endl;

    x0 = { 1,-3,10,-4,-5,50 };
    cout << endl;
    cout << "sr2 quasi newton iter:" << min_qua_newton(df1, f1, x0, 2) << endl;
    for (int i = 0; i < x0.size(); i++) cout << x0[i] << ' ';
    cout << endl << "f(x)= " << f1(x0) << endl;

    cout << endl;
    cout << "f2: " << endl;

    x0 = { 1,-3,10,-4,-5,50 };
    cout << endl;
    cout << "gradient iter:" << min_grad(df2, f2, x0) << endl;
    for (int i = 0; i < x0.size(); i++) cout << x0[i] << ' ';
    cout << endl << "f(x)= " << f2(x0) << endl;

    x0 = { 1,-3,10,-4,-5,50 };
    cout << endl;
    cout << "con-gradient iter:" << min_con_grad(df2, f2, x0) << endl;
    for (int i = 0; i < x0.size(); i++) cout << x0[i] << ' ';
    cout << endl << "f(x)= " << f2(x0) << endl;

    x0 = { 1,-3,10,-4,-5,50 };
    cout << endl;
    cout << "sr1 quasi newton iter:" << min_qua_newton(df2, f2, x0, 1) << endl;
    for (int i = 0; i < x0.size(); i++) cout << x0[i] << ' ';
    cout << endl << "f(x)= " << f2(x0) << endl;

    x0 = { 1,-3,10,-4,-5,50 };
    cout << endl;
    cout << "sr2 quasi newton iter:" << min_qua_newton(df2, f2, x0, 2) << endl;
    for (int i = 0; i < x0.size(); i++) cout << x0[i] << ' ';
    cout << endl << "f(x)= " << f2(x0) << endl;
    
    cout << endl;
    cout << "f3: " << endl;

    x0 = { 1,-3,10,-4,-5,50 };
    cout << endl;
    cout << "gradient iter:" << min_grad(df3, f3, x0) << endl;
    for (int i = 0; i < x0.size(); i++) cout << x0[i] << ' ';
    cout << endl << "f(x)= " << f3(x0) << endl;

    x0 = { 1,-3,10,-4,-5,50 };
    cout << endl;
    cout << "con-gradient iter:" << min_con_grad(df3, f3, x0) << endl;
    for (int i = 0; i < x0.size(); i++) cout << x0[i] << ' ';
    cout << endl << "f(x)= " << f3(x0) << endl;

    x0 = { 1,-3,10,-4,-5,50 };
    cout << endl;
    cout << "sr1 quasi newton iter:" << min_qua_newton(df3, f3, x0, 1) << endl;
    for (int i = 0; i < x0.size(); i++) cout << x0[i] << ' ';
    cout << endl << "f(x)= " << f3(x0) << endl;

    x0 = { 1,-3,10,-4,-5,50 };
    cout << endl;
    cout << "sr2 quasi newton iter:" << min_qua_newton(df3, f3, x0, 2) << endl;
    for (int i = 0; i < x0.size(); i++) cout << x0[i] << ' ';
    cout << endl << "f(x)= " << f3(x0) << endl;

    cout << endl;
    cout << "f4: " << endl;

    x0 = { 1,-3,10,-4,-5,50 };
    cout << endl;
    cout << "gradient iter:" << min_grad(df4, f4, x0) << endl;
    for (int i = 0; i < x0.size(); i++) cout << x0[i] << ' ';
    cout << endl << "f(x)= " << f4(x0) << endl;

    x0 = { 1,-3,10,-4,-5,50 };
    cout << endl;
    cout << "con-gradient iter:" << min_con_grad(df4, f4, x0) << endl;
    for (int i = 0; i < x0.size(); i++) cout << x0[i] << ' ';
    cout << endl << "f(x)= " << f4(x0) << endl;

    x0 = { 1,-3,10,-4,-5,50 };
    cout << endl;
    cout << "sr1 quasi newton iter:" << min_qua_newton(df4, f4, x0, 1) << endl;
    for (int i = 0; i < x0.size(); i++) cout << x0[i] << ' ';
    cout << endl << "f(x)= " << f4(x0) << endl;

    x0 = { 1,-3,10,-4,-5,50 };
    cout << endl;
    cout << "sr2 quasi newton iter:" << min_qua_newton(df4, f4, x0, 2) << endl;
    for (int i = 0; i < x0.size(); i++) cout << x0[i] << ' ';
    cout << endl << "f(x)= " << f4(x0) << endl;

    cout << endl;
    cout << "f1 without wp: " << endl;

    x0 = { 1,-3,10,-4,-5,50 };
    cout << endl;
    cout << "gradient iter:" << min_grad1(df1, f1, x0) << endl;
    for (int i = 0; i < x0.size(); i++) cout << x0[i] << ' ';
    cout << endl << "f(x)= " << f1(x0) << endl;

    x0 = { 1,-3,10,-4,-5,50 };
    cout << endl;
    cout << "con-gradient iter:" << min_con_grad1(df1, f1, x0) << endl;
    for (int i = 0; i < x0.size(); i++) cout << x0[i] << ' ';
    cout << endl << "f(x)= " << f1(x0) << endl;

    x0 = { 1,-3,10,-4,-5,50 };
    cout << endl;
    cout << "sr1 quasi newton iter:" << min_qua_newton1(df1, f1, x0, 1) << endl;
    for (int i = 0; i < x0.size(); i++) cout << x0[i] << ' ';
    cout << endl << "f(x)= " << f1(x0) << endl;

    x0 = { 1,-3,10,-4,-5,50 };
    cout << endl;
    cout << "sr2 quasi newton iter:" << min_qua_newton1(df1, f1, x0, 2) << endl;
    for (int i = 0; i < x0.size(); i++) cout << x0[i] << ' ';
    cout << endl << "f(x)= " << f1(x0) << endl;

    cout << endl;
    cout << "f2 without wp: " << endl;

    x0 = { 1,-3,10,-4,-5,50 };
    cout << endl;
    cout << "gradient iter:" << min_grad1(df2, f2, x0) << endl;
    for (int i = 0; i < x0.size(); i++) cout << x0[i] << ' ';
    cout << endl << "f(x)= " << f2(x0) << endl;

    x0 = { 1,-3,10,-4,-5,50 };
    cout << endl;
    cout << "con-gradient iter:" << min_con_grad1(df2, f2, x0) << endl;
    for (int i = 0; i < x0.size(); i++) cout << x0[i] << ' ';
    cout << endl << "f(x)= " << f2(x0) << endl;

    x0 = { 1,-3,10,-4,-5,50 };
    cout << endl;
    cout << "sr1 quasi newton iter:" << min_qua_newton1(df2, f2, x0, 1) << endl;
    for (int i = 0; i < x0.size(); i++) cout << x0[i] << ' ';
    cout << endl << "f(x)= " << f2(x0) << endl;

    x0 = { 1,-3,10,-4,-5,50 };
    cout << endl;
    cout << "sr2 quasi newton iter:" << min_qua_newton1(df2, f2, x0, 2) << endl;
    for (int i = 0; i < x0.size(); i++) cout << x0[i] << ' ';
    cout << endl << "f(x)= " << f2(x0) << endl;

    cout << endl;
    cout << "f3 without wp: " << endl;

    x0 = { 1,-3,10,-4,-5,50 };
    cout << endl;
    cout << "gradient iter:" << min_grad1(df3, f3, x0) << endl;
    for (int i = 0; i < x0.size(); i++) cout << x0[i] << ' ';
    cout << endl << "f(x)= " << f3(x0) << endl;

    x0 = { 1,-3,10,-4,-5,50 };
    cout << endl;
    cout << "con-gradient iter:" << min_con_grad1(df3, f3, x0) << endl;
    for (int i = 0; i < x0.size(); i++) cout << x0[i] << ' ';
    cout << endl << "f(x)= " << f3(x0) << endl;

    x0 = { 1,-3,10,-4,-5,50 };
    cout << endl;
    cout << "sr1 quasi newton iter:" << min_qua_newton1(df3, f3, x0, 1) << endl;
    for (int i = 0; i < x0.size(); i++) cout << x0[i] << ' ';
    cout << endl << "f(x)= " << f3(x0) << endl;

    x0 = { 1,-3,10,-4,-5,50 };
    cout << endl;
    cout << "sr2 quasi newton iter:" << min_qua_newton1(df3, f3, x0, 2) << endl;
    for (int i = 0; i < x0.size(); i++) cout << x0[i] << ' ';
    cout << endl << "f(x)= " << f3(x0) << endl;

    cout << endl;
    cout << "f4 without wp: " << endl;

    x0 = { 1,-3,10,-4,-5,50 };
    cout << endl;
    cout << "gradient iter:" << min_grad1(df4, f4, x0) << endl;
    for (int i = 0; i < x0.size(); i++) cout << x0[i] << ' ';
    cout << endl << "f(x)= " << f4(x0) << endl;

    x0 = { 1,-3,10,-4,-5,50 };
    cout << endl;
    cout << "con-gradient iter:" << min_con_grad1(df4, f4, x0) << endl;
    for (int i = 0; i < x0.size(); i++) cout << x0[i] << ' ';
    cout << endl << "f(x)= " << f4(x0) << endl;

    x0 = { 1,-3,10,-4,-5,50 };
    cout << endl;
    cout << "sr1 quasi newton iter:" << min_qua_newton1(df4, f4, x0, 1) << endl;
    for (int i = 0; i < x0.size(); i++) cout << x0[i] << ' ';
    cout << endl << "f(x)= " << f4(x0) << endl;

    x0 = { 1,-3,10,-4,-5,50 };
    cout << endl;
    cout << "sr2 quasi newton iter:" << min_qua_newton1(df4, f4, x0, 2) << endl;
    for (int i = 0; i < x0.size(); i++) cout << x0[i] << ' ';
    cout << endl << "f(x)= " << f4(x0) << endl;

    cout << endl;
    cout << "f1 with better x0" << endl;

    x0 = { 1,-3,2,-4,-5,3 };
    cout << endl;
    cout << "gradient iter:" << min_grad(df1, f1, x0) << endl;
    for (int i = 0; i < x0.size(); i++) cout << x0[i] << ' ';
    cout << endl << "f(x)= " << f1(x0) << endl;

    x0 = { 1,-3,2,-4,-5,3 };
    cout << endl;
    cout << "con-gradient iter:" << min_con_grad(df1, f1, x0) << endl;
    for (int i = 0; i < x0.size(); i++) cout << x0[i] << ' ';
    cout << endl << "f(x)= " << f1(x0) << endl;

    x0 = { 1,-3,2,-4,-5,3 };
    cout << endl;
    cout << "sr1 quasi newton iter:" << min_qua_newton(df1, f1, x0, 1) << endl;
    for (int i = 0; i < x0.size(); i++) cout << x0[i] << ' ';
    cout << endl << "f(x)= " << f1(x0) << endl;

    x0 = { 1,-3,2,-4,-5,3 };
    cout << endl;
    cout << "sr2 quasi newton iter:" << min_qua_newton(df1, f1, x0, 2) << endl;
    for (int i = 0; i < x0.size(); i++) cout << x0[i] << ' ';
    cout << endl << "f(x)= " << f1(x0) << endl;

    cout << endl;
    cout << "f1 with worse x0" << endl;

    x0 = { 1,-3,2000,-4,-500,3 };
    cout << endl;
    cout << "gradient iter:" << min_grad(df1, f1, x0) << endl;
    for (int i = 0; i < x0.size(); i++) cout << x0[i] << ' ';
    cout << endl << "f(x)= " << f1(x0) << endl;

    x0 = { 1,-3,2000,-4,-500,3 };
    cout << endl;
    cout << "con-gradient iter:" << min_con_grad(df1, f1, x0) << endl;
    for (int i = 0; i < x0.size(); i++) cout << x0[i] << ' ';
    cout << endl << "f(x)= " << f1(x0) << endl;

    x0 = { 1,-3,2000,-4,-500,3 };
    cout << endl;
    cout << "sr1 quasi newton iter:" << min_qua_newton(df1, f1, x0, 1) << endl;
    for (int i = 0; i < x0.size(); i++) cout << x0[i] << ' ';
    cout << endl << "f(x)= " << f1(x0) << endl;

    x0 = { 1,-3,2000,-4,-500,3 };
    cout << endl;
    cout << "sr2 quasi newton iter:" << min_qua_newton(df1, f1, x0, 2) << endl;
    for (int i = 0; i < x0.size(); i++) cout << x0[i] << ' ';
    cout << endl << "f(x)= " << f1(x0) << endl;

    cout << endl;
    cout << "f4 with better x0" << endl;

    x0 = { 1,-3,1,-4,-5,5 };
    cout << endl;
    cout << "gradient iter:" << min_grad(df4, f4, x0) << endl;
    for (int i = 0; i < x0.size(); i++) cout << x0[i] << ' ';
    cout << endl << "f(x)= " << f4(x0) << endl;

    x0 = { 1,-3,1,-4,-5,5 };
    cout << endl;
    cout << "con-gradient iter:" << min_con_grad(df4, f4, x0) << endl;
    for (int i = 0; i < x0.size(); i++) cout << x0[i] << ' ';
    cout << endl << "f(x)= " << f4(x0) << endl;

    x0 = { 1,-3,1,-4,-5,5 };
    cout << endl;
    cout << "sr1 quasi newton iter:" << min_qua_newton(df4, f4, x0, 1) << endl;
    for (int i = 0; i < x0.size(); i++) cout << x0[i] << ' ';
    cout << endl << "f(x)= " << f4(x0) << endl;

    x0 = { 1,-3,1,-4,-5,5 };
    cout << endl;
    cout << "sr2 quasi newton iter:" << min_qua_newton(df4, f4, x0, 2) << endl;
    for (int i = 0; i < x0.size(); i++) cout << x0[i] << ' ';
    cout << endl << "f(x)= " << f4(x0) << endl;

    cout << endl;
    cout << "f4 with better x0 without wp" << endl;

    x0 = { 1,-3,1,-4,-5,5 };
    cout << endl;
    cout << "gradient iter:" << min_grad1(df4, f4, x0) << endl;
    for (int i = 0; i < x0.size(); i++) cout << x0[i] << ' ';
    cout << endl << "f(x)= " << f4(x0) << endl;

    x0 = { 1,-3,1,-4,-5,5 };
    cout << endl;
    cout << "con-gradient iter:" << min_con_grad1(df4, f4, x0) << endl;
    for (int i = 0; i < x0.size(); i++) cout << x0[i] << ' ';
    cout << endl << "f(x)= " << f4(x0) << endl;

    x0 = { 1,-3,1,-4,-5,5 };
    cout << endl;
    cout << "sr1 quasi newton iter:" << min_qua_newton1(df4, f4, x0, 1) << endl;
    for (int i = 0; i < x0.size(); i++) cout << x0[i] << ' ';
    cout << endl << "f(x)= " << f4(x0) << endl;

    x0 = { 1,-3,1,-4,-5,5 };
    cout << endl;
    cout << "sr2 quasi newton iter:" << min_qua_newton1(df4, f4, x0, 2) << endl;
    for (int i = 0; i < x0.size(); i++) cout << x0[i] << ' ';
    cout << endl << "f(x)= " << f4(x0) << endl;

    cout << endl;
    cout << "f4 with worse x0" << endl;

    x0 = { 1,-3,200,-4,-500,3 };
    cout << endl;
    cout << "gradient iter:" << min_grad(df4, f4, x0) << endl;
    for (int i = 0; i < x0.size(); i++) cout << x0[i] << ' ';
    cout << endl << "f(x)= " << f4(x0) << endl;

    x0 = { 1,-3,200,-4,-500,3 };
    cout << endl;
    cout << "con-gradient iter:" << min_con_grad(df4, f4, x0) << endl;
    for (int i = 0; i < x0.size(); i++) cout << x0[i] << ' ';
    cout << endl << "f(x)= " << f4(x0) << endl;

    x0 = { 1,-3,200,-4,-500,3 };
    cout << endl;
    cout << "sr1 quasi newton iter:" << min_qua_newton(df4, f4, x0, 1) << endl;
    for (int i = 0; i < x0.size(); i++) cout << x0[i] << ' ';
    cout << endl << "f(x)= " << f4(x0) << endl;

    x0 = { 1,-3,200,-4,-500,3 };
    cout << endl;
    cout << "sr2 quasi newton iter:" << min_qua_newton(df4, f4, x0, 2) << endl;
    for (int i = 0; i < x0.size(); i++) cout << x0[i] << ' ';
    cout << endl << "f(x)= " << f4(x0) << endl;
}
