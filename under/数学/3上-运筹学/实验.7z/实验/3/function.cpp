#include "function.h"

double dot(vector<double> x, vector<double> y) {
    double ret = 0;
    for (int i = 0; i < x.size(); i++) ret += x[i] * y[i];
    return ret;
}

vector<double> bi_com(double a, vector<double> x, double b, vector<double> y) {
    for (int i = 0; i < x.size(); i++) x[i] = a * x[i] + b * y[i];
    return x;
}

vector<double> bi_com(vector<double> x, double b, vector<double> y) {
    for (int i = 0; i < x.size(); i++) x[i] += b * y[i];
    return x;
}

vector<double> bi_com(vector<double> x, vector<double> y) {
    for (int i = 0; i < x.size(); i++) x[i] += y[i];
    return x;
}

vector<double> bi_com(double a, vector<double> x) {
    for (int i = 0; i < x.size(); i++) x[i] *= a;
    return x;
}

double inf_norm(vector<double> x) {
    double max = -1;
    for (int i = 0; i < x.size(); i++)
        if (abs(x[i]) > max) max = abs(x[i]);
    return max;
}

double wp_search(vector<double>(*df)(vector<double>), double (*f)(vector<double>),
    vector<double> x, vector<double> d) {
    const double phip0 = dot(d, df(x)), phi0 = f(x);
    if (phip0 >= 0) {
        cout << "warning: direction choosed not a decrement" << endl;
        return 0;
    }
    double begin = 0, end = 2;
    int count = 0;
    double phip1 = phip0, phi1 = phi0;
    while (dot(d, df(bi_com(x, end, d))) < 0) {
        end *= 2;
        count++;
        if (count == 10) {
            cout << "warning: perhaps d too small" << endl;
            return end;
        }
    }
    double now = end / 2;
    count = 0;
    while (count < MAX_ITER) {
        count++;
        vector<double> x_now = bi_com(x, now, d);
        double phi = f(x_now);
        //cout << "phi: " << phi << endl;
        //cout << "judge1: " << phi0 + RHO * now * phip0 << endl;
        if (phi > phi0 + RHO * now * phip0) {
            end = now;
            now = begin + (begin - now) * (begin - now) * phip1 / (phi1 - phi + (now - begin) * phip1) / 2;
            continue;
        }
        double phip = dot(d, df(x_now));
        //cout << "phip: " << phip << endl;
        //cout << "judge2: " << SIGMA * phip0 << endl;
        if (phip < SIGMA * phip0) {
            double temp = now;
            now += (now - begin) * phip / (phip1 - phip);
            begin = temp;
            phi1 = phi;
            phip1 = phip;
            continue;
        }
        //cout << endl;
        return now;
    }
    cout << "warning: too many searches" << endl;
    return now;
}

int min_grad(vector<double>(*df)(vector<double>), double (*f)(vector<double>),
    vector<double>& x0) {
    int count = 0;
    while (count < MAX_ITER) {
        count++;
        vector<double> g = df(x0);
        if (inf_norm(g) < TOL) return count;
        double a = wp_search(df, f, x0, bi_com(-1, g));
        x0 = bi_com(x0, -a, g);
    }
    cout << "reached max iter" << endl;
    return count;
}

int min_con_grad(vector<double>(*df)(vector<double>), double (*f)(vector<double>),
    vector<double>& x0) {
    const int dim = x0.size();
    int count = 0;
    vector<double> g(dim), d(dim);
    while (count < MAX_ITER) {
        count++;
        double beta = dot(g, g);
        g = df(x0);
        if (inf_norm(g) < TOL) return count;
        if (count % dim == 1) d = bi_com(-1, g);
        else {
            beta = dot(g, g) / beta;
            d = bi_com(-1, g, beta, d);
        }
        double a = wp_search(df, f, x0, d);
        x0 = bi_com(x0, a, d);
    }
    cout << "reached max iter" << endl;
    return count;
}

vector<double> count_d(vector<vector<double>> H, vector<double> g) {
    const int dim = g.size();
    vector<double> d(dim);
    for (int i = 0; i < dim; i++)
        for (int j = 0; j < dim; j++)
            d[i] -= H[i][j] * g[j];
    return d;
}

void count_H2(vector<double> s, vector<double> y, vector<vector<double>>& H) {
    const int dim = s.size();
    vector<double> Hy(dim);
    for (int i = 0; i < dim; i++)
        for (int j = 0; j < dim; j++)
            Hy[i] += H[i][j] * y[j];
    double a = 1 / dot(s, y), b = 1 / dot(Hy, y);
    for (int i = 0; i < dim; i++)
        for (int j = 0; j < dim; j++) {
            H[i][j] += s[i] * s[j] * a;
            H[i][j] -= Hy[i] * Hy[j] * b;
        }
}

void count_H1(vector<double> s, vector<double> y, vector<vector<double>>& H) {
    const int dim = s.size();
    vector<double> Hy(dim);
    for (int i = 0; i < dim; i++)
        for (int j = 0; j < dim; j++)
            Hy[i] += H[i][j] * y[j];
    s = bi_com(s, -1, Hy);
    double a = 1 / dot(s, y);
    for (int i = 0; i < dim; i++)
        for (int j = 0; j < dim; j++) {
            H[i][j] += s[i] * s[j] * a;
        }
}

int min_qua_newton(vector<double>(*df)(vector<double>), double (*f)(vector<double>),
    vector<double>& x0, int sr) {
    const int dim = x0.size();
    int count = 0;
    vector<vector<double>> H(dim, vector<double>(dim));
    for (int i = 0; i < dim; i++) H[i][i] = 1;
    while (count < MAX_ITER) {
        count++;
        vector<double> g = df(x0);
        if (inf_norm(g) < TOL) return count;
        vector<double> d = count_d(H, g);
        double a = wp_search(df, f, x0, d);
        x0 = bi_com(x0, a, d);
        vector<double> s = bi_com(a, d);
        vector<double> y = bi_com(df(x0), -1, g);
        if (sr == 2) count_H2(s, y, H);
        else count_H1(s, y, H);
    }
    cout << "reached max iter" << endl;
    return count;
}

int min_grad1(vector<double>(*df)(vector<double>), double (*f)(vector<double>),
    vector<double>& x0) {
    int count = 0;
    while (count < MAX_ITER) {
        count++;
        vector<double> g = df(x0);
        if (inf_norm(g) < TOL) return count;
        x0 = bi_com(x0, -0.2, g);
    }
    cout << "reached max iter" << endl;
    return count;
}

int min_con_grad1(vector<double>(*df)(vector<double>), double (*f)(vector<double>),
    vector<double>& x0) {
    const int dim = x0.size();
    int count = 0;
    vector<double> g(dim), d(dim);
    while (count < MAX_ITER) {
        count++;
        double beta = dot(g, g);
        g = df(x0);
        if (inf_norm(g) < TOL) return count;
        if (count % dim == 1) d = bi_com(-1, g);
        else {
            beta = dot(g, g) / beta;
            d = bi_com(-1, g, beta, d);
        }
        x0 = bi_com(x0, 0.2, d);
    }
    cout << "reached max iter" << endl;
    return count;
}

int min_qua_newton1(vector<double>(*df)(vector<double>), double (*f)(vector<double>),
    vector<double>& x0, int sr) {
    const int dim = x0.size();
    int count = 0;
    vector<vector<double>> H(dim, vector<double>(dim));
    for (int i = 0; i < dim; i++) H[i][i] = 1;
    while (count < MAX_ITER) {
        count++;
        vector<double> g = df(x0);
        if (inf_norm(g) < TOL) return count;
        vector<double> d = count_d(H, g);
        x0 = bi_com(x0, 0.2, d);
        vector<double> s = d;
        vector<double> y = bi_com(df(x0), -1, g);
        if (sr == 2) count_H2(s, y, H);
        else count_H1(s, y, H);
    }
    cout << "reached max iter" << endl;
    return count;
}