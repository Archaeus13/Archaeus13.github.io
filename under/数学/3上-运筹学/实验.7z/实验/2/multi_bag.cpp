#include <iostream>
#include <fstream>
#include <vector>

using namespace std;

int bag_multi(int n, vector<int> w, vector<int> c, vector<int> m) {
    const int v = c.size();

    // binary separate
    vector<int> seq;
    vector<int> num;

    for (int i = 0; i < v; i++) {
        int temp = 1;
        while (m[i] > temp) {
            m[i] -= temp;
            seq.push_back(i);
            num.push_back(temp);
            temp = temp << 1;
        }
        seq.push_back(i);
        num.push_back(m[i]);
    }

    // dp
    const int t = seq.size();
    vector<vector<int>> f(t+1, vector<int>(n+1));
    vector<vector<bool>> choice(t+1, vector<bool>(n+1));
    for (int i = 1; i <= t; i++) {
        int w0 = w[seq[i-1]] * num[i-1];
        int c0 = c[seq[i-1]] * num[i-1];
        for (int j = 1; j <= n; j++) {
            int temp = -1;
            if (j >= w0) temp = f[i-1][j-w0] + c0;
            if (f[i-1][j] >= temp) {
                f[i][j] = f[i-1][j];
                choice[i][j] = 0;
            }
            else {
                f[i][j] = temp;
                choice[i][j] = 1;
            }
        }
    }
    cout << "best value: " << f[t][n] << endl;

    // print choice
    cout << "choice: " << endl;
    vector<int> ch(v);
    int a = n;
    for (int i = t; i > 0; i--)
        if (choice[i][a]) {
            ch[seq[i-1]] += num[i-1];
            a -= w[seq[i-1]] * num[i-1];
        }
    for (int j = 0; j < v; j++) cout << ch[j] << endl;
    return f[t][n];
}

int main(int argc, char** argv) {
    if (argc < 2) return -1;
    ifstream infile;
    infile.open(argv[1], ios::in);
    int n, t;
    infile >> n >> t;
    vector<int> w(t);
    vector<int> c(t);
    vector<int> m(t);
    for (int i = 0; i < t; i++)
        infile >> w[i] >> c[i] >> m[i];
    infile.close();
    bag_multi(n, w, c, m);
    return 0;
}