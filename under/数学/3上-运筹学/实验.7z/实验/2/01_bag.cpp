#include <iostream>
#include <fstream>
#include <vector>

using namespace std;

int bag_01(int n, vector<int> w, vector<int> c) {
    const int t = c.size();
    vector<vector<int>> f(t+1, vector<int>(n+1));
    vector<vector<bool>> choice(t+1, vector<bool>(n+1));
    for (int i = 1; i <= t; i++)
        for (int j = 1; j <= n; j++) {
            int temp = -1;
            if (j >= w[i-1]) temp = f[i-1][j-w[i-1]] + c[i-1];
            if (f[i-1][j] >= temp) {
                f[i][j] = f[i-1][j];
                choice[i][j] = 0;
            }
            else {
                f[i][j] = temp;
                choice[i][j] = 1;
            }
        }
    cout << "best value: " << f[t][n] << endl;
    cout << "choice: " << endl;
    int a = n; 
    for (int i = t; i > 0; i--)
        if (choice[i][a]) {
            cout << i << endl;
            a -= w[i-1];
        }
    return f[t][n];
}

int main(int argc, char** argv) {
    if (argc < 2) return -1;
    ifstream infile;
    infile.open(argv[1], ios::in);
    int n, t;
    infile >> n >> t;
    vector<int> w(t);
    vector<int> c(t);
    for (int i = 0; i < t; i++)
        infile >> w[i] >> c[i];
    infile.close();
    bag_01(n, w, c);
    return 0;
}