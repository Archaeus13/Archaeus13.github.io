#include <iostream>
#include <fstream>
#include <vector>

using namespace std;

void print_result(vector<vector<char>> t, string a) {
    int m = t.size() - 1;
    int n = t[0].size() - 1;
    string d = "";
    while (m >= 0 && n >= 0) {
        if (t[m][n] == 'd') {
            d = a[m] + d;
            m--;
            n--;
        }
        else if (t[m][n] == 'u') m--;
        else n--;
    }
    cout << d << endl;
}

int longest_common_subsequence(string a, string b) {
    int m = a.length(), n = b.length();
    vector<vector<int>> c(m+1, vector<int>(n+1));
    vector<vector<char>> t(m, vector<char>(n));
    for (int i = 0; i < m; i++) for (int j = 0; j < n; j++) {
        if (a[i] == b[j]) {
            c[i+1][j+1] = c[i][j] + 1;
            t[i][j] = 'd';
        }
        else if (c[i][j+1] > c[i+1][j]) {
            c[i+1][j+1] = c[i][j+1];
            t[i][j] = 'u';
        }
        else {
            c[i+1][j+1] = c[i+1][j];
            t[i][j] = 'l';
        }
    }
    cout << "length: " << c[m][n] << endl;
    print_result(t, a);
    return c[m][n];
}

int main(void) {
    ifstream infile;
    int num;
    string a, b;
    infile.open("in.txt", ios::in);
    while (infile >> num) {
        infile >> a;
        infile >> b;
        cout << '-' << num << '-' << endl;
        longest_common_subsequence(a, b);
    }
    infile.close();
}