#include <iostream>
#include <fstream>
#include <vector>

#define INFTY 1 << 14
#define ALPHA 0.8

using namespace std;

struct original_node {
    int end;
    int l;
    int u;
    int cost;
    int x;
};

struct node {
    int end;
    int cost;
    int x;
};

class original_graph {
private:
    int vecnum;
    int edgenum;
    vector<int> dif;
    vector<vector<original_node>> e;
public:
    vector<vector<original_node>> get_edges(void) { return e; }
    int get_vec_num(void) { return vecnum; }
    int get_edge_num(void) { return edgenum; }
    vector<int> get_dif(void) { return dif; }
    void readfile(string path);
    void count_flow(vector<vector<node>> edges);
    void output(string path);
};

class min_cost_graph {
private:
    int vec;
    vector<vector<node>> e;
    vector<int> b;
    vector<int> dif;
    vector<int> pi;
    vector<int> classify;
    bool judge_and_modify(int& delta);
    void scale_by_delta(int delta);
    void reconstruct(void);
public:
    vector<vector<node>> get_edges(void) { return e; }
    void init(original_graph G);
    void count(void);
};
