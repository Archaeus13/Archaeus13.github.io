﻿#include "min_cost.h"

void original_graph::readfile(string path) {
    ifstream in;
    in.open(path, ios::in);
    in >> vecnum;
    edgenum = 0;
    vector<vector<original_node>> a(vecnum);
    vector<int> dif0(vecnum);
    int s;
    original_node now;
    while (in >> s >> now.end >> now.l >> now.u >> now.cost) {
        now.x = now.l;
        a[s].push_back(now);
        dif0[s] -= now.x;
        dif0[now.end] += now.x;
        edgenum++;
    }
    in.close();
    e = a;
    dif = dif0;
}

void original_graph::count_flow(vector<vector<node>> edges) {
    int count = vecnum;
    for (int i = 0; i < vecnum; i++) {
        for (int j = 0; j < e[i].size(); j++) {
            for (int k = 0; k < edges[i].size(); k++)
                if (edges[i][k].end == count) {
                    e[i][j].x += edges[i][k].x;
                    break;
                }
            count++;
        }
    }
}

void original_graph::output(string path) {
    ofstream out;
    out.open(path, ios::out);
    for (int i = 0; i < vecnum; i++) {
        for (int j = 0; j < e[i].size(); j++) {
            original_node now = e[i][j];
            out << i << '\t' << now.end << '\t' << now.x << endl;
        }
    }
    out.close();
}

void min_cost_graph::init(original_graph G) {
    int vecnum = G.get_vec_num();
    vec = vecnum + G.get_edge_num() + 1;
    vector<vector<original_node>> t = G.get_edges();
    vector<int> d = G.get_dif();
    vector<int> b0(vec);
    vector<vector<node>> a(vec);
    e = a;
    b = b0;
    pi = b0;
    classify = b0;
    for (int i = 0; i < vecnum; i++)
        b[i] = d[i];
    node now;
    now.end = vecnum;
    for (int i = 0; i < vecnum; i++) {
        for (int j = 0; j < t[i].size(); j++) {
            original_node td = t[i][j];
            now.cost = td.cost;
            e[i].push_back(now);
            now.cost = 0;
            e[td.end].push_back(now);
            b[td.end] += td.u - td.l;
            b[now.end] -= td.u - td.l;
            now.end++;
        }
    }
    now.cost = INFTY;
    for (int i = 0; i < vec - 1; i++)
        e[i].push_back(now);
    for (int i = 0; i < vec - 1; i++) {
        now.end = i;
        e[vec - 1].push_back(now);
    }
    for (int i = 0; i < vec - 1; i++)
        classify[i] = i;
    dif = b;

    for (int i = 0; i < vec; i++) {
        for (int j = 0; j < e[i].size(); j++) {
            node now = e[i][j];
            cout << i << '\t' << now.end << '\t' << now.cost << endl;
        }
        cout << "b" << i << "=" << b[i] << ' ';
        cout << "pi" << i << "=" << pi[i] << ' ';
        cout << "class" << i << "=" << classify[i] << endl;
    }
    
}

bool min_cost_graph::judge_and_modify(int& delta) {
    bool flag = false;
    int m = 0;
    for (int i = 0; i < vec; i++)
        if (dif[i] != 0) {
            flag = true;
            if (dif[i] >= m) m = dif[i];
        }
    if (!flag) return true;
    if (m >= delta) return false;
    for (int i = 0; i < vec; i++) {
        for (int j = 0; j < e[i].size(); j++)
            if (e[i][j].x != 0) return false;
    }
    delta = m;
    return false;
}

void min_cost_graph::scale_by_delta(int delta) {
    for (int i = 0; i < vec; i++)
        for (int j = 0; j < e[i].size(); j++) {
            if (e[i][j].x >= 3 * vec * delta) {
                int end = e[i][j].end;
                dif[classify[i]] += dif[classify[end]];
                int endc = classify[end];
                for (int k = 0; k < vec; k++) {
                    if (classify[k] == endc)
                        classify[k] = classify[i];
                }    
            }
        }
    vector<int> centers;
    for (int i = 0; i < vec; i++)
        if (classify[i] == i)
            centers.push_back(i);
    int size = centers.size();
    while (1) {
        int k = -1, v = -1;
        for (int i = 0; i < size; i++) {
            if (dif[centers[i]] >= ALPHA * delta) k = centers[i];
            if (dif[centers[i]] <= -ALPHA * delta) v = centers[i];
        }
        if (k == -1 || v == -1) return;
        vector<int> dis(size), pre(size);
        for (int i = 0; i < size; i++) pre[i] = -1;
        // To Be Done 感觉这么做到不了复杂度要求，但C++表示合并过于复杂
    }
    
}

void min_cost_graph::reconstruct(void) {
    dif = b;
    for (int i = 0; i < vec; i++)
        for (int j = 0; j < e[i].size(); j++) {
            int end = e[i][j].end;
            if (e[i][j].cost - pi[i] + pi[end] > 0)
                e[i][j].cost = INFTY;
            e[i][j].x = 0;
        }
    // To Be Done 用EK算法当最大流问题找可行流
}

void min_cost_graph::count(void) {
    int delta = INFTY;
    while (1) {
        if (judge_and_modify(delta)) break;
        scale_by_delta(delta);
        delta /= 2;
    }
    reconstruct();
}

int main(void) {
    string in_path = "in.txt";
    original_graph G0;
    min_cost_graph G;
    G0.readfile(in_path);
    G.init(G0);
    G0.count_flow(G.get_edges());
    G0.output("test.txt");
}

