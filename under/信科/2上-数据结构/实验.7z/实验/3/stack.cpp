#include <iostream>
using namespace::std;

struct stack{
	ElemType n;
	stack* next;
};

int InitStack(stack* &p) {
	p = new stack;
	p->next = NULL;
	return 0;
}

int DestroyStack(stack* &p) {
	if (!p)	return -1;
	stack* q;
	while (p) {
		q = p;
		p = p->next;
		delete q;
	}
	p = NULL; 
	return 0;
}

int Push(stack* &p, ElemType a) {
	if (!p) return -1;	
	p->n = a;
	stack* s = new stack;
	s->next = p;
	p = s;
	return 0;
}

int Pop(stack* &p, ElemType &a) {
	if (!p) return -1;
	if (!p->next) return 1;
	stack* s = p;
	p = p->next;
	a = p->n;
	delete s;
	return 0;
}

int IsEmpty(stack*p) {
	if (!p) return -1;
	if (!p->next) return 1;
	return 0;
}
