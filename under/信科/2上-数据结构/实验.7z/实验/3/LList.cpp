#include <iostream>
#include <fstream>
using namespace std;

struct node{
	int end;
	int length;
	node* next;
};

#define ElemType node*
#include "stack.cpp"
#include "queue.cpp"

#define INFTY 10000
class Graph{
	private:
	int vexnum;
	node **v;
	void NewEdge(int start, int end, int length);
	int D(int start, int end);
	void InitCandidateSet(int T[][3]);
	int SelectLightEdge(int T[][3], int k);
	void ModifyCandidateSet(int T[][3], int k, int v);
	void PrintTree(int T[][3]);
	void InitPath(bool S[], int Parent[], int Distance[]);
	void FindPath(bool S[], int Parent[], int Distance[]);
	void PrintPath(int Parent[], int Distance[]);
	
	public:
	void Init(const char* s);
	void Destroy(void);
	void Print(void);
	void DFS(void);
	void BFS(void);
	void Prim(void);
	void Dijkstra(void);
};

void Graph::NewEdge(int start, int end, int length) {
	node *p = new node;
	p->end = end;
	p->length = length;
	p->next = v[start]->next;
	v[start]->next = p;
	p = new node;
	p->end = start;
	p->length = length;
	p->next = v[end]->next;
	v[end]->next = p;
}

int Graph::D(int start, int end) {
	node* p = v[start]->next;
	while (p) {
		if (p->end == end) return p->length;
		p = p->next;
	}
	return INFTY;
}

void Graph::Init(const char* s) {
	ifstream file;
	file.open(s, ios::in);
	file >> vexnum;
	v = new node*[vexnum];
	for (int i = 0; i < vexnum; i++) {
		v[i] = new node;
		v[i]->end = i;
		v[i]->next = NULL;
    }
    int a, b, c;
	while (!file.eof()) {
		file >> a;
		file >> b;
		file >> c;
		NewEdge(a, b, c);
	}
}

void Graph::Destroy(void) {
	node *p, *pre;
	for (int i = 0; i < vexnum; i++) {
		pre = v[i];
		while (pre) {
			p = pre->next;
			delete pre;
			pre = p;
		}
	}
	delete[] v;
}

void Graph::Print(void) {
	node *p;
	for (int i = 0; i < vexnum; i++) {
		p = v[i]->next;
		while (p) {
			cout << '(' << i << ',' << p->end << ')';
			cout << " = " << p->length << ' ';
			p = p->next;
		}
		cout << endl;
	}
	cout << endl;
}

void Graph::DFS(void) {
	bool visit[vexnum] = {0};
	node *p;
	stack *s;
	InitStack(s);
	Push(s, v[0]);
	while (!IsEmpty(s)) {
		Pop(s, p);
		if (!visit[p->end]) {
			visit[p->end] = 1;
			cout << p->end << ' ';
			p = p->next;
			while (p) {
				Push(s, v[p->end]);
				p = p->next;
			}	
		}
	}
	DestroyStack(s);
	cout << endl << endl;
}

void Graph::BFS(void){
	bool visit[vexnum] = {0};
	node *p;
	queue *q;
	InitQueue(q);
	visit[0] = 1;
	cout << 0 << ' ';
	EnQueue(q, v[0]);
	while (!IsEmpty(q)) {
		DeQueue(q, p);
		p = p->next;
		while (p) {
			if (!visit[p->end]) {
				visit[p->end] = 1;
				cout << p->end << ' ';
				EnQueue(q, v[p->end]);
			}
			p = p->next;
		}
	}
	DestroyQueue(q);
	cout << endl << endl;
}

void Graph::InitCandidateSet(int T[][3]){
	for (int i = 1; i < vexnum; i++) {
		T[i-1][0] = 0;
		T[i-1][1] = i;
		T[i-1][2] = D(0, i);
	}
}

int Graph::SelectLightEdge(int T[][3], int k) {
    int minpos, min = INFTY;
    for (int i = k; i < vexnum-1; i++) if (T[i][2] < min) {
        min = T[i][2];
    	minpos = i;
	}
    return minpos;
}

void Graph::ModifyCandidateSet(int T[][3], int k, int v) {
	int d;
	for (int i = k; i < vexnum-1; i++){
		d = D(v, T[i][1]);
		if (d < T[i][2]) {
			T[i][0] = v;
			T[i][2] = d;
		}
	}	
}

void Graph::PrintTree(int T[][3]) {
	for (int k = 0; k < vexnum-1; k++) {
		cout << '(' << T[k][0] << ',' << T[k][1] << ')';
		cout << " = " << T[k][2] << endl;
	}
	cout << endl;
}

void Graph::Prim(void) {
	int T[vexnum-1][3], k, m, r, temp;
	InitCandidateSet(T);
	for (k = 0; k < vexnum-1; k++) {
		m = SelectLightEdge(T, k);
		for (r = 0; r < 3; r++) {
			temp = T[k][r];
			T[k][r] = T[m][r];
			T[m][r] = temp;
		}
		r = T[k][1];
		ModifyCandidateSet(T, k, r);
	}
	PrintTree(T);
}

void Graph::InitPath(bool S[], int Parent[], int Distance[]) {
	S[0] = 1;
	Distance[0] = 0;
	Parent[0] = -1;	 
	for (int i = 1; i < vexnum; i++ ) {
		S[i] = 0;
		Distance[i] = D(0, i);
		if (Distance[i] == INFTY) Parent[i] = -1;
		else Parent[i] = 0;
	}
}

void Graph::FindPath(bool S[], int Parent[], int Distance[]) {
	int min = INFTY, j, k, d;
	for(j = 0; j < vexnum; j++)
		if (!S[j] && Distance[j] < min) {
			min = Distance[j];
			k = j;
	}
	S[k] = 1;
	for (j = 0; j < vexnum; j++) {
		d = D(k, j);
		if (!S[j] && Distance[j] > Distance[k] + d) {
			Distance[j] = Distance[k] + d;
			Parent[j] = k;
		}
	}	
}

void Graph::PrintPath(int Parent[], int Distance[]) {
	int j;
	for (int i = 0; i < vexnum; i++) {
		j = i;
		while (j) {
			cout << j << " <- ";
			j = Parent[j];
		}
		cout << "0 Distance:" << Distance[i] << endl;
	}
}

void Graph::Dijkstra(void) {
	bool S[vexnum];
	int Parent[vexnum];
	int Distance[vexnum];
	InitPath(S, Parent, Distance);
	for (int i = 0; i < vexnum-1; i++) FindPath(S, Parent, Distance);
	PrintPath(Parent, Distance);
	cout << endl;
}

void PrintMenu(void) {
	cout << "0 Exit" << endl;
	cout << "1 Print" << endl;
	cout << "2 DFS" << endl;
	cout << "3 BFS" << endl;
	cout << "4 Prim" << endl;
	cout << "5 Dijkstra" << endl;
}

int main(void) {
	Graph g;
	g.Init("sample.txt");
	char c;
	while (1) {
		PrintMenu();
		cin >> c;
		cin.get();
		switch (c) {
			case '0':
				g.Destroy();
				return 0;
			
			case '1':
				g.Print();
				break;
				
			case '2':
				g.DFS();
				break;
				
			case '3':
				g.BFS();
				break;
				
			case '4':
				g.Prim();
				break;
				
			case '5':
				g.Dijkstra();
				break;
				
			default:
				cout << "ERROR" << endl;
		}
	}
}
