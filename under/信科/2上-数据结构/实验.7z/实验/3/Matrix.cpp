#include <iostream>
#include <fstream>
using namespace std;

class Graph{
	private:
	int vexnum;
	int **edge;
	
	public:
	void Init(void);
	void Destroy(void);
	void Print(void);
};

void Graph::Init(void) {
	ifstream file;
	file.open("sample.txt", ios::in);
	file >> vexnum;
	edge = new int*[vexnum];
	for (int i = 0; i < vexnum; i++) {
		edge[i] = new int[vexnum];
		for (int j = 0; j < vexnum; j++)
			edge[i][j] = INT_MAX;
	}
	int a, b, c;
	while (!file.eof()) {
		file >> a;
		file >> b;
		file >> c;
		edge[a][b] = edge[b][a] = c;
	}
}

void Graph::Destroy(void) {
	for (int i = 0; i < vexnum; i++)
		delete[] edge[i];
	delete[] edge;
}

void Graph::Print(void) {
	for (int i = 0; i < vexnum; i++) {
		for (int j = 0; j < vexnum; j++){
			if (edge[i][j] == INT_MAX) cout << '#';
			else cout << edge[i][j];
			cout << ' ';
		}
		cout << endl;
	}
}

int main(void) {
	Graph g;
	g.Init();
	g.Print();
	g.Destroy();
}
