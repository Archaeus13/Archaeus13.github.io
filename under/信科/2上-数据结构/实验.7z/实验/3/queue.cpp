#include <iostream>
using namespace::std;

struct queue{
	ElemType n;
	queue* next;
};

int InitQueue(queue* &p) {
	p = new queue;
	p->next = NULL;
	return 0;
}

int DestroyQueue(queue* &p) {
	if (!p)	return -1;
	queue* q;
	while (p) {
		q = p;
		p = p->next;
		delete q;
	}
	return 0;
}

int EnQueue(queue* &p, ElemType a) {
	if (!p) return -1;
	queue* s = new queue;
	p->n = a;
	s->next = p;
	p = s;
	return 0;
}

int DeQueue(queue* &p, ElemType &a) {
	if (!p) return -1;
	if (!p->next) return 1;
	queue* s = p, *t;
	while (s->next->next) s = s->next;
	t = s->next;
	s->next = NULL;
	a = t->n;
	delete t;
	return 0;
}

int IsEmpty(queue* p) {
	if (!p) return -1;
	if (!p->next) return 1;
	return 0;
}
