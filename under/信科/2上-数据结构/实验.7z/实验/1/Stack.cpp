#include <iostream>
using namespace std;

struct node{
	ElemType n;
	struct node* next;
};

int InitStack(node* &p) {
	if (p) return -1;
	p = new node;
	p->next = NULL;
	return 0;
}

int DestroyStack(node* &p) {
	if (!p)	return -1;
	node* q;
	while (p) {
		q = p;
		p = p->next;
		delete q;
	}
	p = NULL; 
	return 0;
}

int Push(node* &p, ElemType a) {
	if (!p) return -1;
	node* s = new node;
	p->n = a;
	s->next = p;
	p = s;
	return 0;
}

int Pop(node* &p, ElemType &a) {
	if (!p) return -1;
	if (!p->next) return 1;
	node* s = p;
	p = p->next;
	a = p->n;
	delete s;
	return 0;
}

int GetTop(node* p, ElemType &a) {
	if (!p) return -1;
	if (!p->next) return 1;
	a = p->next->n;
	return 0;
}

int TraverseStack(node* p) {
	if (!p) return -1;
	if (!p->next) return 1;
	while (p->next) {
		p = p->next;
		cout << p->n << ' ';
	}
	cout << endl;
	return 0;
}
