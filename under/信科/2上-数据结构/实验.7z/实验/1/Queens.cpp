#define ElemType int
#include "stack.cpp"

int N; 

int chaos(node* p, int x) {
	int i = 0;
	while (p->next) {
		i++;
		p = p->next;
		if (x == p->n) return 1;
		if (p->n - x == i) return 1;
		if (x - p->n == i) return 1;
	}
	return 0;
}

void Display(node* p) {
	int i;
	while (p->next) {
		cout << '|';
		p = p->next;
		for (i = 0; i < p->n; i++) cout << "+ ";
		cout << "Q ";
		for (i++ ; i < N; i++) cout << "+ ";
		cout << '|' << endl;
	}
	for (int i = 0; i < 2*N + 2; i++) cout << '-';
	cout << endl;
}

int main(int argc, char* argv[]) {
	node* p = NULL;
	cout << "����N��";
	cin >> N;
	freopen(argv[1], "w", stdout);
	int i = 0, a, b;
	long n = 0;
	InitStack(p);
	for (int i = 0; i < 2*N + 2; i++) cout << '-';
	cout << endl;
	while (1) {
		a = 0;
		while (chaos(p, a)) a++;
		Push(p, a);
		i++;
		GetTop(p, b);
		    if (b < N && i == N) {
		    	Display(p);
                n++; 
		    	Pop(p, a);
				a++;
				while (chaos(p, a)) a++;
				Push(p, a);
			}
		    while (b >= N) {
				Pop(p, b);
				if (Pop(p, b)) {
					cout << "total:" << n << endl;
	                DestroyStack(p);
	                return 0;
				}
				b++;
				while (chaos(p, b)) b++;
				Push(p, b);
				i--;
				GetTop(p, b);
			}
	}
	fclose(stdout);
}
