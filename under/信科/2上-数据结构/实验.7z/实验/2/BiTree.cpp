#include <iostream>
using namespace std;

struct Tree{
	char data;
	Tree *lchild, *rchild;
};

void InitTree(Tree* &t) {
	char a;
	cin >> a;
	if (a != '#') {
		t = new Tree;
		t->data = a;
		InitTree(t->lchild);
		InitTree(t->rchild);
	}
	else t = NULL;
}

void PreOrder(Tree* t) {
	if (!t) return;
	cout << t->data;
	PreOrder(t->lchild);
	PreOrder(t->rchild);
}

void InOrder(Tree* t) {
	if (!t) return;
	InOrder(t->lchild);
	cout << t->data;
	InOrder(t->rchild);
}

void PostOrder(Tree* t) {
	if (!t) return;
	PostOrder(t->lchild);
	PostOrder(t->rchild);
	cout << t->data;
}

int main(void) {
	cout << "����������չ���У�";
	Tree* t;
	InitTree(t);
	cout << "�������У�";
	PreOrder(t);
	cout << endl;
	cout << "�������У�";
	InOrder(t);
	cout << endl;
	cout << "�������У�";
	PostOrder(t);
	cout << endl;
}

