#include <iostream>
using namespace std;

struct Tree{
	char data;
	bool IfNum;
	Tree *lchild, *rchild;
};

void InitTree(Tree* &t) {
	char a;
	cin >> a;
	t = new Tree;
	t->data = a;
	if (a < '0') {
		t->IfNum = 0;
		InitTree(t->lchild);
		InitTree(t->rchild);
	}
	else t->IfNum = 1;
}

void PreOrder(Tree* t) {
	if (t->IfNum) {
		cout << t->data;
		return;
	}
	cout << t->data;
	PreOrder(t->lchild);
	PreOrder(t->rchild);
}

void InOrder(Tree* t) {
	if (t->IfNum) {
		cout << t->data;
		return;
	}
	InOrder(t->lchild);
	cout << t->data;
	InOrder(t->rchild);
}

void PostOrder(Tree* t) {
	if (t->IfNum) {
		cout << t->data;
		return;
	}
	PostOrder(t->lchild);
	PostOrder(t->rchild);
	cout << t->data;
}

float Count(float a, char op, float b) {
	if (op == '+') return a + b;
	else if (op == '-') return a - b;
	else if (op == '*') return a * b;
	else if (op == '/') return a / b;
}

float Cal(Tree* t) {
	if (t->IfNum) return t->data - 48;
	return Count(Cal(t->lchild), t->data, Cal(t->rchild));
}

int main(void) {
	cout << "���벨��ʽ��";
	Tree* t;
	InitTree(t);
	cout << "����ʽ��";
	PreOrder(t);
	cout << endl;
	cout << "��׺ʽ��";
	InOrder(t);
	cout << endl;
	cout << "�沨��ʽ��";
	PostOrder(t);
	cout << endl;	
	cout << "��������" << Cal(t) << endl;
}

