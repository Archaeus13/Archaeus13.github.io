#include <iostream>
using namespace std;

struct Tree{
	char data;
	bool ltag, rtag; 
	Tree *lchild, *rchild;
};

void InitTree(Tree* &t) {
	char a;
	cin >> a;
	if (a != '#') {
		t = new Tree;
		t->data = a;
		t->ltag = t->rtag = 0;
		InitTree(t->lchild);
		InitTree(t->rchild);
	}
	else t = NULL;
}

void ThrTree(Tree* &t, Tree* &pre) {
	if (!t) return;
	ThrTree(t->lchild, pre);
	ThrTree(t->rchild, pre);
	if (!t->lchild) {
		t->ltag = 1;
		t->lchild = pre;
	}
	if (pre && !pre->rchild) {
		pre->rtag = 1;
		pre->rchild = t;
	}
	pre = t;
}

void RePostOrder(Tree* t) {
	while (t) {
		cout << t->data;
		if (!t->rtag) t = t->rchild;
		else t = t->lchild;
	}
}

int main(void) {
	cout << "����������չ���У�";
	Tree* t;
	Tree* pre = NULL;
	InitTree(t);
	ThrTree(t, pre);
	if (!t->rchild) t->rtag = 1;
	cout << "����������������"; 
	RePostOrder(t);
	cout << endl;
}

