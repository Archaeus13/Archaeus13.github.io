#include <string.h>
#include <time.h>
#include <assert.h>
#include <errno.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <sys/timeb.h>

#include "fat16.h"

const char *FAT_FILE_NAME = "fat16.img";
const char *FAT_FILE_COPY1_NAME = "c1.img";
const char *FAT_FILE_COPY2_NAME = "c2.img";
const char *LOG_PATH = "/fat16.log";
FILE *fd_copy1;
FILE *fd_copy2;
int occupied = 0, ifwrite = 1, log_exist = 0;

/**
 * @brief 将buffer中的数据写入到扇区号为secnum的扇区中
 * 
 * @param fd      镜像文件指针
 * @param secnum  需要写入的扇区号
 * @param buffer  需要写入的数据
 */
void sector_write(FILE *fd, unsigned int secnum, const void *buffer)
{
  fseek(fd, BYTES_PER_SECTOR * secnum, SEEK_SET);
  fwrite(buffer, BYTES_PER_SECTOR, 1, fd);
  fflush(fd);
  fseek(fd_copy1, BYTES_PER_SECTOR * secnum, SEEK_SET);
  fwrite(buffer, BYTES_PER_SECTOR, 1, fd_copy1);
  fflush(fd_copy1);
  fseek(fd_copy2, BYTES_PER_SECTOR * secnum, SEEK_SET);
  fwrite(buffer, BYTES_PER_SECTOR, 1, fd_copy2);
  fflush(fd_copy2);
}

/**
 * @brief 读取扇区号为secnum的扇区，将数据存储到buffer中
 * 
 * @param fd      镜像文件指针
 * @param secnum  需要读取的扇区号
 * @param buffer  数据要存储到的缓冲区指针
 */
void sector_read(FILE *fd, unsigned int secnum, void *buffer)
{
  BYTE buffer0[BYTES_PER_SECTOR];
  BYTE buffer_copy1[BYTES_PER_SECTOR];
  BYTE buffer_copy2[BYTES_PER_SECTOR];
  fseek(fd, BYTES_PER_SECTOR * secnum, SEEK_SET);
  fread(buffer0, BYTES_PER_SECTOR, 1, fd);
  fseek(fd_copy1, BYTES_PER_SECTOR * secnum, SEEK_SET);
  fread(buffer_copy1, BYTES_PER_SECTOR, 1, fd_copy1);
  fseek(fd_copy2, BYTES_PER_SECTOR * secnum, SEEK_SET);
  fread(buffer_copy2, BYTES_PER_SECTOR, 1, fd_copy2);
  uint8_t findflag[4] = {0, 0, 0, 0};
  for (uint i = 0; i < BYTES_PER_SECTOR; i++) {
    if (buffer0[i] == buffer_copy1[i]) {
      if (buffer_copy2[i] != buffer0[i]) findflag[0] = 1;
    }
    else if (buffer0[i] == buffer_copy2[i]) {
      if (buffer_copy1[i] != buffer0[i]) findflag[1] = 1;
    }
    else if (buffer_copy1[i] == buffer_copy2[i]) {
      findflag[2] = 1;
      buffer0[i] = buffer_copy1[i];
    }
    else findflag[3] = 1;
  }
  if (findflag[0]) printf("copy2ERR\n");
  if (findflag[1]) printf("copy1ERR\n");
  if (findflag[2]) printf("imgERR\n");
  if (findflag[3]) printf("At least two copies are error, cannot solve -_-\n");
  memcpy(buffer, buffer0, BYTES_PER_SECTOR);
  sector_write(fd, secnum, buffer);
}

/**
 * @brief 从fuse中获取存储了文件系统元数据的FAT16指针

 * @return FAT16* 文件系统元数据指针 
 */
FAT16* get_fat16_ins() {
  struct fuse_context *context;
  context = fuse_get_context();
  return (FAT16 *)context->private_data;
}

/**
 * @brief 计算编号为cluster的簇在硬盘中的偏移量
 * 
 * @param fat16_ins FAT16元数据指针
 * @param cluster   簇号
 * @return long     簇在硬盘（镜像文件）中的偏移量
 */
long get_cluster_offset(FAT16 *fat16_ins, uint16_t cluster)
{
  if (cluster >= CLUSTER_MIN &&
      cluster <= CLUSTER_MAX &&
      cluster < (fat16_ins->FatSize / sizeof(uint16_t)))
  {
    return fat16_ins->DataOffset + fat16_ins->ClusterSize * (cluster - 2);
  }
  return -1;
}

/**
 * @brief 将输入路径按“/”分割成多个字符串，并按照FAT文件名格式转换字符串。
 * 
 * 例如：当pathInputConst为"/dir1/dir2/file.txt"时，函数将其分割为"dir1", "dir2", "file.txt"
 * 三层，三层文件名分别转换为"DIR1       ", "DIR2       "和"FILE    TXT"。
 * 所以函数将设置pathDepth_ret为3，并返回长度为3的字符串数组，返回如上如上所述的三个长度为11的字符串。
 * 当某层的文件名或拓展名过长时，会自动截断文件名和拓展名，
 * 如"/verylongname.extension"会被转换为"VERYLONGEXT"。
 * 若某层文件名为"."或者".."则会特殊处理，分别转换为".           "和"..        "，
 * 分别代表当前目录和父目录。
 * 
 * @param pathInputConst  输入的文件路径名, 如/home/user/m.c
 * @param pathDepth_ret   输出参数，将会被设置为输入路径的层数，如上面的例子中为3
 * @return char**         转换后的FAT格式的文件名，字符串数组，包含pathDepth_ret个字符串，
 *                        每个字符串长度都为11，依次为转换后每层的文件名
 */
char **path_split(const char *pathInputConst, int *pathDepth_ret)
{
  int i, j;
  int pathDepth = 0;

  char *pathInput = strdup(pathInputConst);

  for (i = 0; pathInput[i] != '\0'; i++)
  {
    if (pathInput[i] == '/')
    {
      pathDepth++;
    }
  }

  char **paths = malloc(pathDepth * sizeof(char *));

  const char token[] = "/";
  char *slice;

  /* Dividing the path into separated strings of file names */
  slice = strtok(pathInput, token);
  for (i = 0; i < pathDepth; i++)
  {
    paths[i] = slice;
    slice = strtok(NULL, token);
  }

  char **pathFormatted = malloc(pathDepth * sizeof(char *));

  for (i = 0; i < pathDepth; i++)
  {
    pathFormatted[i] = malloc(MAX_SHORT_NAME_LEN * sizeof(char));
  }

  int k;

  /* Verifies if each file of the path is a valid input, and then formats it */
  for (i = 0; i < pathDepth; i++)
  {
    for (j = 0, k = 0; k < 11; j++)
    {
      if (paths[i][j] == '.')
      {
        /* Verifies if it is a "." or ".." */
        if (j == 0 && (paths[i][j + 1] == '\0' || (paths[i][j + 1] == '.' && paths[i][j + 2] == '\0')))
        {
          pathFormatted[i][0] = '.';

          if (paths[i][j + 1] == '\0')
            pathFormatted[i][1] = ' ';
          else
            pathFormatted[i][1] = '.';

          for (k = 2; k < 11; k++)
          {
            pathFormatted[i][k] = ' ';
          }
          break;
        }
        else
        {
          for (; k < 8; k++)
          {
            pathFormatted[i][k] = ' ';
          }
        }
      }
      else if (paths[i][j] == '\0')
      { /* End of the file name, fills with ' ' character the rest of the file
         * name and the file extension fields */
        for (; k < 11; k++)
        {
          pathFormatted[i][k] = ' ';
        }
        break;
      }
      else if (paths[i][j] >= 'a' && paths[i][j] <= 'z')
      { /* Turns lower case characters into upper case characters */
        pathFormatted[i][k++] = paths[i][j] - 'a' + 'A';
      }
      else
      {
        pathFormatted[i][k++] = paths[i][j];
      }
    }
    pathFormatted[i][11] = '\0';
  }

  *pathDepth_ret = pathDepth;
  free(paths);
  free(pathInput);
  return pathFormatted;
}

/**
 * @brief 将FAT格式的文件名转换为文件名字符串，如"FILE    TXT"会被转换为"file.txt"
 * 
 * @param path    FAT格式的文件名，长度为11的字符串
 * @return BYTE*  普通格式的文件名字符串
 */
BYTE *path_decode(BYTE *path)
{

  int i, j;
  BYTE *pathDecoded = malloc(MAX_SHORT_NAME_LEN * sizeof(BYTE));

  /* If the name consists of "." or "..", return them as the decoded path */
  if (path[0] == '.' && path[1] == '.' && path[2] == ' ')
  {
    pathDecoded[0] = '.';
    pathDecoded[1] = '.';
    pathDecoded[2] = '\0';
    return pathDecoded;
  }
  if (path[0] == '.' && path[1] == ' ')
  {
    pathDecoded[0] = '.';
    pathDecoded[1] = '\0';
    return pathDecoded;
  }

  /* Decoding from uppercase letters to lowercase letters, removing spaces,
   * inserting 'dots' in between them and verifying if they are legal */
  for (i = 0, j = 0; i < 11; i++)
  {
    if (path[i] != ' ')
    {
      if (i == 8)
        pathDecoded[j++] = '.';

      if (path[i] >= 'A' && path[i] <= 'Z')
        pathDecoded[j++] = path[i] - 'A' + 'a';
      else
        pathDecoded[j++] = path[i];
    }
  }
  pathDecoded[j] = '\0';
  return pathDecoded;
}

/**
 * @brief 获得父目录的路径。如输入path = "dir1/dir2/texts"，得到"dir1/dir2"
 * 
 * @param path        路径
 * @param orgPaths    由`org_path_split`分割后的路径，如{ "dir1", "dir2", "tests" }
 * @param pathDepth   由`org_path_split`返回的路径层数，如3
 * @return char*      父目录的路径
 */
char *get_prt_path(const char *path, const char **orgPaths, int pathDepth)
{
  char *prtPath;
  if (pathDepth == 1)
  {
    prtPath = (char *)malloc(2 * sizeof(char));
    prtPath[0] = '/';
    prtPath[1] = '\0';
  }
  else
  {
    int prtPathLen = strlen(path) - strlen(orgPaths[pathDepth - 1]) - 1;
    prtPath = (char *)malloc((prtPathLen + 1) * sizeof(char));
    strncpy(prtPath, path, prtPathLen);
    prtPath[prtPathLen] = '\0';
  }
  return prtPath;
}

/**
 * @brief 从镜像文件中读取BPB，并计算所需的各类元数据
 * 
 * @param imageFilePath 镜像文件路径
 * @return FAT16*       存储元数据的FAT16结构指针
 */
FAT16 *pre_init_fat16(const char *imageFilePath)
{
  /* Opening the FAT16 image file */
  FILE *fd = fopen(imageFilePath, "rb+");

  if (fd == NULL)
  {
    fprintf(stderr, "Missing FAT16 image file!\n");
    exit(EXIT_FAILURE);
  }

  FAT16 *fat16_ins = malloc(sizeof(FAT16));

  fat16_ins->fd = fd;

  /* Reads the BPB */
  sector_read(fat16_ins->fd, 0, &fat16_ins->Bpb);

  /* First sector of the root directory */
  fat16_ins->FirstRootDirSecNum = fat16_ins->Bpb.BPB_RsvdSecCnt + (fat16_ins->Bpb.BPB_FATSz16 * fat16_ins->Bpb.BPB_NumFATS);

  /* Number of sectors in the root directory */
  DWORD RootDirSectors = ((fat16_ins->Bpb.BPB_RootEntCnt * 32) +
                          (fat16_ins->Bpb.BPB_BytsPerSec - 1)) /
                         fat16_ins->Bpb.BPB_BytsPerSec;

  /* First sector of the data region (cluster #2) */
  fat16_ins->FirstDataSector = fat16_ins->Bpb.BPB_RsvdSecCnt + (fat16_ins->Bpb.BPB_NumFATS * fat16_ins->Bpb.BPB_FATSz16) + RootDirSectors;

  fat16_ins->FatOffset =  fat16_ins->Bpb.BPB_RsvdSecCnt * fat16_ins->Bpb.BPB_BytsPerSec;
  fat16_ins->FatSize = fat16_ins->Bpb.BPB_BytsPerSec * fat16_ins->Bpb.BPB_FATSz16;
  fat16_ins->RootOffset = fat16_ins->FatOffset + fat16_ins->FatSize * fat16_ins->Bpb.BPB_NumFATS;
  fat16_ins->ClusterSize = fat16_ins->Bpb.BPB_BytsPerSec * fat16_ins->Bpb.BPB_SecPerClus;
  fat16_ins->DataOffset = fat16_ins->RootOffset + fat16_ins->Bpb.BPB_RootEntCnt * BYTES_PER_DIR;

  return fat16_ins;
}

/**
 * @brief 返回簇号为ClusterN对应的FAT表项
 * 
 * @param fat16_ins 文件系统元数据指针
 * @param ClusterN  簇号（注意合法的簇号从2开始）
 * @return WORD     FAT表项（每个表项2字节，故用WORD存储）
 */
WORD fat_entry_by_cluster(FAT16 *fat16_ins, WORD ClusterN)
{
  /* Buffer to store bytes from the image file and the FAT16 offset */
  BYTE sector_buffer[BYTES_PER_SECTOR];
  WORD FATOffset = ClusterN * 2;
  /* FatSecNum is the sector number of the FAT sector that contains the entry
   * for cluster N in the first FAT */
  WORD FatSecNum = fat16_ins->Bpb.BPB_RsvdSecCnt + (FATOffset / fat16_ins->Bpb.BPB_BytsPerSec);
  WORD FatEntOffset = FATOffset % fat16_ins->Bpb.BPB_BytsPerSec;

  /* Reads the sector and extract the FAT entry contained on it */
  sector_read(fat16_ins->fd, FatSecNum, &sector_buffer);
  return *((WORD *)&sector_buffer[FatEntOffset]);
  // return 0xffff;  //可以修改
}

/**
 * @brief 读取指定簇号的簇的第一个扇区，并给出相应的FAT表项和扇区号
 * 
 * @param fat16_ins               文件系统元数据指针
 * @param ClusterN                簇号
 * @param FatClusEntryVal         输出参数，对应簇的FAT表项
 * @param FirstSectorofCluster    输出参数，对应簇的第一个扇区的扇区号
 * @param buffer                  输出参数，对应簇第一个扇区的内容
 */
void first_sector_by_cluster(FAT16 *fat16_ins, WORD ClusterN, WORD *FatClusEntryVal, WORD *FirstSectorofCluster, BYTE *buffer)
{
  *FatClusEntryVal = fat_entry_by_cluster(fat16_ins, ClusterN);
  *FirstSectorofCluster = ((ClusterN - 2) * fat16_ins->Bpb.BPB_SecPerClus) + fat16_ins->FirstDataSector;

  sector_read(fat16_ins->fd, *FirstSectorofCluster, buffer);
}

/**
 * @brief 从根目录开始寻找path所对应的文件或目录，并设置相应目录项，以及目录项所在的偏移量
 * 
 * @param fat16_ins   文件系统元数据指针
 * @param Root        输出参数，对应的目录项
 * @param path        要查找的路径
 * @param offset_dir  输出参数，对应目录项在镜像文件中的偏移量（字节）
 * @return int        是否找到路径对应的文件或目录（0:找到， 1:未找到）
 */
int find_root(FAT16 *fat16_ins, DIR_ENTRY *Root, const char *path, off_t *offset_dir)
{
  int RootDirCnt = 1;
  BYTE buffer[BYTES_PER_SECTOR];

  int pathDepth;
  char *path_dup = strdup(path);
  char **paths = path_split((char *)path_dup, &pathDepth);

  sector_read(fat16_ins->fd, fat16_ins->FirstRootDirSecNum, buffer);

  /* We search for the path in the root directory first */
  for (uint i = 1; i <= fat16_ins->Bpb.BPB_RootEntCnt; i++)
  {
    memcpy(Root, &buffer[((i - 1) * BYTES_PER_DIR) % BYTES_PER_SECTOR], BYTES_PER_DIR);

    /* If the directory entry is free, all the next directory entries are also
     * free. So this file/directory could not be found */
    if (Root->DIR_Name[0] == 0x00)
    {
      return 1;
    }

    /* Check whether dir entry has been delete */
    int is_del = (Root->DIR_Name[0] == 0xe5);
    /* Comparing strings character by character */
    int is_eq = strncmp((const char *)Root->DIR_Name, paths[0], 11) == 0 ? 1 : 0;
    int is_valid = (!is_del) && is_eq;

    /* If the path is only one file (ATTR_ARCHIVE) and it is located in the
     * root directory, stop searching */
    if (is_valid && Root->DIR_Attr == ATTR_ARCHIVE)
    {
      *offset_dir = fat16_ins->RootOffset + (i - 1) * BYTES_PER_DIR;
      return 0;
    }

    /* If the path is only one directory (ATTR_DIRECTORY) and it is located in
     * the root directory, stop searching */
    if (is_valid && Root->DIR_Attr == ATTR_DIRECTORY && pathDepth == 1)
    {
      *offset_dir = fat16_ins->RootOffset + (i - 1) * BYTES_PER_DIR;
      return 0;
    }

    /* If the first level of the path is a directory, continue searching
     * in the root's sub-directories */
    if (is_valid && Root->DIR_Attr == ATTR_DIRECTORY)
    {
      return find_subdir(fat16_ins, Root, paths, pathDepth, 1, offset_dir);
    }

    /* End of bytes for this sector (1 sector == 512 bytes == 16 DIR entries)
     * Read next sector */
    if (i % 16 == 0 && i != fat16_ins->Bpb.BPB_RootEntCnt)
    {
      sector_read(fat16_ins->fd, fat16_ins->FirstRootDirSecNum + RootDirCnt, buffer);
      RootDirCnt++;
    }
  }

  /* We did not find anything */
  return 1;
}

/**
 * 从子目录开始查找path对应的文件或目录，找到返回0，没找到返回1，并将Dir填充为查找到的对应目录项
 *
 * Hint1: 在find_subdir入口处，Dir应该是要查找的这一级目录的表项，需要根据其中的簇号，读取这级目录对应的扇区数据
 * Hint2: 目录的大小是未知的，可能跨越多个扇区或跨越多个簇；当查找到某表项以0x00开头就可以停止查找
 * Hint3: 需要查找名字为paths[curDepth]的文件或目录，同样需要根据pathDepth判断是否继续调用find_subdir函数
 **/

/**
 * @brief 从子目录Dir开始递归寻找paths对应的文件
 * 
 * @param fat16_ins   文件系统元数据指针
 * @param Dir         输入当前要查找的子目录目录项，输出查找到的文件目录项
 * @param paths       要查找的路径，应该传入`path_split`返回的结果
 * @param pathDepth   路径的总层数，`path_split`输出的结果
 * @param curDepth    当前在查找的路径层数
 * @param offset_dir  输出参数，输出查找到的文件目录项在镜像文件中的偏移（字节）
 * @return int        是否找到路径对应的文件或目录（0:找到， 1:未找到）
 */
int find_subdir(FAT16 *fat16_ins, DIR_ENTRY *Dir, char **paths, int pathDepth, int curDepth, off_t *offset_dir)
{
  int DirSecCnt = 1, is_eq;
  BYTE buffer[BYTES_PER_SECTOR];

  WORD ClusterN, FatClusEntryVal, FirstSectorofCluster;

  ClusterN = Dir->DIR_FstClusLO;

  first_sector_by_cluster(fat16_ins, ClusterN, &FatClusEntryVal, &FirstSectorofCluster, buffer);

  /* Searching for the given path in all directory entries of Dir */
  for (uint i = 1; Dir->DIR_Name[0] != 0x00; i++)
  {
    memcpy(Dir, &buffer[((i - 1) * BYTES_PER_DIR) % BYTES_PER_SECTOR], BYTES_PER_DIR);

    /* Check whether dir entry has been delete */
    int is_del = (Dir->DIR_Name[0] == 0xe5);
    /* Comparing strings */
    is_eq = strncmp((const char *)Dir->DIR_Name, paths[curDepth], 11) == 0 ? 1 : 0;
    int is_valid = (!is_del) && is_eq;

    /* Stop searching if the last file of the path is located in this
     * directory */
    if ((is_valid && Dir->DIR_Attr == ATTR_ARCHIVE && curDepth + 1 == pathDepth) ||
        (is_valid && Dir->DIR_Attr == ATTR_DIRECTORY && curDepth + 1 == pathDepth))
    {
      *offset_dir = get_cluster_offset(fat16_ins, ClusterN) + (DirSecCnt - 1) * BYTES_PER_SECTOR + (i - 1) * BYTES_PER_DIR;
      return 0;
    }

    /* Recursively keep searching if the directory has been found and it isn't
     * the last file */
    if (is_valid && Dir->DIR_Attr == ATTR_DIRECTORY)
    {
      return find_subdir(fat16_ins, Dir, paths, pathDepth, curDepth + 1, offset_dir);
    }

    /* A sector needs to be readed 16 times by the buffer to reach the end. */
    if (i % 16 == 0)
    {
      /* If there are still sector to be read in the cluster, read the next sector. */
      if (DirSecCnt < fat16_ins->Bpb.BPB_SecPerClus)
      {
        sector_read(fat16_ins->fd, FirstSectorofCluster + DirSecCnt, buffer);
        DirSecCnt++;
      }
      else
      { /* Reaches the end of the cluster */

        /* Not strictly necessary, but here we reach the end of the clusters of
         * this directory entry. */
        if (FatClusEntryVal == 0xffff)
        {
          return 1;
        }

        /* Next cluster */
        ClusterN = FatClusEntryVal;

        first_sector_by_cluster(fat16_ins, ClusterN, &FatClusEntryVal, &FirstSectorofCluster, buffer);

        i = 0;
        DirSecCnt = 1;
      }
    }
  }

  /* We did not find the given path */
  return 1;
}

/**
 * @brief 分割字符串但不转换格式，如"/dir1/dir2/text"会转化为{"dir1","dir2","text"}。注意pathInput会被修改。
 * 
 * @param pathInput 输入的字符串
 * @return char**   分割后的字符串
 */
char **org_path_split(char *pathInput)
{
  int pathDepth = 0;
  for (uint i = 0; pathInput[i] != '\0'; i++)
  {
    if (pathInput[i] == '/')
    {
      pathDepth++;
    }
  }
  char **orgPaths = (char **)malloc(pathDepth * sizeof(char *));
  const char token[] = "/";
  char *slice;

  /* Dividing the path into separated strings of file names */
  slice = strtok(pathInput, token);
  for (uint i = 0; i < pathDepth; i++)
  {
    orgPaths[i] = slice;
    slice = strtok(NULL, token);
  }
  return orgPaths;
}

// ===========================文件系统接口实现===============================

// ------------------TASK2: 创建/删除文件-----------------------------------

/* (This is a new function) Add an entry according to specified sector and offset
 * ==================================================================================
 * exp: sectorNum = 1000, offset = 1*BYTES_PER_DIR
 * The 1000th sector content before create: | Dir Entry(used)   |  Dir Entry(free)  | ... |
 * The 1000th sector content after create:  | Dir Entry(used)   | Added Entry(used) | ... |
 * ==================================================================================
 */
/**
 * @brief 创建目录项
 * 
 * @param fat16_ins       文件系统指针
 * @param sectorNum       目录项所在扇区号
 * @param offset          目录项在扇区中的偏移量
 * @param Name            文件名（FAT格式）
 * @param attr            文件属性
 * @param firstClusterNum 文件首簇簇号
 * @param fileSize        文件大小
 * @return int            成功返回0
 */
int dir_entry_create(FAT16 *fat16_ins, int sectorNum, int offset, char *Name, BYTE attr, WORD firstClusterNum, DWORD fileSize)
{
  /* Create memory buffer to store entry info */
  //先在buffer中写好表项的信息，最后通过一次IO写入到磁盘中
  BYTE *entry_info = malloc(BYTES_PER_DIR * sizeof(BYTE));

  /**
     * TODO:为新表项填入文件名和文件属性
     **/
  /*** BEGIN ***/
  memcpy(entry_info, Name, 11 * sizeof(BYTE));
  memcpy(entry_info + 11, &attr, sizeof(BYTE));
  /*** END ***/

  /**
     * 关于时间信息部分的工作我们本次实验不要求
     * 代码已经给出，可以参考实验文档自行理解
     **/
  time_t timer_s;
  time(&timer_s);
  struct tm *time_ptr = localtime(&timer_s);
  int value;

  /* Unused */
  memset(entry_info + 12, 0, 10 * sizeof(BYTE));

  /* File update time */
  /* 时间部分可以阅读实验文档 */
  value = time_ptr->tm_sec / 2 + (time_ptr->tm_min << 5) + (time_ptr->tm_hour << 11);
  memcpy(entry_info + 22, &value, 2 * sizeof(BYTE));

  /* File update date */
  value = time_ptr->tm_mday + (time_ptr->tm_mon << 5) + ((time_ptr->tm_year - 80) << 9);
  memcpy(entry_info + 24, &value, 2 * sizeof(BYTE));
  
  /**
     * TODO:为新表项填入文件首簇号与文件大小
     **/
  /* First Cluster Number & File Size */
  /*** BEGIN ***/
  memcpy(entry_info + 26, &firstClusterNum, sizeof(WORD));
  memcpy(entry_info + 28, &fileSize, sizeof(DWORD));
  /*** END ***/

  /**
     * TODO:将创建好的新表项信息写入到磁盘
     **/
  /* Write the above entry to specified location */
  /*** BEGIN ***/
  BYTE sector_buffer[BYTES_PER_SECTOR];
  sector_read(fat16_ins->fd, sectorNum, sector_buffer);
  memcpy(sector_buffer + offset, entry_info, BYTES_PER_DIR * sizeof(BYTE));
  sector_write(fat16_ins->fd, sectorNum, sector_buffer);
  /*** END ***/
  free(entry_info);
  return 0;
}

/**
 * @brief 释放簇号对应的簇，只需修改FAT对应表项，并返回下一个簇的簇号。
 * 
 * @param fat16_ins   文件系统指针
 * @param ClusterNum  要释放的簇号
 * @return int        下一个簇的簇号
 */
int free_cluster(FAT16 *fat16_ins, int ClusterNum)
{
  BYTE sector_buffer[BYTES_PER_SECTOR];
  WORD FATClusEntryval, FirstSectorofCluster;
  first_sector_by_cluster(fat16_ins, ClusterNum, &FATClusEntryval, &FirstSectorofCluster, sector_buffer);

  FILE *fd = fat16_ins->fd;
  /** TODO:
   * 修改FAT表
   * 注意两个表都要修改
   * FAT表1和表2的偏移地址怎么计算参考实验文档
   * 每个表项为2个字节
   **/
  /*** BEGIN ***/
  WORD FATOffset = ClusterNum * 2;
  /* FatSecNum is the sector number of the FAT sector that contains the entry
   * for cluster N in the first FAT */
  WORD FatSecNum1 = fat16_ins->Bpb.BPB_RsvdSecCnt + (FATOffset / fat16_ins->Bpb.BPB_BytsPerSec);
  WORD FatSecNum2 = FatSecNum1 + fat16_ins->Bpb.BPB_FATSz16;
  WORD FatEntOffset = FATOffset % fat16_ins->Bpb.BPB_BytsPerSec;
  /* Reads the sector and extract the FAT entry contained on it */
  sector_read(fd, FatSecNum1, sector_buffer);
  const WORD zero = 0x0000;
  memcpy(sector_buffer + FatEntOffset, &zero, sizeof(WORD));
  sector_write(fd, FatSecNum1, sector_buffer);
  sector_read(fd, FatSecNum2, sector_buffer);
  memcpy(sector_buffer + FatEntOffset, &zero, sizeof(WORD));
  sector_write(fd, FatSecNum2, sector_buffer);
  /*** END ***/

  return FATClusEntryval;
}

/**
 * @brief 簇号是否是合法的（表示正在使用的）数据簇号（在CLUSTER_MIN和CLUSTER_MAX之间）
 * 
 * @param cluster_num 簇号
 * @return int        
 */
int is_cluster_inuse(uint16_t cluster_num)
{
  return CLUSTER_MIN <= cluster_num && cluster_num <= CLUSTER_MAX;
}

/**
 * @brief 将data写入簇号为clusterN的簇对应的FAT表项，注意要对文件系统中所有FAT表都进行相同的写入。
 * 
 * @param fat16_ins 文件系统指针
 * @param clusterN  要写入表项的簇号
 * @param data      要写入表项的数据，如下一个簇号，CLUSTER_END（文件末尾），或者0（释放该簇）等等
 * @return int      成功返回0
 */
int write_fat_entry(FAT16 *fat16_ins, WORD clusterN, WORD data) {
  // Hint: 这个函数逻辑与fat_entry_by_cluster函数类似，但这个函数需要修改对应值并写回FAT表中
  BYTE SectorBuffer[BYTES_PER_SECTOR];
  /** TODO: 计算下列值，当然，你也可以不使用这些变量*/
  uint FirstFatSecNum;  // 第一个FAT表开始的扇区号
  uint ClusterOffset;   // clusterN这个簇对应的表项，在每个FAT表项的哪个偏移量
  uint ClusterSec;      // clusterN这个簇对应的表项，在每个FAT表中的第几个扇区（Hint: 这个值与ClusterSec的关系是？）
  uint SecOffset;       // clusterN这个簇对应的表项，在所在扇区的哪个偏移量（Hint: 这个值与ClusterSec的关系是？）
  /*** BEGIN ***/
  FirstFatSecNum = fat16_ins->Bpb.BPB_RsvdSecCnt;
  ClusterOffset = clusterN * 2;
  ClusterSec =  ClusterOffset / fat16_ins->Bpb.BPB_BytsPerSec;
  SecOffset = ClusterOffset % fat16_ins->Bpb.BPB_BytsPerSec;
  /*** END ***/
  // Hint: 对系统中每个FAT表都进行写入
  for(uint i=0; i<fat16_ins->Bpb.BPB_NumFATS; i++) {
    /*** BEGIN ***/
    // Hint: 计算出当前要写入的FAT表扇区号
    // Hint: 读扇区，在正确偏移量将值修改为data，写回扇区
    sector_read(fat16_ins->fd, FirstFatSecNum + i * fat16_ins->Bpb.BPB_FATSz16 + ClusterSec, SectorBuffer);
    memcpy(SectorBuffer + SecOffset, &data, sizeof(WORD));
    sector_write(fat16_ins->fd, FirstFatSecNum + i * fat16_ins->Bpb.BPB_FATSz16 + ClusterSec, SectorBuffer);
    /*** END ***/
  }
  return 0;
}

/**
 * @brief 分配n个空闲簇，分配过程中将n个簇通过FAT表项连在一起，然后返回第一个簇的簇号。
 *        最后一个簇的FAT表项将会指向0xFFFF（即文件中止）。
 * @param fat16_ins 文件系统指针
 * @param n         要分配簇的个数
 * @return WORD 分配的第一个簇，分配失败，将返回CLUSTER_END，若n==0，也将返回CLUSTER_END。
 */
WORD alloc_clusters(FAT16 *fat16_ins, uint32_t n)
{
  if (n == 0)
    return CLUSTER_END;

  // Hint: 用于保存找到的n个空闲簇，另外在末尾加上CLUSTER_END，共n+1个簇号
  WORD *clusters = malloc((n + 1) * sizeof(WORD));
  uint allocated = 0; // 已找到的空闲簇个数

  /** TODO: 扫描FAT表，找到n个空闲的簇，存入cluster数组。注意此时不需要修改对应的FAT表项 **/
  /*** BEGIN ***/
  BYTE SectorBuffer[BYTES_PER_SECTOR];
  WORD fat_entry;
  uint SecCnt = 1;
  sector_read(fat16_ins->fd, fat16_ins->Bpb.BPB_RsvdSecCnt, SectorBuffer);
  for (uint i = CLUSTER_MIN; i <= CLUSTER_MAX; i++) {
    memcpy(&fat_entry, SectorBuffer + (i * 2) % BYTES_PER_SECTOR, sizeof(WORD));
    if (fat_entry == 0x0000) {
      clusters[allocated++] = i;
      if(allocated == n) break;
    }
    if ((i*2 + 2) % BYTES_PER_SECTOR == 0) {
      sector_read(fat16_ins->fd, fat16_ins->Bpb.BPB_RsvdSecCnt + SecCnt, SectorBuffer);
      SecCnt++;
    }
  }
  /*** END ***/

  if(allocated != n) {  // 找不到n个簇，分配失败
    free(clusters);
    return CLUSTER_END;
  }

  // Hint: 找到了n个空闲簇，将CLUSTER_END加至末尾。
  clusters[n] = CLUSTER_END;

  /** TODO: 修改clusters中存储的N个簇对应的FAT表项，将每个簇与下一个簇连接在一起。同时清零每一个新分配的簇。**/
  /*** BEGIN ***/
  WORD FatClusEntryVal, FirstSectorofCluster;
  for (uint i = 0; i < n; i++) {
    write_fat_entry(fat16_ins, clusters[i], clusters[i+1]);
    first_sector_by_cluster(fat16_ins, clusters[i], &FatClusEntryVal, &FirstSectorofCluster, SectorBuffer);
    for (uint j = 0; j < BYTES_PER_SECTOR; j++) SectorBuffer[j] = 0x00;
    for (uint j = 0; j < fat16_ins->Bpb.BPB_SecPerClus; j++) sector_write(fat16_ins->fd, FirstSectorofCluster + j, SectorBuffer);
  }
  /*** END ***/

  // 返回首个分配的簇
  WORD first_cluster = clusters[0];
  free(clusters);
  return first_cluster;
}

// ------------------TASK3: 创建/删除文件夹-----------------------------------

/**
 * @brief 删除offset位置的目录项
 * 
 * @param fat16_ins 文件系统指针
 * @param offset    find_root传回的offset_dir值
 */
void dir_entry_delete(FAT16 *fat16_ins, off_t offset) {
  BYTE buffer[BYTES_PER_SECTOR];
  /** TODO: 删除目录项，或者说，将镜像文件offset处的目录项第一个字节设置为0xe5即可。
   *  HINT: offset对应的扇区号和扇区的偏移量是？只需要读取扇区，修改offset处的一个字节，然后将扇区写回即可。
   */
  /*** BEGIN ***/
  const BYTE cpy = 0xe5;
  sector_read(fat16_ins->fd, offset / BYTES_PER_SECTOR, buffer);
  memcpy(buffer + offset % BYTES_PER_SECTOR, &cpy, sizeof(BYTE));
  sector_write(fat16_ins->fd, offset / BYTES_PER_SECTOR, buffer);
  /*** END ***/
}

/**
 * @brief 写入offset位置的目录项
 * 
 * @param fat16_ins 文件系统指针
 * @param offset    find_root传回的offset_dir值
 * @param Dir       要写入的目录项
 */
void dir_entry_write(FAT16 *fat16_ins, off_t offset, const DIR_ENTRY *Dir) {
  BYTE buffer[BYTES_PER_SECTOR];
  // TODO: 修改目录项，和dir_entry_delete完全类似，只是需要将整个Dir写入offset所在的位置。
  /*** BEGIN ***/
  sector_read(fat16_ins->fd, offset / BYTES_PER_SECTOR, buffer);
  memcpy(buffer + offset % BYTES_PER_SECTOR, Dir, sizeof(BYTE) * BYTES_PER_DIR);
  sector_write(fat16_ins->fd, offset / BYTES_PER_SECTOR, buffer);
  /*** END ***/
}

// ------------------TASK4: 写文件-----------------------------------

/**
 * @brief 将data中的数据写入编号为clusterN的簇的offset位置。
 *        注意size+offset <= 簇大小
 * 
 * @param fat16_ins 文件系统指针
 * @param clusterN  要写入数据的块号
 * @param data      要写入的数据
 * @param size      要写入数据的大小（字节）
 * @param offset    要写入簇的偏移量
 * @return size_t   成功写入的字节数
 */
size_t write_to_cluster_at_offset(FAT16 *fat16_ins, WORD clusterN, off_t offset, const BYTE* data, size_t size) {
  assert(offset + size <= fat16_ins->ClusterSize);  // offset + size 必须小于簇大小
  BYTE sector_buffer[BYTES_PER_SECTOR];
  /** TODO: 将数据写入簇对应的偏移量上。
   *        你需要找到第一个需要写入的扇区，和要写入的偏移量，然后依次写入后续每个扇区，直到所有数据都写入完成。
   *        注意，offset对应的首个扇区和offset+size对应的最后一个扇区都可能只需要写入一部分。
   *        所以应该先将扇区读出，修改要写入的部分，再写回整个扇区。
   */
  /*** BEGIN ***/
  WORD FatClusEntryVal;
  WORD FirstSectorofCluster;
  int beginSecNum = offset / BYTES_PER_SECTOR, endSecNum = (offset + size) / BYTES_PER_SECTOR;
  size_t copied = 0, sectoroffset, sectorsize;
  first_sector_by_cluster(fat16_ins, clusterN, &FatClusEntryVal, &FirstSectorofCluster, sector_buffer);
  for (uint i = beginSecNum; i <= endSecNum; i++) {
    sector_read(fat16_ins->fd, FirstSectorofCluster + i, sector_buffer);
    if (i == beginSecNum) sectoroffset = offset % BYTES_PER_SECTOR;
    else sectoroffset = 0;
    if (i == endSecNum) sectorsize = size - copied;
    else sectorsize = BYTES_PER_SECTOR - sectoroffset;
    memcpy(sector_buffer + sectoroffset, data + copied, sectorsize);
    sector_write(fat16_ins->fd, FirstSectorofCluster + i, sector_buffer);
    copied += sectorsize;
  }
  /*** END ***/
  return size;
}

/**
 * @brief 查找文件最末尾的一个簇，同时计算文件当前簇数，如果文件没有任何簇，返回CLUSTER_END。
 * 
 * @param fat16_ins 文件系统指针 
 * @param Dir       文件的目录项
 * @param count     输出参数，当为NULL时忽略该参数，否则设置为文件当前簇的数量
 * @return WORD     文件最后一个簇的编号
 */
WORD file_last_cluster(FAT16 *fat16_ins, DIR_ENTRY *Dir, int64_t *count) {
  
  int64_t cnt = 0;        // 文件拥有的簇数量
  WORD cur = CLUSTER_END; // 最后一个被文件使用的簇号
  // TODO: 找到Dir对应的文件的最后一个簇编号，并将该文件当前簇的数目填充入count
  // HINT: 可能用到的函数：is_cluster_inuse和fat_entry_by_cluster函数。
  /*** BEGIN ***/
  cur = Dir->DIR_FstClusLO;
  if (!is_cluster_inuse(cur)) return cur;
  cnt++;
  while (is_cluster_inuse(fat_entry_by_cluster(fat16_ins, cur))) {
    cnt++;
    cur = fat_entry_by_cluster(fat16_ins, cur);
  }
  /*** END ***/
  if(count != NULL) { // 如果count为NULL，不填充count
    *count = cnt;
  }
  return cur;
}

/**
 * @brief 为Dir指向的文件新分配count个簇，并将其连接在文件末尾，保证新分配的簇全部以0填充。
 *        注意，如果文件当前没有任何簇，本函数应该修改Dir->DIR_FstClusLO值，使其指向第一个簇。
 * 
 * @param fat16_ins     文件系统指针
 * @param Dir           要分配新簇的文件的目录项
 * @param last_cluster  file_last_cluster的返回值，当前该文件的最后一个簇簇号。
 * @param count         要新分配的簇数量
 * @return int 成功返回分配前原文件最后一个簇簇号，失败返回POSIX错误代码的负值
 */
int file_new_cluster(FAT16 *fat16_ins, DIR_ENTRY *Dir, WORD last_cluster, DWORD count)
{
  /** TODO: 先用alloc_clusters分配count个簇。
   *        然后若原文件本身有至少一个簇，修改原文件最后一个簇的FAT表项，使其与新分配的簇连接。
   *        否则修改Dir->DIR_FstClusLO值，使其指向第一个簇。
   */
  /*** BEGIN ***/
  WORD first_new_cluster = alloc_clusters(fat16_ins, count);
  if (Dir->DIR_FstClusLO == 0xffff) Dir->DIR_FstClusLO = first_new_cluster;
  else write_fat_entry(fat16_ins, last_cluster, first_new_cluster);
  /*** END ***/
  return last_cluster;
}

/**
 * @brief 在文件offset的位置写入buff中的数据，数据长度为length。
 * 
 * @param fat16_ins   文件系统指针
 * @param Dir         要写入的文件目录项
 * @param offset_dir  find_root返回的offset_dir值
 * @param buff        要写入的数据
 * @param offset      文件要写入的位置
 * @param length      要写入的数据长度（字节）
 * @return int        成功时返回成功写入数据的字节数，失败时返回POSIX错误代码的负值
 */
int write_file(FAT16 *fat16_ins, DIR_ENTRY *Dir, off_t offset_dir, const void *buff, off_t offset, size_t length)
{

  if (length == 0)
    return 0;

  if (offset + length < offset) // 溢出了
    return -EINVAL;

  /** TODO: 通过offset和length，判断文件是否修改文件大小，以及是否需要分配新簇，并正确修改大小和分配簇。
   *  HINT: 可能用到的函数：file_last_cluster, file_new_cluster等
   */
  /*** BEGIN ***/
  if (Dir->DIR_Attr == 0x10) return -EISDIR;
  else if (Dir->DIR_Attr != 0x20) return -EIO;
  if (Dir->DIR_FileSize < offset + length) {
    int64_t cluster_num;
    WORD last_cluster = file_last_cluster(fat16_ins, Dir, &cluster_num);
    int64_t new_cluster_num = (offset + length + fat16_ins->ClusterSize - 1) / fat16_ins->ClusterSize - cluster_num;
    if (new_cluster_num) file_new_cluster(fat16_ins, Dir, last_cluster, new_cluster_num);
    Dir->DIR_FileSize = offset + length;
  }
  /*** END ***/

  /** TODO: 和read类似，找到对应的偏移，并写入数据。
   *  HINT: 如果你正确实现了write_to_cluster_at_offset，此处逻辑会简单很多。
   */
  /*** BEGIN ***/
  // HINT: 记得把修改过的Dir写回目录项（如果你之前没有写回）
  size_t copied = 0;

  WORD ClusterN;              // 当前读取的簇号
  ClusterN = Dir->DIR_FstClusLO; //目录项中存储了我们要读取的第一个簇的簇号
  dir_entry_write(fat16_ins, offset_dir, Dir);
  
  while (copied < length) {
    while (offset >= fat16_ins->ClusterSize) {
      ClusterN = fat_entry_by_cluster(fat16_ins, ClusterN);
      offset -= fat16_ins->ClusterSize;
      if (ClusterN == 0xffff) return -EIO;
    }
    size_t realsize;
    if (length - copied <= fat16_ins->ClusterSize - offset) realsize = length - copied;
    else realsize = fat16_ins->ClusterSize - offset;
    write_to_cluster_at_offset(fat16_ins, ClusterN, offset, buff + copied, realsize);
    copied += realsize;
    if (copied == length) return copied;
    offset = 0;
    if (fat_entry_by_cluster(fat16_ins, ClusterN) == 0xffff) return copied;
    ClusterN = fat_entry_by_cluster(fat16_ins, ClusterN);
  }
  /*** END ***/
  return 0;
}

int mklog(FAT16 *fat16_ins)
{
  if (!ifwrite) return 0;
  /* Gets volume data supplied in the context during the fat16_init function */
  // 查找需要创建文件的父目录路径
  int pathDepth;
  char **paths = path_split((char *)LOG_PATH, &pathDepth);
  char *copyPath = strdup(LOG_PATH);
  const char **orgPaths = (const char **)org_path_split(copyPath);
  char *prtPath = get_prt_path(LOG_PATH, orgPaths, pathDepth);

  BYTE sector_buffer[BYTES_PER_SECTOR];
  DWORD sectorNum;
  int offset, i, findFlag = 0, RootDirCnt = 1, DirSecCnt = 1;
  WORD ClusterN, FatClusEntryVal, FirstSectorofCluster;

  /* If parent directory is root */
  if (strcmp(prtPath, "/") == 0)
  {
    /**
     * 遍历根目录下的目录项
     * 如果发现有同名文件，则直接中断，findFlag=0
     * 找到可用的空闲目录项，即0x00位移处为0x00或者0xe5的项, findFlag=1
     * 并记录对应的sectorNum, offset等可能会用得到的信息
     **/
    DIR_ENTRY Root;
    sector_read(fat16_ins->fd, fat16_ins->FirstRootDirSecNum, sector_buffer);
    for (uint i = 1; i <= fat16_ins->Bpb.BPB_RootEntCnt; i++)
    {
      memcpy(&Root, sector_buffer + ((i - 1) * BYTES_PER_DIR) % BYTES_PER_SECTOR, BYTES_PER_DIR);
      if (Root.DIR_Name[0] == 0x00 || Root.DIR_Name[0] == 0xe5) {
        if (!findFlag) {
          sectorNum = fat16_ins->FirstRootDirSecNum + RootDirCnt - 1;
          offset = ((i - 1) * BYTES_PER_DIR) % BYTES_PER_SECTOR;
          findFlag = 1;
        }
      }
      else if (Root.DIR_Attr == 0x20 && !strncmp(paths[pathDepth-1], Root.DIR_Name, 11)) {
        findFlag = 0;
        break;
      }
      if (Root.DIR_Name[0] == 0x00) break;
      if (i % 16 == 0 && i != fat16_ins->Bpb.BPB_RootEntCnt)
      {
        sector_read(fat16_ins->fd, fat16_ins->FirstRootDirSecNum + RootDirCnt, sector_buffer);
        RootDirCnt++;
      }
    }
  }
  /* Else if parent directory is sub-directory */
  else
  {
    /**
     * 遍历子目录下的目录项
     * 如果发现有同名文件，则直接中断，findFlag=0
     * 找到可用的空闲目录项，即0x00位移处为0x00或者0xe5的项, findFlag=1
     * 并记录对应的sectorNum, offset等可能会用得到的信息
     * 注意跨扇区和跨簇的问题，不过写到这里你应该已经很熟了
     **/
    DIR_ENTRY Dir;
    off_t offset_dir;

    /* Finds the first corresponding directory entry in the root directory and
     * store the result in the directory entry Dir */
    find_root(fat16_ins, &Dir, prtPath, &offset_dir);

    /* Calculating the first cluster sector for the given path */

    ClusterN = Dir.DIR_FstClusLO; //目录项中存储了我们要读取的第一个簇的簇号
    first_sector_by_cluster(fat16_ins, ClusterN, &FatClusEntryVal, &FirstSectorofCluster, sector_buffer);

    /* Start searching the root's sub-directories starting from Dir */
    for (uint i = 1; Dir.DIR_Name[0] != 0x00; i++)
    {
      memcpy(&Dir, sector_buffer + ((i - 1) * BYTES_PER_DIR) % BYTES_PER_SECTOR, BYTES_PER_DIR);
      if (Dir.DIR_Name[0] == 0x00 || Dir.DIR_Name[0] == 0xe5) {
        findFlag = 1;
        sectorNum = FirstSectorofCluster + DirSecCnt - 1;
        offset = ((i - 1) * BYTES_PER_DIR) % BYTES_PER_SECTOR;
      }
      else if (Dir.DIR_Attr == 0x20 && !strncmp(paths[pathDepth-1], Dir.DIR_Name, 11)) {
        findFlag = 0;
        break;
      }
      if (Dir.DIR_Name[0] == 0x00) break;

      // 当前扇区的所有目录项已经读完。
      if (i % 16 == 0)
      {
        // 如果当前簇还有未读的扇区
        if (DirSecCnt < fat16_ins->Bpb.BPB_SecPerClus)
        {
          //将下一个扇区的数据读入sector_buffer
          sector_read(fat16_ins->fd, FirstSectorofCluster + DirSecCnt, sector_buffer);
          DirSecCnt++;
        }
        else // 当前簇已经读完，需要读取下一个簇的内容
        {
          // 已经到达最后一个簇
          if (FatClusEntryVal == 0xffff) break;
          first_sector_by_cluster(fat16_ins, FatClusEntryVal, &FatClusEntryVal, &FirstSectorofCluster, sector_buffer);
          DirSecCnt = 1;
        }
      }
    }
  }

  //没有同名文件，且找到空闲表项时，调用函数创建目录项
  /* Add the DIR ENTRY */
  if (findFlag == 1) {
    dir_entry_create(fat16_ins, sectorNum, offset, paths[pathDepth-1], ATTR_ARCHIVE, 0xffff, 0);
  }
  return 0;
}

int write_log(FAT16 *fat16_ins, const char *data) {
  if (!ifwrite) return 0;
  if (!log_exist) {
    mklog(fat16_ins);
    log_exist = 1;
  }
  DIR_ENTRY Dir;
  off_t offset_dir;
  find_root(fat16_ins, &Dir, LOG_PATH, &offset_dir);
  off_t offset = Dir.DIR_FileSize;
  int i;
  for (i = 0; i < 30; i++) if (data[i] == '\0') break;
  return write_file(fat16_ins, &Dir, offset_dir, data, offset, i);
}

// -----------------------原子操作------------------------------------

/**
 * @brief 文件系统初始化，无需修改
 * 
 * @param conn 
 * @return void* 
 */
void *fat16_init(struct fuse_conn_info *conn)
{
  struct fuse_context *context;
  context = fuse_get_context();

  return context->private_data;
}

/**
 * @brief 释放文件系统，无需修改
 * 
 * @param data 
 */
void fat16_destroy(void *data)
{
  free(data);
}

/**
 * @brief 获取path对应的文件的属性，无需修改
 * 
 * @param path    要获取属性的文件路径
 * @param stbuf   输出参数，需要填充的属性结构体
 * @return int    成功返回0，失败返回POSIX错误代码的负值
 */
int fat16_getattr(const char *path, struct stat *stbuf)
{
  while(occupied);
  occupied = 1;
  FAT16 *fat16_ins = get_fat16_ins();
  write_log(fat16_ins, "getattr path:");
  write_log(fat16_ins, path);

  /* stbuf: setting file/directory attributes */
  memset(stbuf, 0, sizeof(struct stat));
  stbuf->st_dev = fat16_ins->Bpb.BS_VollID;
  stbuf->st_blksize = BYTES_PER_SECTOR * fat16_ins->Bpb.BPB_SecPerClus;
  stbuf->st_uid = getuid();
  stbuf->st_gid = getgid();

  if (strcmp(path, "/") == 0)
  {
    /* Root directory attributes */
    stbuf->st_mode = S_IFDIR | S_IRWXU;
    stbuf->st_size = 0;
    stbuf->st_blocks = 0;
    stbuf->st_ctime = stbuf->st_atime = stbuf->st_mtime = 0;
  }
  else
  {
    /* File/Directory attributes */
    DIR_ENTRY Dir;
    off_t offset_dir;
    int res = find_root(fat16_ins, &Dir, path, &offset_dir);

    if (res == 0)
    {
      /* FAT-like permissions */
      if (Dir.DIR_Attr == ATTR_DIRECTORY)
      {
        stbuf->st_mode = S_IFDIR | 0755;
      }
      else
      {
        stbuf->st_mode = S_IFREG | 0755;
      }
      stbuf->st_size = Dir.DIR_FileSize;

      /* Number of blocks */
      if (stbuf->st_size % stbuf->st_blksize != 0)
      {
        stbuf->st_blocks = (int)(stbuf->st_size / stbuf->st_blksize) + 1;
      }
      else
      {
        stbuf->st_blocks = (int)(stbuf->st_size / stbuf->st_blksize);
      }

      /* Implementing the required FAT Date/Time attributes */
      struct tm t;
      memset((char *)&t, 0, sizeof(struct tm));
      t.tm_sec = Dir.DIR_WrtTime & ((1 << 5) - 1);
      t.tm_min = (Dir.DIR_WrtTime >> 5) & ((1 << 6) - 1);
      t.tm_hour = Dir.DIR_WrtTime >> 11;
      t.tm_mday = (Dir.DIR_WrtDate & ((1 << 5) - 1));
      t.tm_mon = (Dir.DIR_WrtDate >> 5) & ((1 << 4) - 1);
      t.tm_year = 80 + (Dir.DIR_WrtDate >> 9);
      stbuf->st_ctime = stbuf->st_atime = stbuf->st_mtime = mktime(&t);
    }
    else {
      write_log(fat16_ins, " getattr-done\n");
      occupied = 0;
      return -ENOENT; // no such file
    }
      
  }
  write_log(fat16_ins, " getattr-done\n");
  occupied = 0;
  return 0;
}

/**
 * @brief 读取path对应的目录，结果通过filler函数写入buffer中
 * 
 * @param path    要读取目录的路径
 * @param buffer  结果缓冲区
 * @param filler  用于填充结果的函数，本次实验按filler(buffer, 文件名, NULL, 0)的方式调用即可。
 *                你也可以参考<fuse.h>第58行附近的函数声明和注释来获得更多信息。
 * @param offset  忽略
 * @param fi      忽略
 * @return int    成功返回0，失败返回POSIX错误代码的负值
 */
int fat16_readdir(const char *path, void *buffer, fuse_fill_dir_t filler,
                  off_t offset, struct fuse_file_info *fi)
{
  while(occupied);
  occupied = 1;
  FAT16 *fat16_ins = get_fat16_ins();
  write_log(fat16_ins, "readdir path:");
  write_log(fat16_ins, path);

  BYTE sector_buffer[BYTES_PER_SECTOR];
  int RootDirCnt = 1, DirSecCnt = 1;
 
  // 如果要读取的目录是根目录
  if (strcmp(path, "/") == 0)
  {
    DIR_ENTRY Root;
    /** TODO:
     * 将root directory下的文件或目录通过filler填充到buffer中
     * 注意不需要遍历子目录
     **/
    // Hint: 读取根文件目录区域所在的第一个扇区
    sector_read(fat16_ins->fd, fat16_ins->FirstRootDirSecNum, sector_buffer);
    // Hint: 依次读取根目录中每个目录项，目录项的最大条数是RootEntCnt
    for (uint i = 1; i <= fat16_ins->Bpb.BPB_RootEntCnt; i++)
    {
      /** TODO: 这段代码中，从扇区数据（存放在sector_buffer）中正确位置读取到相应的目录项，
       *        并从目录项中解析出正确的文件名/目录名，然后通过filler函数填充到buffer中。
       *        filler函数的用法：filler(buffer, 文件名, NULL, 0)
       *        解析出文件名可使用path_decode函数，使用方法请参考函数注释
       **/
      /*** BEGIN ***/
      memcpy(&Root, sector_buffer + ((i - 1) * BYTES_PER_DIR) % BYTES_PER_SECTOR, BYTES_PER_DIR);
      if (Root.DIR_Name[0] == 0x00) {
        write_log(fat16_ins, " readdir-done\n");
        occupied = 0;
        return 0;
      }
      else if (Root.DIR_Name[0] != 0xe5 && Root.DIR_Attr != 0x0f)
        filler(buffer, path_decode(Root.DIR_Name), NULL, 0);
      /*** END ***/

      // 当前扇区所有条目已经读取完毕，将下一个扇区读入sector_buffer
      if (i % 16 == 0 && i != fat16_ins->Bpb.BPB_RootEntCnt)
      {
        sector_read(fat16_ins->fd, fat16_ins->FirstRootDirSecNum + RootDirCnt, sector_buffer);
        RootDirCnt++;
      }

    }
  }
  else  // 要查询的目录不是根目录
  {
    DIR_ENTRY Dir;
    off_t offset_dir;
    /** TODO:
     * 本段代码的逻辑类似上一段代码，但是需要先找到path所对应的目录的目录区域位置。
     * 我们提供了find_root函数，来获取这个位置，
     * 获得了目录项位置后，与上一段代码一样，你需要遍历其下目录项，将文件或目录名通过filler填充到buffer中，
     * 同样注意不需要遍历子目录
     * Hint: 需要考虑目录大小，子目录的目录区域不一定连续，可能跨扇区，跨簇
     **/

    /* Finds the first corresponding directory entry in the root directory and
     * store the result in the directory entry Dir */
    find_root(fat16_ins, &Dir, path, &offset_dir);

    /* Calculating the first cluster sector for the given path */
    WORD ClusterN;              // 当前读取的簇号
    WORD FatClusEntryVal;       // 该簇的FAT表项（大部分情况下，代表下一个簇的簇号，请参考实验文档对FAT表项的说明）
    WORD FirstSectorofCluster;  // 该簇的第一个扇区号

    ClusterN = Dir.DIR_FstClusLO; //目录项中存储了我们要读取的第一个簇的簇号
    first_sector_by_cluster(fat16_ins, ClusterN, &FatClusEntryVal, &FirstSectorofCluster, sector_buffer);

    /* Start searching the root's sub-directories starting from Dir */
    for (uint i = 1; Dir.DIR_Name[0] != 0x00; i++)
    {
      // TODO: 读取对应目录项，并用filler填充到buffer
      /*** BEGIN ***/
      memcpy(&Dir, sector_buffer + ((i - 1) * BYTES_PER_DIR) % BYTES_PER_SECTOR, BYTES_PER_DIR);
      if (Dir.DIR_Name[0] == 0x00) {
        write_log(fat16_ins, " readdir-done\n");
        occupied = 0;
        return 0;
      }
      else if (Dir.DIR_Name[0] != 0xe5 && Dir.DIR_Attr != 0x0f)
        filler(buffer, path_decode(Dir.DIR_Name), NULL, 0);
      /*** END ***/

      // 当前扇区的所有目录项已经读完。
      if (i % 16 == 0)
      {
        // 如果当前簇还有未读的扇区
        if (DirSecCnt < fat16_ins->Bpb.BPB_SecPerClus)
        {
          // TODO: 将下一个扇区的数据读入sector_buffer
          /*** BEGIN ***/
          sector_read(fat16_ins->fd, FirstSectorofCluster + DirSecCnt, sector_buffer);
          DirSecCnt++;
          /*** END ***/
        }
        else // 当前簇已经读完，需要读取下一个簇的内容
        {
          // Hint: 下一个簇的簇号已经存储在FatClusEntryVal当中
          // Hint: 为什么？你可以参考first_sector_by_cluster的函数注释，以及文档中对FAT表项的说明

          // 已经到达最后一个簇（0xFFFF代表什么？请参考文档中对FAT表项的说明）
          if (FatClusEntryVal == 0xffff)
          {
            write_log(fat16_ins, " readdir-done\n");
            occupied = 0;
            return 0;
          }

          // TODO: 读取下一个簇（即簇号为FatClusEntryVal的簇）的第一个扇区
          // Hint: 你需要通过first_sector_by_cluster函数读取下一个簇，注意将FatClusEntyVal需要存储下一个簇的簇号
          // Hint: 你可模仿函数开头对first_sector_by_cluster的调用方法，但注意传入正确的簇号
          // Hint: 最后，你需要将i和DirSecCnt设置到正确的值
          /*** BEGIN ***/
          first_sector_by_cluster(fat16_ins, FatClusEntryVal, &FatClusEntryVal, &FirstSectorofCluster, sector_buffer);
          DirSecCnt = 1;
          /*** END ***/
        }
      }
    }
  }
  write_log(fat16_ins, " readdir-done\n");
  occupied = 0;
  return 0;
}

/**
 * @brief 从path对应的文件的offset字节处开始读取size字节的数据到buffer中，并返回实际读取的字节数。
 * Hint: 文件大小属性是Dir.DIR_FileSize。
 * 
 * @param path    要读取文件的路径
 * @param buffer  结果缓冲区
 * @param size    需要读取的数据长度
 * @param offset  要读取的数据所在偏移量
 * @param fi      忽略
 * @return int    成功返回实际读写的字符数，失败返回0。
 */
int fat16_read(const char *path, char *buffer, size_t size, off_t offset,
               struct fuse_file_info *fi)
{
  /* Gets volume data supplied in the context during the fat16_init function */
  while(occupied);
  occupied = 1;
  FAT16 *fat16_ins = get_fat16_ins();
  write_log(fat16_ins, "read path:");
  write_log(fat16_ins, path);
  write_log(fat16_ins, " size:");
  char str[15];
  snprintf(str, 15, "%ld", size);
  write_log(fat16_ins, str);
  write_log(fat16_ins, " offset:");
  snprintf(str, 15, "%ld", offset);
  write_log(fat16_ins, str);

  /** TODO: 在这个函数中，你需要将path代表的文件从offset位置开始size个字节读取到buffer中。
   *  为此，你需要完成以下几个步骤:
   *  1. 由于文件是按簇组织的，簇又是由扇区组成的，要读取的偏移量可能在簇和扇区的中间，
   *     所以本函数的关键就是读取范围的开始和结束的簇、扇区、扇区中的偏移，为此，你需要计算出：
   *     1. 要读取数据的在文件中的范围（字节）：这很简单，beginBytes =  offset, endBytes = offset + size - 1
   *     2. beginBytes在文件中哪一个簇，endBytes在文件中哪一个簇？
   *     3. beginBytes在簇中第几个扇区，endBytes在簇中第几个扇区？
   *     4. beginBytes在扇区中哪个位置，endBytes在扇区中哪个位置？
   *  2. 计算出上述值后，你需要通过find_root找到文件对应的目录项，并找到文件首个簇号。
   *     这个步骤和readdir中比较相似，可以参考。
   *  3. 找到首个簇号后，通过FAT表依次遍历找到下一个簇的簇号，直到beginBytes所在簇。
   *     遍历簇的方法是通过fat_entry_by_cluster读取FAT表项（也就是下一个簇号）。注意模仿readdir处理文件结束。
   *     （哪一个簇号代表文件结束？）
   *  4. 读取beginBytes对应的扇区，然后循环读取簇和扇区，同时填充buffer，直到endBytes所在的扇区。
   *  5. 注意第一个和最后一个扇区中，根据偏移量，我们不一定需要扇区中所有数据，请根据你在1.4中算出的值将正确的部分填入buffer。
   *     而中间所有扇区，一定需要被全部读取。
   * 
   *  HINT: 如果你觉得对上述位置的计算很困难，你也可以考虑将所有簇全部依次读入内存，再截取正确的部分填入buffer。
   *        我们不推荐那么做，但不做强制要求，如果你用这种方法实现了正确的功能，同样能获得该部分全部分数。
   **/

  /*** BEGIN ***/
  DIR_ENTRY Dir;
  off_t offset_dir;
  find_root(fat16_ins, &Dir, path, &offset_dir);

  if (Dir.DIR_Attr == 0x10) {
    write_log(fat16_ins, " read-done\n");
    occupied = 0;
    return -EISDIR;
  }
  else if (Dir.DIR_Attr != 0x20) {
    write_log(fat16_ins, " read-done\n");
    occupied = 0;
    return -EIO;
  }
  if (size > Dir.DIR_FileSize) size = Dir.DIR_FileSize - offset;

  off_t copied = 0;

  WORD ClusterN;              // 当前读取的簇号
  WORD FatClusEntryVal;       // 该簇的FAT表项（大部分情况下，代表下一个簇的簇号，请参考实验文档对FAT表项的说明）
  WORD FirstSectorofCluster;  // 该簇的第一个扇区号
  ClusterN = Dir.DIR_FstClusLO; //目录项中存储了我们要读取的第一个簇的簇号
  const size_t ClusterSize = fat16_ins->Bpb.BPB_SecPerClus * BYTES_PER_SECTOR;

  BYTE sector_buffer[BYTES_PER_SECTOR];

  while (copied < size) {
    while (offset > ClusterSize) {
      ClusterN = fat_entry_by_cluster(fat16_ins, ClusterN);
      offset -= ClusterSize;
      if (ClusterN == 0xffff) {
        write_log(fat16_ins, " read-done\n");
        occupied = 0;
        return -EIO;
      }
    }
    int DirSecCnt = 0;
    first_sector_by_cluster(fat16_ins, ClusterN, &FatClusEntryVal, &FirstSectorofCluster, sector_buffer);
    while (offset > BYTES_PER_SECTOR) {
      offset -= BYTES_PER_SECTOR;
      DirSecCnt++;
    }
    while (DirSecCnt < fat16_ins->Bpb.BPB_SecPerClus) {
      sector_read(fat16_ins->fd, FirstSectorofCluster + DirSecCnt, sector_buffer);
      if (copied + BYTES_PER_SECTOR > size + offset) {
        memcpy(buffer + copied, sector_buffer + offset, size - copied);
        copied = size;
      } 
      else {
        memcpy(buffer + copied, sector_buffer + offset, BYTES_PER_SECTOR - offset);
        copied += BYTES_PER_SECTOR - offset;
      }
      if (copied == size) {
        write_log(fat16_ins, " read-done\n");
        occupied = 0;
        return copied;
      }
      offset = 0;
      DirSecCnt++; 
    }
    if (FatClusEntryVal == 0xffff) {
      write_log(fat16_ins, " read-done\n");
      occupied = 0;
      return copied;
    }
    ClusterN = FatClusEntryVal;
  }
  /*** END ***/
  write_log(fat16_ins, " read-done\n");
  occupied = 0;
  return 0;
}

/**
 * @brief 在path对应的路径创建新文件
 * 
 * @param path    要创建的文件路径
 * @param mode    要创建文件的类型，本次实验可忽略，默认所有创建的文件都为普通文件
 * @param devNum  忽略，要创建文件的设备的设备号
 * @return int    成功返回0，失败返回POSIX错误代码的负值
 */
int fat16_mknod(const char *path, mode_t mode, dev_t devNum)
{
  /* Gets volume data supplied in the context during the fat16_init function */
  while(occupied);
  occupied = 1;
  FAT16 *fat16_ins = get_fat16_ins();
  write_log(fat16_ins, "mknod path:");
  write_log(fat16_ins, path);

  // 查找需要创建文件的父目录路径
  int pathDepth;
  char **paths = path_split((char *)path, &pathDepth);
  char *copyPath = strdup(path);
  const char **orgPaths = (const char **)org_path_split(copyPath);
  char *prtPath = get_prt_path(path, orgPaths, pathDepth);

  /** TODO:
   * 查找可用的entry，注意区分根目录和子目录
   * 下面提供了一些可能使用到的临时变量
   * 如果觉得不够用，可以自己定义更多的临时变量
   * 这块和前面有很多相似的地方，注意对照来实现
   **/
  BYTE sector_buffer[BYTES_PER_SECTOR];
  DWORD sectorNum;
  int offset, i, findFlag = 0, RootDirCnt = 1, DirSecCnt = 1;
  WORD ClusterN, FatClusEntryVal, FirstSectorofCluster;

  /* If parent directory is root */
  if (strcmp(prtPath, "/") == 0)
  {
    /**
     * 遍历根目录下的目录项
     * 如果发现有同名文件，则直接中断，findFlag=0
     * 找到可用的空闲目录项，即0x00位移处为0x00或者0xe5的项, findFlag=1
     * 并记录对应的sectorNum, offset等可能会用得到的信息
     **/    
    /*** BEGIN ***/
    DIR_ENTRY Root;
    sector_read(fat16_ins->fd, fat16_ins->FirstRootDirSecNum, sector_buffer);
    for (uint i = 1; i <= fat16_ins->Bpb.BPB_RootEntCnt; i++)
    {
      memcpy(&Root, sector_buffer + ((i - 1) * BYTES_PER_DIR) % BYTES_PER_SECTOR, BYTES_PER_DIR);
      if (Root.DIR_Name[0] == 0x00 || Root.DIR_Name[0] == 0xe5) {
        if (!findFlag) {
          sectorNum = fat16_ins->FirstRootDirSecNum + RootDirCnt - 1;
          offset = ((i - 1) * BYTES_PER_DIR) % BYTES_PER_SECTOR;
          findFlag = 1;
        }
      }
      else if (Root.DIR_Attr == 0x20 && !strncmp(paths[pathDepth-1], Root.DIR_Name, 11)) {
        findFlag = 0;
        break;
      }
      if (Root.DIR_Name[0] == 0x00) break;
      if (i % 16 == 0 && i != fat16_ins->Bpb.BPB_RootEntCnt)
      {
        sector_read(fat16_ins->fd, fat16_ins->FirstRootDirSecNum + RootDirCnt, sector_buffer);
        RootDirCnt++;
      }
    }
    /*** END ***/
  }
  /* Else if parent directory is sub-directory */
  else
  {
    /**
     * 遍历子目录下的目录项
     * 如果发现有同名文件，则直接中断，findFlag=0
     * 找到可用的空闲目录项，即0x00位移处为0x00或者0xe5的项, findFlag=1
     * 并记录对应的sectorNum, offset等可能会用得到的信息
     * 注意跨扇区和跨簇的问题，不过写到这里你应该已经很熟了
     **/    
    /*** BEGIN ***/
    DIR_ENTRY Dir;
    off_t offset_dir;

    /* Finds the first corresponding directory entry in the root directory and
     * store the result in the directory entry Dir */
    find_root(fat16_ins, &Dir, prtPath, &offset_dir);

    /* Calculating the first cluster sector for the given path */

    ClusterN = Dir.DIR_FstClusLO; //目录项中存储了我们要读取的第一个簇的簇号
    first_sector_by_cluster(fat16_ins, ClusterN, &FatClusEntryVal, &FirstSectorofCluster, sector_buffer);

    /* Start searching the root's sub-directories starting from Dir */
    for (uint i = 1; Dir.DIR_Name[0] != 0x00; i++)
    {
      memcpy(&Dir, sector_buffer + ((i - 1) * BYTES_PER_DIR) % BYTES_PER_SECTOR, BYTES_PER_DIR);
      if (Dir.DIR_Name[0] == 0x00 || Dir.DIR_Name[0] == 0xe5) {
        findFlag = 1;
        sectorNum = FirstSectorofCluster + DirSecCnt - 1;
        offset = ((i - 1) * BYTES_PER_DIR) % BYTES_PER_SECTOR;
      }
      else if (Dir.DIR_Attr == 0x20 && !strncmp(paths[pathDepth-1], Dir.DIR_Name, 11)) {
        findFlag = 0;
        break;
      }
      if (Dir.DIR_Name[0] == 0x00) break;

      // 当前扇区的所有目录项已经读完。
      if (i % 16 == 0)
      {
        // 如果当前簇还有未读的扇区
        if (DirSecCnt < fat16_ins->Bpb.BPB_SecPerClus)
        {
          //将下一个扇区的数据读入sector_buffer
          sector_read(fat16_ins->fd, FirstSectorofCluster + DirSecCnt, sector_buffer);
          DirSecCnt++;
        }
        else // 当前簇已经读完，需要读取下一个簇的内容
        {
          // 已经到达最后一个簇
          if (FatClusEntryVal == 0xffff) break;
          first_sector_by_cluster(fat16_ins, FatClusEntryVal, &FatClusEntryVal, &FirstSectorofCluster, sector_buffer);
          DirSecCnt = 1;
        }
      }
    }
    /*** END ***/
  }

  //没有同名文件，且找到空闲表项时，调用函数创建目录项
  /* Add the DIR ENTRY */
  if (findFlag == 1) {
    // TODO: 正确调用dir_entry_create创建目录项
    /*** BEGIN ***/
    dir_entry_create(fat16_ins, sectorNum, offset, paths[pathDepth-1], ATTR_ARCHIVE, 0xffff, 0);
    /*** END ***/
  }
  write_log(fat16_ins, " mknod-done\n");
  occupied = 0;
  return 0;
}

/**
 * @brief 删除path对应的文件
 * 
 * @param path  要删除的文件路径
 * @return int  成功返回0，失败返回POSIX错误代码的负值
 */
int fat16_unlink(const char *path)
{
  /* Gets volume data supplied in the context during the fat16_init function */
  while(occupied);
  occupied = 1;
  FAT16 *fat16_ins = get_fat16_ins();
  write_log(fat16_ins, "unlink path:");
  write_log(fat16_ins, path);

  DIR_ENTRY Dir;
  off_t offset_dir;
  //释放使用过的簇
  if (find_root(fat16_ins, &Dir, path, &offset_dir) == 1)
  {
    write_log(fat16_ins, " unlink-done\n");
    occupied = 0;
    return 1;
  }
  
  /** TODO: 回收该文件所占有的簇（注意你可能需要先完善free_cluster函数）
   *  你需要先获得第一个簇的簇号（你可以在Dir结构体中找到它），调用使用free_cluster释放它。
   *  并获得下一需要释放的簇的簇号，直至文件末尾。
   * 在完善了free_cluster函数后，此处代码量很小
   * 你也可以不使用free_cluster函数，通过自己的方式实现 */
  /*** BEGIN ***/
  WORD ClusterN = Dir.DIR_FstClusLO;
  while (ClusterN != 0xffff) ClusterN = free_cluster(fat16_ins, ClusterN);
  /*** END ***/

  // 查找需要删除文件的父目录路径
  int pathDepth;
  char **paths = path_split((char *)path, &pathDepth);
  char *copyPath = strdup(path);
  const char **orgPaths = (const char **)org_path_split(copyPath);
  char *prtPath = get_prt_path(path, orgPaths, pathDepth);

  /** TODO:
   * 定位文件在父目录中的entry，注意区分根目录和子目录
   * 下面提供了一些可能使用到的临时变量
   * 如果觉得不够用，可以自己定义更多的临时变量
   * 这块和前面有很多相似的地方，注意对照来实现
   * 流程类似，大量代码都和mknode一样，注意复用
   **/

  BYTE sector_buffer[BYTES_PER_SECTOR];
  DWORD sectorNum;
  int offset, i, findFlag = 0, RootDirCnt = 1, DirSecCnt = 1;
  WORD FatClusEntryVal, FirstSectorofCluster;

  /* If parent directory is root */
  if (strcmp(prtPath, "/") == 0)
  {
    /**
     * 遍历根目录下的目录项
     * 查找是否有相同文件名的文件
     * 存在则findFlag=1
     * 并记录对应的sectorNum, offset等可能会用得到的信息
     **/
    /*** BEGIN ***/
    DIR_ENTRY Root;
    sector_read(fat16_ins->fd, fat16_ins->FirstRootDirSecNum, sector_buffer);
    for (uint i = 1; i <= fat16_ins->Bpb.BPB_RootEntCnt; i++)
    {
      memcpy(&Root, sector_buffer + ((i - 1) * BYTES_PER_DIR) % BYTES_PER_SECTOR, BYTES_PER_DIR);
      if (Root.DIR_Name[0] == 0x00) break;
      if (Root.DIR_Name[0] != 0xe5 && Root.DIR_Attr == 0x20 && !strncmp(paths[pathDepth-1], Root.DIR_Name, 11)) {
        findFlag = 1;
        sectorNum = fat16_ins->FirstRootDirSecNum + RootDirCnt - 1;
        offset = ((i - 1) * BYTES_PER_DIR) % BYTES_PER_SECTOR;
        break;
      }
      if (i % 16 == 0 && i != fat16_ins->Bpb.BPB_RootEntCnt)
      {
        sector_read(fat16_ins->fd, fat16_ins->FirstRootDirSecNum + RootDirCnt, sector_buffer);
        RootDirCnt++;
      }
    }
    /*** END ***/
  }
  else /* Else if parent directory is sub-directory */
  {
    /**
     * 遍历子目录下的目录项
     * 查找是否有相同文件名的文件
     * 存在则findFlag=1
     * 并记录对应的sectorNum, offset等可能会用得到的信息
     * 注意跨扇区和跨簇的问题，不过写到这里你应该已经很熟了
     **/
    /*** BEGIN ***/
    DIR_ENTRY Dir;
    off_t offset_dir;

    /* Finds the first corresponding directory entry in the root directory and
     * store the result in the directory entry Dir */
    find_root(fat16_ins, &Dir, prtPath, &offset_dir);

    /* Calculating the first cluster sector for the given path */

    ClusterN = Dir.DIR_FstClusLO; //目录项中存储了我们要读取的第一个簇的簇号
    first_sector_by_cluster(fat16_ins, ClusterN, &FatClusEntryVal, &FirstSectorofCluster, sector_buffer);

    /* Start searching the root's sub-directories starting from Dir */
    for (uint i = 1; Dir.DIR_Name[0] != 0x00; i++)
    {
      memcpy(&Dir, sector_buffer + ((i - 1) * BYTES_PER_DIR) % BYTES_PER_SECTOR, BYTES_PER_DIR);
      if (Dir.DIR_Name[0] == 0x00) break;
      if (Dir.DIR_Name[0] != 0xe5 && Dir.DIR_Attr == 0x20 && !strncmp(paths[pathDepth-1], Dir.DIR_Name, 11)) {
        findFlag = 1;
        sectorNum = FirstSectorofCluster + DirSecCnt - 1;
        offset = ((i - 1) * BYTES_PER_DIR) % BYTES_PER_SECTOR;
        break;
      }

      // 当前扇区的所有目录项已经读完。
      if (i % 16 == 0)
      {
        // 如果当前簇还有未读的扇区
        if (DirSecCnt < fat16_ins->Bpb.BPB_SecPerClus)
        {
          //将下一个扇区的数据读入sector_buffer
          sector_read(fat16_ins->fd, FirstSectorofCluster + DirSecCnt, sector_buffer);
          DirSecCnt++;
        }
        else // 当前簇已经读完，需要读取下一个簇的内容
        {
          // 已经到达最后一个簇
          if (FatClusEntryVal == 0xffff) break;
          first_sector_by_cluster(fat16_ins, FatClusEntryVal, &FatClusEntryVal, &FirstSectorofCluster, sector_buffer);
          DirSecCnt = 1;
        }
      }
    }
    /*** END ***/
  }

  /** TODO:
   * 删除文件，对相应entry做标记
   * 思考要修改entry中的哪些域
   * 注意目录项被删除时的标记为曾被使用但目前已删除
   * 和一个完全没用过的目录项的标记是不一样的
   **/

  /* Update file entry, change its first byte of file name to 0xe5 */
  if (findFlag == 1)
  {
    /*** BEGIN ***/
    const BYTE cpy = 0xe5;
    sector_read(fat16_ins->fd, sectorNum, sector_buffer);
    memcpy(sector_buffer + offset, &cpy, sizeof(BYTE));
    sector_write(fat16_ins->fd, sectorNum, sector_buffer);
    /*** END ***/
  }
  write_log(fat16_ins, " unlink-done\n");
  occupied = 0;
  return 0;
}

/**
 * @brief 修改path对应文件的时间戳，本次实验不做要求，可忽略该函数
 * 
 * @param path  要修改时间戳的文件路径
 * @param tv    时间戳
 * @return int 
 */
int fat16_utimens(const char *path, const struct timespec tv[2])
{
  return 0;
}

/**
 * @brief 创建path对应的文件夹
 * 
 * @param path 创建的文件夹路径
 * @param mode 文件模式，本次实验可忽略，默认都为普通文件夹
 * @return int 成功:0， 失败: POSIX错误代码的负值
 */
int fat16_mkdir(const char *path, mode_t mode) {
  /* Gets volume data supplied in the context during the fat16_init function */
  while(occupied);
  occupied = 1;
  FAT16 *fat16_ins = get_fat16_ins();
  write_log(fat16_ins, "mkdir path:");
  write_log(fat16_ins, path);

  int findFlag = 0;     // 是否找到空闲的目录项
  int sectorNum = 0;    // 找到的空闲目录项所在扇区号
  int offset = 0;       // 找到的空闲目录项在扇区中的偏移量
  /** TODO: 模仿mknod，计算出findFlag, sectorNum和offset的值
   *  你也可以选择不使用这些值，自己定义其它变量。注意本函数前半段和mknod前半段十分类似。
   **/
  /*** BEGIN ***/
  // 查找需要创建文件的父目录路径
  int pathDepth;
  char **paths = path_split((char *)path, &pathDepth);
  char *copyPath = strdup(path);
  const char **orgPaths = (const char **)org_path_split(copyPath);
  char *prtPath = get_prt_path(path, orgPaths, pathDepth);

  //查找可用的entry
  BYTE sector_buffer[BYTES_PER_SECTOR];
  int i, RootDirCnt = 1, DirSecCnt = 1;
  WORD ClusterN, FatClusEntryVal, FirstSectorofCluster;

  /* If parent directory is root */
  if (strcmp(prtPath, "/") == 0)
  {
    /**
     * 遍历根目录下的目录项
     * 如果发现有同名目录，则直接中断，findFlag=0
     * 找到可用的空闲目录项，即0x00位移处为0x00或者0xe5的项, findFlag=1
     * 并记录对应的sectorNum, offset等可能会用得到的信息
     **/
    DIR_ENTRY Root;
    sector_read(fat16_ins->fd, fat16_ins->FirstRootDirSecNum, sector_buffer);
    for (uint i = 1; i <= fat16_ins->Bpb.BPB_RootEntCnt; i++)
    {
      memcpy(&Root, sector_buffer + ((i - 1) * BYTES_PER_DIR) % BYTES_PER_SECTOR, BYTES_PER_DIR);
      if (Root.DIR_Name[0] == 0x00 || Root.DIR_Name[0] == 0xe5) {
        if (!findFlag) {
          sectorNum = fat16_ins->FirstRootDirSecNum + RootDirCnt - 1;
          offset = ((i - 1) * BYTES_PER_DIR) % BYTES_PER_SECTOR;
          findFlag = 1;
        }
      }
      else if (Root.DIR_Attr == 0x10 && !strncmp(paths[pathDepth-1], Root.DIR_Name, 11)) {
        findFlag = 0;
        break;
      }
      if (Root.DIR_Name[0] == 0x00) break;
      if (i % 16 == 0 && i != fat16_ins->Bpb.BPB_RootEntCnt)
      {
        sector_read(fat16_ins->fd, fat16_ins->FirstRootDirSecNum + RootDirCnt, sector_buffer);
        RootDirCnt++;
      }
    }
  }
  /* Else if parent directory is sub-directory */
  else
  {
    /**
     * 遍历子目录下的目录项
     * 如果发现有同名目录，则直接中断，findFlag=0
     * 找到可用的空闲目录项，即0x00位移处为0x00或者0xe5的项, findFlag=1
     * 并记录对应的sectorNum, offset等可能会用得到的信息
     * 注意跨扇区和跨簇的问题，不过写到这里你应该已经很熟了
     **/
    DIR_ENTRY Dir;
    off_t offset_dir;

    /* Finds the first corresponding directory entry in the root directory and
     * store the result in the directory entry Dir */
    find_root(fat16_ins, &Dir, prtPath, &offset_dir);

    /* Calculating the first cluster sector for the given path */

    ClusterN = Dir.DIR_FstClusLO; //目录项中存储了我们要读取的第一个簇的簇号
    first_sector_by_cluster(fat16_ins, ClusterN, &FatClusEntryVal, &FirstSectorofCluster, sector_buffer);

    /* Start searching the root's sub-directories starting from Dir */
    for (uint i = 1; Dir.DIR_Name[0] != 0x00; i++)
    {
      memcpy(&Dir, sector_buffer + ((i - 1) * BYTES_PER_DIR) % BYTES_PER_SECTOR, BYTES_PER_DIR);
      if (Dir.DIR_Name[0] == 0x00 || Dir.DIR_Name[0] == 0xe5) {
        findFlag = 1;
        sectorNum = FirstSectorofCluster + DirSecCnt - 1;
        offset = ((i - 1) * BYTES_PER_DIR) % BYTES_PER_SECTOR;
      }
      else if (Dir.DIR_Attr == 0x10 && !strncmp(paths[pathDepth-1], Dir.DIR_Name, 11)) {
        findFlag = 0;
        break;
      }
      if (Dir.DIR_Name[0] == 0x00) break;

      // 当前扇区的所有目录项已经读完。
      if (i % 16 == 0)
      {
        // 如果当前簇还有未读的扇区
        if (DirSecCnt < fat16_ins->Bpb.BPB_SecPerClus)
        {
          //将下一个扇区的数据读入sector_buffer
          sector_read(fat16_ins->fd, FirstSectorofCluster + DirSecCnt, sector_buffer);
          DirSecCnt++;
        }
        else // 当前簇已经读完，需要读取下一个簇的内容
        {
          // 已经到达最后一个簇
          if (FatClusEntryVal == 0xffff) break;
          first_sector_by_cluster(fat16_ins, FatClusEntryVal, &FatClusEntryVal, &FirstSectorofCluster, sector_buffer);
          DirSecCnt = 1;
        }
      }
    }
  }
  /*** END ***/

  /** TODO: 在父目录的目录项中添加新建的目录。
   *        同时，为新目录分配一个簇，并在这个簇中创建两个目录项，分别指向. 和 .. 。
   *        目录的文件大小设置为0即可。
   *  HINT: 使用正确参数调用dir_entry_create来创建上述三个目录项。
   **/
  if (findFlag == 1) {
    /*** BEGIN ***/
    ClusterN = alloc_clusters(fat16_ins, 1);
    dir_entry_create(fat16_ins, sectorNum, offset, paths[pathDepth-1], ATTR_DIRECTORY, ClusterN, BYTES_PER_SECTOR * fat16_ins->Bpb.BPB_SecPerClus);
    first_sector_by_cluster(fat16_ins, ClusterN, &FatClusEntryVal, &FirstSectorofCluster, sector_buffer);
    dir_entry_create(fat16_ins, FirstSectorofCluster, 0, ".          ", ATTR_DIRECTORY, 0xffff, 0);
    dir_entry_create(fat16_ins, FirstSectorofCluster, BYTES_PER_DIR, "..         ", ATTR_DIRECTORY, 0xffff, 0);
    /*** END ***/
  }
  write_log(fat16_ins, " mkdir-done\n");
  occupied = 0;
  return 0;
}

/**
 * @brief 删除path对应的文件夹
 * 
 * @param path 要删除的文件夹路径
 * @return int 成功:0， 失败: POSIX错误代码的负值
 */
int fat16_rmdir(const char *path) {
  /* Gets volume data supplied in the context during the fat16_init function */
  while(occupied);
  occupied = 1;
  FAT16 *fat16_ins = get_fat16_ins();
  write_log(fat16_ins, "rmdir path:");
  write_log(fat16_ins, path);

  if(strcmp(path, "/") == 0) {
    write_log(fat16_ins, " rmdir-done\n");
    occupied = 0;
    return -EBUSY;  // 无法删除根目录，根目录是挂载点（可参考`man 2 rmdir`）
  }

  DIR_ENTRY Dir;
  DIR_ENTRY curDir;
  off_t offset;
  int res = find_root(fat16_ins, &Dir, path, &offset);

  if(res != 0) {
    write_log(fat16_ins, " rmdir-done\n");
    occupied = 0;
    return -ENOENT; // 路径不存在
  }

  if(Dir.DIR_Attr != ATTR_DIRECTORY) {
    write_log(fat16_ins, " rmdir-done\n");
    occupied = 0;
    return ENOTDIR; // 路径不是目录
  }

  /** TODO: 检查目录是否为空，如果目录不为空，直接返回-ENOTEMPTY。
   *        注意空目录也可能有"."和".."两个子目录。
   *  HINT: 这一段和readdir的非根目录部分十分类似。
   *  HINT: 注意忽略DIR_Attr为0x0F的长文件名项(LFN)。
   **/

  /*** BEGIN ***/
    BYTE sector_buffer[BYTES_PER_SECTOR];
    WORD ClusterN, FirstCluster;              // 当前读取的簇号
    WORD FatClusEntryVal;       // 该簇的FAT表项（大部分情况下，代表下一个簇的簇号，请参考实验文档对FAT表项的说明）
    WORD FirstSectorofCluster;  // 该簇的第一个扇区号
    int DirSecCnt = 1;

    FirstCluster = ClusterN = Dir.DIR_FstClusLO; //目录项中存储了我们要读取的第一个簇的簇号
    first_sector_by_cluster(fat16_ins, ClusterN, &FatClusEntryVal, &FirstSectorofCluster, sector_buffer);

    /* Start searching the root's sub-directories starting from Dir */
    for (uint i = 1; Dir.DIR_Name[0] != 0x00; i++)
    {
      memcpy(&Dir, sector_buffer + ((i - 1) * BYTES_PER_DIR) % BYTES_PER_SECTOR, BYTES_PER_DIR);
      if (Dir.DIR_Name[0] == 0x00) break;
      if (Dir.DIR_Name[0] != 0xe5 && Dir.DIR_Attr != 0x0f)
        if(strncmp(Dir.DIR_Name, ".          ", 11) && strncmp(Dir.DIR_Name, "..         ", 11)) {
          write_log(fat16_ins, " rmdir-done\n");
          occupied = 0;
          return -ENOTEMPTY;
        }
      // 当前扇区的所有目录项已经读完。
      if (i % 16 == 0)
      {
        // 如果当前簇还有未读的扇区
        if (DirSecCnt < fat16_ins->Bpb.BPB_SecPerClus)
        {
          // 将下一个扇区的数据读入sector_buffer
          sector_read(fat16_ins->fd, FirstSectorofCluster + DirSecCnt, sector_buffer);
          DirSecCnt++;
        }
        else // 当前簇已经读完，需要读取下一个簇的内容
        {
          // 已经到达最后一个簇
          if (FatClusEntryVal == 0xffff) break;
          // 读取下一个簇（即簇号为FatClusEntryVal的簇）的第一个扇区
          first_sector_by_cluster(fat16_ins, FatClusEntryVal, &FatClusEntryVal, &FirstSectorofCluster, sector_buffer);
          DirSecCnt = 1;
        }
      }
    }
  /*** END ***/

  // 已确认目录项为空，释放目录占用的簇
  // TODO: 循环调用free_cluster释放对应簇，和unlink类似。
  /*** BEGIN ***/
  while (FirstCluster != 0xffff) FirstCluster = free_cluster(fat16_ins, FirstCluster);
  /*** END ***/

  // TODO: 删除父目录中的目录项
  // HINT: 如果你正确实现了dir_entry_delete，这里只需要一行代码调用它即可
  //       你也可以使用你在unlink使用的方法。
  /*** BEGIN ***/
  dir_entry_delete(fat16_ins, offset);
  /*** END ***/
  write_log(fat16_ins, " rmdir-done\n");
  occupied = 0;
  return 0;
}

/**
 * @brief 将长度为size的数据data写入path对应的文件的offset位置。注意当写入数据量超过文件本身大小时，
 *        需要扩展文件的大小，必要时需要分配新的簇。
 * 
 * @param path    要写入的文件的路径
 * @param data    要写入的数据
 * @param size    要写入数据的长度
 * @param offset  文件中要写入数据的偏移量（字节）
 * @param fi      本次实验可忽略该参数
 * @return int    成功返回写入的字节数，失败返回POSIX错误代码的负值。
 */
int fat16_write(const char *path, const char *data, size_t size, off_t offset,
                struct fuse_file_info *fi)
{
  while(occupied);
  occupied = 1;
  FAT16 *fat16_ins = get_fat16_ins();
  write_log(fat16_ins, "write path:");
  write_log(fat16_ins, path);
  write_log(fat16_ins, " data:");
  write_log(fat16_ins, data);
  write_log(fat16_ins, " size:");
  char str[15];
  snprintf(str, 15, "%ld", size);
  write_log(fat16_ins, str);
  write_log(fat16_ins, " offset:");
  snprintf(str, 15, "%ld", offset);
  write_log(fat16_ins, str);

  /** TODO: 大部分工作都在write_file里完成了，这里调用find_root获得目录项，然后调用write_file即可
   */
  DIR_ENTRY Dir;
  off_t offset_dir;
  find_root(fat16_ins, &Dir, path, &offset_dir);
  int ret = write_file(fat16_ins, &Dir, offset_dir, data, offset, size);
  write_log(fat16_ins, " write-done\n");
  occupied = 0;
  return ret;
}

/**
 * @brief 将path对应的文件大小改为size，注意size可以大于小于或等于原文件大小。
 *        若size大于原文件大小，需要将拓展的部分全部置为0，如有需要，需要分配新簇。
 *        若size小于原文件大小，将从末尾截断文件，若有簇不再被使用，应该释放对应的簇。
 *        若size等于原文件大小，什么都不需要做。
 * 
 * @param path 需要更改大小的文件路径 
 * @param size 新的文件大小
 * @return int 成功返回0，失败返回POSIX错误代码的负值。
 */
int fat16_truncate(const char *path, off_t size)
{
  /* Gets volume data supplied in the context during the fat16_init function */
  while(occupied);
  occupied = 1;
  FAT16 *fat16_ins = get_fat16_ins();
  write_log(fat16_ins, "truncate path:");
  write_log(fat16_ins, path);
  write_log(fat16_ins, " size:");
  char str[15];
  snprintf(str, 15, "%ld", size);
  write_log(fat16_ins, str);

  /* Searches for the given path */
  DIR_ENTRY Dir;
  off_t offset_dir;
  find_root(fat16_ins, &Dir, path, &offset_dir);

  // 当前文件已有簇的数量，以及截断或增长后，文件所需的簇数量。
  int64_t cur_cluster_count;
  WORD last_cluster = file_last_cluster(fat16_ins, &Dir, &cur_cluster_count);
  int64_t new_cluster_count = (size + fat16_ins->ClusterSize - 1) / fat16_ins->ClusterSize;

  DWORD new_size = size;
  DWORD old_size = Dir.DIR_FileSize;

  if (old_size == new_size){
    
  } else if (old_size < new_size) {
    /** TODO: 增大文件大小，注意是否需要分配新簇，以及往新分配的空间填充0等 **/
    /*** BEGIN ***/
    if (new_cluster_count > cur_cluster_count)
      file_new_cluster(fat16_ins, &Dir, last_cluster, new_cluster_count - cur_cluster_count);
    size_t realoffset = old_size % fat16_ins->ClusterSize;
    size_t realsize = fat16_ins->ClusterSize - realoffset;
    BYTE temp[realsize];
    for (int i = 0; i < realsize; i++) temp[i] = 0x00;
    write_to_cluster_at_offset(fat16_ins, last_cluster, realoffset, temp, realsize);
    Dir.DIR_FileSize = size;
    dir_entry_write(fat16_ins, offset_dir, &Dir);
    /*** END ***/

  } else {  // 截断文件
      /** TODO: 截断文件，注意是否需要释放簇等 **/
      /*** BEGIN ***/
      WORD ClusterN = Dir.DIR_FstClusLO;
      WORD FatClusterEntry;
      FatClusterEntry = fat_entry_by_cluster(fat16_ins, ClusterN);
      for (int i = 0; i < new_cluster_count; i++) {
        ClusterN = FatClusterEntry;
        FatClusterEntry = fat_entry_by_cluster(fat16_ins, ClusterN);
      }
      write_fat_entry(fat16_ins, ClusterN, 0xffff);
      while (FatClusterEntry != 0xffff) {
        ClusterN = FatClusterEntry;
        FatClusterEntry = fat_entry_by_cluster(fat16_ins, ClusterN);
        free_cluster(fat16_ins, ClusterN);
      }
      Dir.DIR_FileSize = size;
      dir_entry_write(fat16_ins, offset_dir, &Dir);
      /*** END ***/
  }
  write_log(fat16_ins, " truncate-done\n");
  occupied = 0;
  return 0;
}

struct fuse_operations fat16_oper = {
    .init = fat16_init,
    .destroy = fat16_destroy,
    .getattr = fat16_getattr,

    // TASK1: tree [dir] / ls [dir] ; cat [file] / tail [file] / head [file]
    .readdir = fat16_readdir,
    .read = fat16_read,

    // TASK2: touch [file]; rm [file]
    .mknod = fat16_mknod,
    .unlink = fat16_unlink,
    .utimens = fat16_utimens,

    // TASK3: mkdir [dir] ; rm -r [dir]
    .mkdir = fat16_mkdir,
    .rmdir = fat16_rmdir,

    // TASK4: echo "hello world!" > [file] ;  echo "hello world!" >> [file]
    .write = fat16_write,
    .truncate = fat16_truncate
    };

int main(int argc, char *argv[])
{
  int ret;

  /* Starting a pre-initialization of the FAT16 volume */
  fd_copy1 = fopen(FAT_FILE_COPY1_NAME, "rb+");
  fd_copy2 = fopen(FAT_FILE_COPY2_NAME, "rb+");
  FAT16 *fat16_ins = pre_init_fat16(FAT_FILE_NAME);
  
  ret = fuse_main(argc, argv, &fat16_oper, fat16_ins);

  return ret;
}
