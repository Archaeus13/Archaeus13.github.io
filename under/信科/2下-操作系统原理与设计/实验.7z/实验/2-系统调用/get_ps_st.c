#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include<sys/syscall.h>

SYSCALL_DEFINE2(exectime, int __user *, pids, unsigned long __user *, time) {
    struct task_struct* task;
    int counter = 0, pid;
    unsigned long temptime;
    printk("[Syscall] exectime\n");
    for_each_process(task) {
    	pid = (int) task->pid;
    	temptime = (unsigned long) task->se.sum_exec_runtime;
    	if(copy_to_user(pids+counter, &pid, sizeof(int))) return -EFAULT;
    	if(copy_to_user(time+counter, &temptime, sizeof(long))) return -EFAULT;
    	counter++;
    }
    pid = -1;
    if(copy_to_user(pids+counter, &pid, sizeof(int))) return -EFAULT;
    return 0;
}

SYSCALL_DEFINE6(ps_st, int __user *, in_pids, unsigned long __user *, before_time,
	int __user *, pids, int __user *, cond,
	char __user *, name, unsigned long __user *, useage) {
    struct task_struct* task;
    int i, j, k, pid_temp, in_pid_temp = 0, counter = 0;
    int pids_k[20];
    int cond_k[20];
    char name_k[320];
    unsigned long useage_k[20];
    unsigned long temp;
    for (i = 0; i < 20; i++) useage_k[i] = 0;
    printk("[Syscall] ps_st\n");
    for_each_process(task) {
    	pid_temp = (int) task->pid;
    	while (pid_temp > in_pid_temp && in_pid_temp != -1) {
    	    if(copy_from_user(&in_pid_temp, in_pids+counter, sizeof(int))) return -EFAULT;
    	    counter++;
    	}
    	if (pid_temp == in_pid_temp) {
    	    if(copy_from_user(&temp, before_time+counter-1, sizeof(long))) return -EFAULT;
    	    temp = task->se.sum_exec_runtime - temp;
    	    for (i = 0; i < 20; i++) if (temp >= useage_k[i]) {
    	    	for (j = 19; j > i; j--) {
    	    	    pids_k[j] = pids_k[j-1];
    	    	    cond_k[j] = cond_k[j-1];
    	    	    useage_k[j] = useage_k[j-1];
    	            for (k = 0; k < 16; k++) name_k[16*j+k] = name_k[16*(j-1)+k];
    	    	}
    	    	pids_k[i] = pid_temp;
    	    	cond_k[i] = (int) task->state;
    	    	useage_k[i] = temp;
    	    	for (k = 0; k < 16; k++) name_k[16*i+k] = task->comm[k];
    	    	i = 19;
    	    }
    	}
    }
    if(copy_to_user(pids, pids_k, 20*sizeof(int))) return -EFAULT;
    if(copy_to_user(cond, cond_k, 20*sizeof(int))) return -EFAULT;
    if(copy_to_user(name, name_k, 320*sizeof(char))) return -EFAULT;
    if(copy_to_user(useage, useage_k, 20*sizeof(long))) return -EFAULT;
    return 0;
};

int main(void) {
    int in_pids[400];
    unsigned long before_time[400]; 
    int pids[20];
    int cond[20];
    char name[320];
    char aname[16];
    unsigned long useage[20];
    while (1) {
    	syscall(332, in_pids, before_time);
    	sleep(1);
    	system("clear");
    	syscall(333, in_pids, before_time, pids, cond, name, useage);
    	printf("PID      COND     NAME             USEAGSE\n");
    	for (int i = 0; i < 20; i++) {
    	    for (int k = 0; k < 16; k++) aname[k] = name[16*i+k];
    	    printf("%-8d %-8d %-16s %-3.2f%%\n", pids[i], cond[i], aname, (float)useage[i]/10000000);
    	}
    }
    return 0;
}
