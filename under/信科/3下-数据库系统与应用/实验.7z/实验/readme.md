* 数据库系统与应用 大作业
* 作者：郑滕飞、梁睿涓

# ER图
<img src=".\static\ER.png" style="zoom: 50%;" />

# 使用方法：

app.py目录下：
set FLASK_APP = app.py
flask run

