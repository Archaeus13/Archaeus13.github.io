//������
#include <stdio.h>
#include <math.h>

void main(void)
{
	register short i;
	short a, n;
	int s = 0;
	printf("a=");
	scanf("%hd", &a);
	printf("n=");
	scanf("%hd", &n);
	for (i = 1; i <= n; i++) s += pow(10, i - 1) * (n + 1 - i);
	s *= a;
	printf("s=%d", s);
} 
