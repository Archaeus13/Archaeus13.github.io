//�������
#include <stdio.h>

int num[10];
char name[10][10];

void input(void)
{
	register int i;
	for (i = 0; i < 10; i++) {
		printf("%d number:", i + 1);
		scanf("%d", &num[i]);
		printf("%d name:", i + 1);
		scanf("%s", name[i]);
	}
}

void arrange(int a[], char b[][10])
{
	register int t, i, j, k, m;
	char c;
	for (i = 0; i <= 8; i++) {
		m = i;
		for (j = i + 1; j <= 9; j++) if (a[j] < a[m]) m = j;
		t = a[i];
		a[i] = a[m];
		a[m] = t;
		for (k = 0; k < 10; k++) {
			c = b[i][k];
			b[i][k] = b[m][k];
			b[m][k] = c;
		}
	} 
}

void check(int a[], char b[][10], int n)
{
	register int t = 4, r = 3, i;
	for (i = 0; i < 3; i++) {
		if (a[t] != n) {
			if (a[t] > n) t -= r;
			else t += r;
			if(t == -1) t = 0;
			r -= 1;
		}
    	else {
    		printf("num:%d\nname:%s", a[t], b[t]);
    		return;
		}
    }
    printf("ERROR\n");
    return;
}

void main(void)
{
	int i, n;
	input();
	arrange(num, name);
	printf("\n");
	for(i = 0; i < 10; i++) printf("%d, %s\n", num[i], name[i]);
	printf("\n");
	printf("n=");
	scanf("%d", &n);
	check(num, name, n);
}	
