//�Ի�
#include <stdio.h>

void input(int a[])
{
	register int i;
	for(i = 0; i < 10; i++) {
		printf("a[%d]=", i);
		scanf("%d", &a[i]);
	}
}

void output(int a[])
{
	register int i;
	for(i = 0; i < 10; i++) printf("%d ", a[i]);
}

void exchange(int a[])
{
	int* p;
	register int t, i;
	p = a;
	for (i = 0; i < 10; i++) if (*p > a[i]) p = &a[i];
	t = *p;
	*p = a[0];
	a[0] = t;
	for (i = 0; i < 10; i++) if (*p < a[i]) p = &a[i];
	t = *p;
	*p = a[9];
	a[9] = t;
}

void main(void)
{
	int a[10];
	input(a);
	exchange(a);
	output(a);
}
