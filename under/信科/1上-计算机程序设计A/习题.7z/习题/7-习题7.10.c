//�����
#include <stdio.h>

void longest(char a[])
{
	short i, length = 0, start = 0, ml = 0, ms;
	for (i = 0; a[i] != '\0'; i++) {
		if (a[i] != ' ') length++;
		else {
		length = 0;
		start = i + 1;
		}
		if (length > ml) {
			ml = length;
			ms = start;
		}
	}
	for (i = ms; i <= ms + ml; i++) printf("%c", a[i]);
}

void main(void)
{
	char a[100];
	scanf("%[^\n]", a);
	longest(a);
}
