//��ӡȫ���� 
#include <stdio.h>
#include <stdbool.h> 
#define N 1000
 
int n;
int a[N];
bool judge[N];

void array(int w){
	int i;
	if (w == n + 1) {
		for(i = 1; i <= n; i++) printf("%d ", a[i]);
	    printf("\n");
	    return;
	}
	else for (i = 1; i <= n; i++) if (judge[i]) {
			a[w] = i;
			judge[i] = 0;
			array(w + 1);
			judge[i] = 1;
	}
}

void main(void){
	printf("n=", &n);
	scanf("%d", &n);
	int i;
	for (i = 1; i <= n; i++) judge[i] = 1;
	array(1);
}
