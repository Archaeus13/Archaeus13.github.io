//��ȫ��
#include <stdio.h>

void main(void)
{
	register int i, j; 
	int t, s, a[50];
	for (i = 1; i <= 1000; i++) {
		s = 0;
		t = 0;
		for (j = 1; j < i; j++) {
			if (!(i % j)) {
				a[t] = j;
				t++;
			}
		}
		for (j = 0; j < t; j++) s += a[j];
		if (s == i) {
			printf("%d its factors are 1", i);
			for (j = 1; j < t; j++) printf(",%d", a[j]);
			printf("\n");
		}
	}
} 
