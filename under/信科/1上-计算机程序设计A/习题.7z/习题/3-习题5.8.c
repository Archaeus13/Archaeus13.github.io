//���ˮ�ɻ���
#include  <stdio.h>

void main(void)
{
	register int i, r[3];
	for (i = 100; i <= 999; i++) {
		r[2] = i / 100;
		r[1] = i / 10 - r[2] * 10;
		r[0] = i - r[2] * 100 - r[1] * 10;
		if (i == r[0] * r[0] * r[0] + r[1] * r[1] * r[1] + r[2] * r[2] * r[2]) printf("%d\n", i);
	}
} 
