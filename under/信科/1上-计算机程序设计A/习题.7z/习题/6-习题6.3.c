//����Խ��ߺ�
#include <stdio.h>

void main(void)
{
	short a[3][3];
	register short i, j, s = 0;
	for (i = 0; i <= 2; i++) {
		for (j = 0; j <= 2; j++) {
			printf("��%d�е�%d���ǣ�", i + 1, j + 1);
			scanf("%d", &a[i][j]);
			if ((i == j) || (i + j == 2)) s += a[i][j];
	    }
    }
    printf("s=%d\n", s);
}
