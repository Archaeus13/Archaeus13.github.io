//��������
#include <stdio.h>

void change(int a[], int m, int n)
{
	int* p = &a[n-1];
	register i;
	for (i = 0; i < n; i++){
		*(p + m) = *p;
		p--;
	}
	p = &a[n];
	for (i = 0; i < m; i++){
		*(p - n) = *p;
		p++;
	}
}

void main(void)
{
	register i;
	int a[20], m, n, *p = a;
	printf("n=");
	scanf("%d", &n);
	printf("m=");
	scanf("%d", &m);
	for (i = 0; i < n; i++) {
		printf("a[%d]=", i);
		scanf("%d", p);
		p++;
	}
	change(a, m, n);
	for (i = 0; i < n; i++) printf("%d ", a[i]);
}
