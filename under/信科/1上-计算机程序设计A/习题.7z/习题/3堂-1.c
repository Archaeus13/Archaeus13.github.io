//�����������
#include <stdio.h>

void main(void)
{
	register int i, j;
	for (i = 1; i <= 5; i++) {
		for (j = 1; j <= i - 1; j++) printf("%2c", ' ');
		for (j = 1; j <= 11 - 2 * i; j++) printf("%2c", '*');
		printf("\n");
	}
} 
