//���ַ��ƽ�
#include <stdio.h>

void main(void)
{
	register int i;
	double a = -10.0, b = 10.0, c;
	double f(double x);
	for (i = 1; i <= 100; i++) {
	    c = (a + b) / 2.0;
	    if (f(a) * f(c) > 0) a = c;
	    else b = c;
	}
	printf("���ƽ�Ϊ %.6lf" ,c);
}

double f(double x)
{
	double t;
	t = 2.0*x*x*x - 4.0*x*x + 3.0*x - 6.0;
	return t;
}
