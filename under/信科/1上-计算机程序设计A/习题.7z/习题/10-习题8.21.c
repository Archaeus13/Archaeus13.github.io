//����++
#include <stdio.h>

void arrange(int n, int *p)
{
	int i, j, t, *q = p, *r = p;
	for (i = 1; i < n; i++) {
		for (j = i; j < n; j++) {
			q++;
		    if (*q < *p) p = q;
		}
		t = *r;
		*r = *p;
		*p = t;
		r++;
		p = q = r;
	}
}

int input(int *p)
{
	int i = 0;
	puts("input intergers, 0 to end:");
	scanf("%d", p);
	while(*p) {
		p++;
		i++;
		scanf("%d", p);
	}
	return i;
}

void main(void)
{
	int a[100], t, i, *p = a;
	t = input(p);
	p = a; 
	arrange(t, p);
	for (i = 0; i < t; i++) printf("%d ", a[i]);
}
