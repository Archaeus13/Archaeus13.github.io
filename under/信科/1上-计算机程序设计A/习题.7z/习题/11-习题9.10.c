//����
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#define N sizeof(struct Student)

typedef struct Student {
	int num;
	char name[5];
	struct Student* next;
}stu;

typedef struct Data {
	int num;
	char name[5];
}dat;

stu* create(int n, dat a[])
{
    int i;
    stu *head, *p;
    p = head = malloc(N);
	for (i = 0; i < n; i++) {
		p->next = malloc(N);
		p = p->next;
		p->num = a[i].num;
		strcpy(p->name, a[i].name);
	}
	p->next = NULL;
	return head;
}

void arrange(int n, dat* p)
{
	int i, j;
	dat t, *q = p, *r = p;
	for (i = 1; i < n; i++) {
		for (j = i; j < n; j++) {
			q++;
		    if (q->num < p->num) p = q;
		}
		t = *r;
		*r = *p;
		*p = t;
		r++;
		p = q = r;
	}
}

void print(stu* p)
{
	while(p->next != NULL) {
	    p = p->next;
		printf("%d %s\n", p->num, p->name);	
	}
}

void main(void)
{
	int i;
	stu *ha, *hb, *pa, *pb, *h;
	dat a[5], b[5], m[10];
	a[0].num = 9;
	strcpy(a[0].name, "Ra");
	a[1].num = 7;
	strcpy(a[1].name, "Se");
	a[2].num = 5;
	strcpy(a[2].name, "Ti");
	a[3].num = 3;
	strcpy(a[3].name, "Ju");
	a[4].num = 1;
	strcpy(a[4].name, "Ko");
	b[0].num = 0;
	strcpy(b[0].name, "Ya");
	b[1].num = 2;
	strcpy(b[1].name, "Re");
	b[2].num = 4;
	strcpy(b[2].name, "Mi");
	b[3].num = 6;
	strcpy(b[3].name, "Wu");
	b[4].num = 8;
	strcpy(b[4].name, "Po");
	pa = create(5, a);
	pb = create(5, b);
	for (i = 0; i < 5; i++) {
		ha = pa;
		pa = pa->next;
		free(ha);
		m[i].num = pa->num;
		strcpy(m[i].name, pa->name);
	}
	for (i = 5; i < 10; i++) {
		hb = pb;
		pb = pb->next;
		free(hb);
		m[i].num = pb->num;
		strcpy(m[i].name, pb->name);
	}
	arrange(10, m);
	h = create(10, m);
	print(h);
}


