//���� 
#include <stdio.h>

struct Date{
	long year;
	int month;
	int day;
};

int run(struct Date x)
{
	if (x.year % 4) return 0;
	if (x.year % 100) return 1;
	if (x.year % 400) return 0;
	return 1;
}

int count(struct Date x)
{
	register int i, s = 0;
	int a[11] = {31,28,31,30,31,30,31,31,30,31,30};
	for (i = 0; i < x.month - 1; i++) s += a[i];
	if (x.month < 3) return s+x.day;
	return s+x.day+run(x);
}

void main(void)
{
	struct Date x;
	printf("yyyy,mm,dd=");
	scanf("%ld,%d,%d", &x.year, &x.month, &x.day);
	printf("%d", count(x));
}
