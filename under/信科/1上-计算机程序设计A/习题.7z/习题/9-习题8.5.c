//�����˳� 
#include <stdio.h>
#include <stdbool.h>

int count(int n)
{
	bool a[n+1];
	register i, t = 0;
	bool *p = &a[n-1];
	for (i = 0; i < n; i++) a[i] = 1;
	for (i = 1; i < n; i++) {
		while (t < 3) {
			p++;
			if (p == &a[n]) p = a;
			if (*p) t++;
		}
		t = 0;
		*p = 0;
	}
	for (i = 0; i <= n; i++) if (a[i]) return i + 1;
}

void main(void)
{
	int n;
	printf("n=");
	scanf("%d", &n);
	printf("result:%d\n", count(n));
}
