//���Լ������С������
#include <stdio.h>

int main(void)
{
	unsigned int a, b, c, d;
	printf("a=");
	scanf("%d", &a);
	printf("b=");
	scanf("%d", &b);
	if (b > a) {
	    c = b;
		d = a;
	}
	else {
		c = a;
		d = b;
	}
	for( ; ; ) {
		c = c % d;
		if (!c) break;
		c += d;
		d = c - d;
		c -= d;
	}
	c = a * b / d;
	printf("gcd = %d\n", d);
	printf("lcm = %d\n", c);
    return 0; 
} 


