//�ɼ���
#include <stdio.h>
#define N 10

struct Grade {
    long num;
	char name[10];
	int score[3];
	int sum;	
};

void input(struct Grade stu[])
{
	int i;
	for (i = 0; i < N; i++) {
		printf("%d\n", i+1);
		printf("Number:");
		scanf("%d", &stu[i].num);
		printf("Name:");
		scanf("%s", stu[i].name);
		printf("Score1:");
		scanf("%d", &stu[i].score[0]);
		printf("Score2:");
		scanf("%d", &stu[i].score[1]);
		printf("Score3:");
		scanf("%d", &stu[i].score[2]);
		stu[i].sum = stu[i].score[0] + stu[i].score[1] + stu[i].score[2];
	}
}

float average(struct Grade stu[])
{
	int i;
	float s = 0;
	for (i = 0; i < N; i++) s += stu[i].sum;
	return s /= 30.0;
}

int max(struct Grade stu[])
{
	int i, t = 0;
	for (i = 1; i < N; i++) if (stu[i].sum > stu[t].sum) t = i;
	return t;
}

void main(void)
{
	struct Grade stu[N];
	int t;
	input(stu);
	printf("\nAverage:%.2f\n", average(stu));
	t = max(stu);
	printf("%d %s %d %d %d %.2f", stu[t].num, stu[t].name, stu[t].score[0], stu[t].score[1], stu[t].score[2], (float) stu[t].sum / 3.0);
}
