//����
#include <stdio.h>

int find(char a[], char b, char c)
{
	register i, t = 0;	
	char *p = a;
	for (i = 0; i < 100; i++) {
		if (*p >= b && *p <= c) t++;
		p++; 
	}
	return t;
}

int count(char a[])
{
	register i, t = 0;	
	char *p = a;
	for (i = 0; i < 100; i++) {
		t++;
		*p++;
		if (!*p) return t;
	}
}

void main(void)
{
	char a[100];
	int n[6];
	scanf("%[^\n]", a);
	n[0] = count(a);
	n[1] = find(a, 'A', 'Z');
	n[2] = find(a, 'a', 'z');
	n[3] = find(a, ' ', ' ');
	n[4] = find(a, '0', '9');
	n[5] = n[0] - n[1] - n[2] - n[3] - n[4];
	printf("��д:%d\nСд:%d\n�ո�:%d\n����:%d\n����:%d\n", n[1], n[2], n[3], n[4], n[5]);
}
