//������ƽ����
#include <stdio.h>

void main(void)
{
	double a, x;
	printf("a=");
	scanf("%lf", &a);
	x = a;
	for (; ;) {
		x = (x * x + a) / 2.0 / x;
		if (x * x - a < 1e-6) break; 
	}
	printf("sqrt(a)=%.6lf", x);
} 
