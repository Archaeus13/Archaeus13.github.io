//���
#include <stdio.h>

void main(void)
{
	register short i, j;
	int n, s = 0;
	printf("n=");
	scanf("%d", &n);
	for (i = 1; i <= n; i++) for (j = 1; j <= i; j++) s += j;
	printf("s=%d", s);
} 
