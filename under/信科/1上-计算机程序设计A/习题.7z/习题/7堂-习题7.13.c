//���õ¶���ʽ
#include <stdio.h>

double Legendre(double x, int n)
{
	if (!n) return 1;
	if (n == 1) return x;
	return (2*n-1) * x - Legendre(x, n-1) - (n-1) * Legendre(x, n-2) / n;
}

void main(void)
{
	double x;
	int n;
	printf("x=");
	scanf("%lf", &x);
	printf("n=");
	scanf("%d", &n);
	printf("result=%.5lf", Legendre(x, n));
}
