//���� 
#include <stdio.h>

int run(long t)
{
	if (t % 4) return 0;
	if (t % 100) return 1;
	if (t % 400) return 0;
	return 1;
}

int count(long y, int m, int d)
{
	register int i, s = 0;
	int a[11] = {31,28,31,30,31,30,31,31,30,31,30};
	for (i = 0; i < m - 1; i++) s += a[i];
	if (m < 3) return s+d;
	return s+d+run(y);
}

void main(void)
{
	long y;
	int m, d;
	printf("yyyy,mm,dd=");
	scanf("%ld,%d,%d", &y, &m, &d);
	printf("%d", count(y,m,d));
}
