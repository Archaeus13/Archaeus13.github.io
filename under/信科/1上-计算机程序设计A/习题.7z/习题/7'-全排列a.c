//��ӡȫ����
#include <stdio.h>

int a[6] = {0,0,0,0,0,0};
int s, k = 0;

void arr(int n)
{
	int i, t, c = 1;
	if (n) for (i = 0; i < n; i++) { //��0 
		for (t = 0; t < s; t++) if (!a[t]) if (c++ > i) { //���� 
			a[t] = n;
		    t = s;
		    c = 1;
		}
		arr(n - 1); //�ݹ� 
	}
	else {
		k++;
		printf("No.%-3d ", k); //��ӡ 
		for (i = 0; i < s; i++) printf("%d ", s + 1 - a[i]);
		printf("\n");
		t = k;
		while (!(t % c)) { //���� 
			t /= c;
			c++;
		}
		for (i = 0; i < s; i++) if (a[i] <= c) a[i] = 0;
	}
}

void main(void)
{   
	printf("s=");
	scanf("%d", &s);
	arr(s);
}
