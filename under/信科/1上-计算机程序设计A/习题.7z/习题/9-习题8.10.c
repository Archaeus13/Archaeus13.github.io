//����任
#include <stdio.h>

void change(int a[][5])
{
	int b[5] = {0, 100, 100, 100, 100};
	register i, j;
	int *p = a;
	for (i = 0; i < 25; i++) {
	    if (*p > b[0]) b[0] = *p;
		if (*p < b[1]) b[1] = *p;
		p++;
	}
	for (j = 2; j < 5; j++) {
		p = a;
		for (i = 0; i < 25; i++) {
			if (*p < b[j] && *p > b[j-1]) b[j] = *p;
			p++;
		}
	}
	a[2][2] = b[0];
	a[0][0] = b[1];
	a[0][4] = b[2];
	a[4][0] = b[3];
	a[4][4] = b[4];
}

void main(void)
{
	int a[5][5] = {{5,4,3,2,1},{10,9,8,7,6},{15,14,13,12,11},{20,19,18,17,16},{25,24,23,22,21}};
	register i, j;
	for (i = 0; i < 5; i++) {
		for (j = 0; j < 5; j++) printf("%-3d", a[i][j]);
		printf("\n");
	} 
	change(a);
	for (i = 0; i < 5; i++) {
		for (j = 0; j < 5; j++) printf("%-3d", a[i][j]);
		printf("\n");
	}
}
