//�ַ�������
#include <stdio.h>
#include <string.h>

void compare(char *p[10])
{
	register i, j, m;
	char *c;
	for (i = 0; i <= 8; i++) {
		m = i;
		for (j = i + 1; j <= 9; j++) if (strcmp(p[j], p[m]) < 0) m = j;
		c = p[i];
		p[i] = p[m];
		p[m] = c;
	}
}

void main(void)
{
	char c[10][10];
	char *p[10];
	register i;
	for (i = 0; i < 10; i++) p[i] = c[i];
	for (i = 0; i < 10; i++) {
		printf("%d:", i + 1);
		scanf("%s", c[i]);
	}
	compare(p);
	for (i = 0; i < 10; i++) printf("%d:%s\n", i + 1, p[i]);
}
