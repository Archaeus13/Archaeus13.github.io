#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#define N sizeof(struct Student)

typedef struct Student {
	int num;
	char name[5];
	struct Student* next;
}stu;

typedef struct Data {
	int num;
	char name[5];
}dat;

stu* create(int n, dat a[])
{
    int i;
    stu *head, *p;
    p = head = malloc(N);
	for (i = 0; i < n; i++) {
		p->next = malloc(N);
		p = p->next;
		p->num = a[i].num;
		strcpy(p->name, a[i].name);
	}
	p->next = NULL;
	return head;
}

stu* del(stu* p, int n)
{
	int i;
	stu *p0, *pt;
	pt = p;
	for (i = 0; i < n - 1; i++) p = p->next;
	p0 = p;
	p = p->next;
	p0->next = p->next;
	free(p);
	return pt;
}

stu* delc(stu* p1, stu* p2) {
	int i = 1;
	stu *h1 = p1;
	stu *h2 = p2;
	while(p1->next) {
		p1 = p1->next;
		i++;
		p2 = h2;
		while(p2->next) {
			p2 = p2->next;
			if (p1->num == p2->num) {
				p1 = h1 = del(h1, i);
				i = 0;
	    	    break;
			}
		}
	}
	return h1;
}

void print(stu* p)
{
	while(p->next != NULL) {
	    p = p->next;
		printf("%d %s\n", p->num, p->name);	
	}
	puts("");
}

void main(void)
{
	int i;
	stu *ha, *hb;
	dat a[5], b[5], m[10];
	a[0].num = 9;
	strcpy(a[0].name, "Ra");
	a[1].num = 7;
	strcpy(a[1].name, "Se");
	a[2].num = 5;
	strcpy(a[2].name, "Ti");
	a[3].num = 3;
	strcpy(a[3].name, "Ju");
	a[4].num = 1;
	strcpy(a[4].name, "Ko");
	b[0].num = 0;
	strcpy(b[0].name, "Ya");
	b[1].num = 3;
	strcpy(b[1].name, "Re");
	b[2].num = 4;
	strcpy(b[2].name, "Mi");
	b[3].num = 5;
	strcpy(b[3].name, "Wu");
	b[4].num = 0;
	strcpy(b[4].name, "Po");
	ha = create(5, a);
	hb = create(5, b);
	ha = delc(ha, hb);
	print(ha);
}
