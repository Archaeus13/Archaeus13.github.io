//��ҵ����
#include <stdio.h>

void main(void)
{
	float count(float a, int b, int c, float d);
	float I, p;
	printf("I=");
	scanf("%f", &I);
	p = count(I, 0, 100000, 0.1);
    p += count(I, 100000, 200000, 0.075);
	p += count(I, 200000, 400000, 0.05);
	p += count(I, 400000, 600000, 0.03);
	p += count(I, 400000, 1000000, 0.015);
	p += count(I, 1000000, 0, 0.01);
	printf("p=%.2f", p);
}

float count(float a, int b, int c, float d)
{   
    float t;
    if (a <= b) t = 0;
    else if (c && (a > c)) t = (c - b) * d;
    else t = (a - b) * d;
    return t;
}

