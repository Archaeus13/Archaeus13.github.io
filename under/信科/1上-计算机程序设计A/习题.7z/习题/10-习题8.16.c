//�洢����
#include <stdio.h>

int number(char c)
{
	if (c >= '0' && c <= '9') return 1;
	return 0;
}

int change(char* a, int *p)
{
	int i = 0;
	while (*a != '\0') {
		if (number(*a)) {
			*p *= 10;
			*p += (int) *a - 48;
			if (!number(*(a + 1))) {
			    p++;
			    i++;
			}
		}
		a++;
	}
	return i;
}

void main(void)
{
	char a[100], *q = a;
	int b[20], i, t, *p = b;
	for (i = 0; i < 20; i++) b[i] = 0;
	scanf("%s", a);
	t = change(q, p);
	printf("Total:%d\n", t);
	for (i = 0; i < t; i++) printf("%d ", b[i]);
}
