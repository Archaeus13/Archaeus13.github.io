//�ַ�������
#include <stdio.h>

void back(char a[])
{
	register short n = 0, i;
	char t;
	while (a[n] != '\0') n++;
	n--; 
	for (i = 0; i <= n / 2; i++) {
		t = a[i];
		a[i] = a[n-i];
		a[n-i] = t;
	}
}

void main(void)
{
	char a[100];
	scanf("%s", a);
	back(a);
	printf("%s\n", a);
}
