//���Լ������С������ 
#include <stdio.h>

int gcd(int a, int b)
{
	if (!a) return b;
	if (!b) return a;
    return (a > b) ? gcd(a % b, b) : gcd(a, b % a);
}

int lcm(int a, int b)
{
	return a * b / gcd(a, b);
}

void main(void)
{
	int a, b;
	printf("a=");
	scanf("%d", &a);
	printf("b=");
	scanf("%d", &b);
	printf("gcd=%d\n", gcd(a, b));
	printf("lcm=%d\n", lcm(a, b));
}
