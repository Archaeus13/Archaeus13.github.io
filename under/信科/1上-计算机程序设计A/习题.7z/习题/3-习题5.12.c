//���ӳ���
#include <stdio.h>

void main(void)
{
	register int i;
	int s = 1;
	for (i = 1; i <= 9; i++) {
		s += 1;
		s *= 2;
	}
	printf("s=%d", s);
}
