//ת�ַ���
#include <stdio.h>
#include <math.h>

char c[10];

int high(long n)
{
	long t;
	t = n / 10;
	if (!t) return n;
	else return high(t);
}

void change(long n)
{
	register int i = 0, j;
	long r = n / 10;
	while (r) {
		r /= 10;
		i++;
	}
	for (j = 0; j <= i; j++) {
		c[j] = high(n) + '0';
		n = n - high(n) * pow(10, i-j);
	}
}

void main(void)
{
	long n;
	printf("n=");
	scanf("%ld", &n);
	change(n);
	printf("%s", c);
}
