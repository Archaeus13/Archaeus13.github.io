// ������Ȧ
#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#define N sizeof(struct Gamer)

struct Gamer {
	int num;
	bool life;
	struct Gamer* next;
};
typedef struct Gamer* pt;

int alive(int n)
{
	int i, t = 0;
	pt head, p1, p2;
	p2 = head = malloc(N);
	head->num = 1;
	head->life = 1;
	for (i = 1; i < n; i++) {
		p1 = malloc(N);
		p1->life = 1;
		p1->num = i + 1;
		p2->next = p1;
		p2 = p1;
	}
	p2->next = head;
	p1 = p2;
	for (i = 1; i < n; i++) {
		while (t < 3) {
			p1 = p1->next;
			if (p1->life) t++;
		}
		p1->life = 0;
		t = 0;
	}
	while(!p1->life) p1 = p1->next;
	return p1->num;
}

void main(void)
{
	int n;
	puts("Input gamers");
	scanf("%d", &n);
	printf("The one who stays: %d", alive(n));
}
