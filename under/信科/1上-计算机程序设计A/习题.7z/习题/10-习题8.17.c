//�ַ����Ƚ� 
#include <stdio.h>

int compare(char* a, char* b)
{
	while (*a == *b) {
	    if (!*a) return 0;
		a++;
		b++; 
	}
	return *a - *b;
}

void main(void)
{
	char a[100], b[100];
	scanf("%s", a);
	scanf("%s", b);
	printf("%d", compare(a, b));
}
