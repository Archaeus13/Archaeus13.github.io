//�·�
#include <stdio.h>

void main(void)
{
    char c[12][10] = {"January","February","March","April","May","June","July","August","September","October","November","December"};
    char* p[12];
    int a, i;
    for (i = 0; i < 12; i++) p[i] = c[i];
    puts("Month:"); 
    scanf("%d", &a);
    printf("%s", p[a-1]);
}
