//Ԫ������
#include <stdio.h>

void copy(char a[])
{
	char b[100];
	register short i, t = 0;
	for (i = 0; i <= 100; i++) switch(a[i]) {
		case 'a':
		case 'A':
		case 'e':
		case 'E':
		case 'i':
		case 'I':
		case 'o':
		case 'O':
		case 'u':
		case 'U':
			b[t] = a[i];
			t++;
	}
	for (i = 0; i < t; i++) printf("%c", b[i]);
} 

void main(void)
{
	char a[100];
	scanf("%s", a);
	copy(a);
}
