//ͳ���ַ�����
#include <stdio.h>
#include <string.h>

void main(void) 
{
	register int i;
	int l, a = 0, b = 0, c = 0, d = 0;
	char str[100];
	printf("Please input the string.\n");
	scanf("%[^\n]", str);
	l = strlen(str);
	printf("Length:%d\n", l);
	for (i = 0; i <= l - 1; i++) {
		if ((str[i] > 64 && str[i] < 91)||(str[i] > 96 && str[i] < 123)) a++;
		else if (str[i] == 32) b++;
		else if (str[i] > 47 && str[i] < 58) c++;
	}
	d = l - a - b - c;
	printf("English letters:%d\n", a);
	printf("Spaces:%d\n", b);
	printf("Numbers:%d\n", c);
	printf("Others:%d\n", d);
}
