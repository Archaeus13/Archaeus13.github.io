//n�׻÷�
#include <stdio.h>

void main(void)
{
	short r, n, a[30][30]; //���������� 
	register int t, i, j, row, col;
	printf("n=");
	scanf("%d", &n);
	if (n % 2) { //������ �޲��� 
		for (i = 0; i < n; i++) for (j = 0; j < n; j++) a[i][j] = 0;
		row = 0;
		col = n / 2;
		for (i = 1; i <= n * n; i++) {
			a[row][col] = i;
			row = (row - 1 + n) % n;
			col = (col + 1) % n;
			if (row == n - 1 && !col) {
				row = 1;
				col = n - 1;
			}
			if (a[row][col]) {
				row += 2;
				col--;
			}		
		}
    }
    else if (n % 4) { //��ż���� ˹�����ȷ� 
        for (i = 0; i < n; i++) for (j = 0; j < n; j++) a[i][j] = 0;
		r = n / 2;
		row = 0;
		col = r / 2;
		for (i = 1; i <= r * r; i++) {
			a[row][col] = i;
			row = (row - 1 + r) % r;
			col = (col + 1) % r;
			if (row == r - 1 && !col) {
				row = 1;
				col = r - 1;
			}
			if (a[row][col]) {
				row += 2;
				col--;
			}		
		}
		for (i = r; i < n; i++) for (j = r; j < n; j++) a[i][j] = a[i-r][j-r] + r * r;
		for (i = 0; i < r; i++) for (j = r; j < n; j++) a[i][j] = a[i][j-r] + 2 * r * r;
		for (i = r; i < n; i++) for (j = 0; j < r; j++) a[i][j] = a[i-r][j] + 3 * r * r;
		for (i = 0; i < r; i++) for (j = 0; j < r / 2; j++) {
				t = a[i][j];
				a[i][j] = a[i+r][j];
				a[i+r][j] = t;
	    }
	    t = a[r/2][r/2];
		a[r/2][r/2] = a[r/2+r][r/2];
		a[r/2+r][r/2] = t;
		t = a[r/2][r/2-1];
		a[r/2][r/2-1] = a[r/2+r][r/2-1];
		a[r/2+r][r/2-1] = t;
		for (i = 0; i < r; i++) for (j = n + 1 - r / 2; j < n; j++) {
				t = a[i][j];
				a[i][j] = a[i+r][j];
				a[i+r][j] = t;
	    }
    }
	else { //˫ż���� ������ 
	    for (i = 0; i < n; i++) for (j = 0; j < n; j++) {
    			if ( i % 4 == j % 4 || (i + j) % 4 == 3 ) a[i][j] = n * n - n * i - j;
				else a[i][j] = n * i + j + 1;
		}
	}
	for (i = 0; i < n; i++) { //��� 
		for (j = 0; j < n; j++) printf("%3d ", a[i][j]);
		printf("\n");
	}
}
