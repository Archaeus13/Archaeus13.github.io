//��������
#include <stdio.h>

void main(void)
{
	register short i, t;
	short n, a[10];
	printf("Length=");
	scanf("%d", &n);
	for (i = 0; i < n; i++) {
	    printf("a[%d]=", i);
	    scanf("%d", &a[i]);
	}
	printf("Before:\n");
	for (i = 0; i < n; i++) printf("%d ", a[i]);
	for (i = 0; i < n / 2; i++) {
		t = a[i];
		a[i] = a[n-1-i];
		a[n-1-i] = t;
	}
	printf("\nAfter:\n");
	for (i = 0; i < n; i++) printf("%d ", a[i]);
} 
