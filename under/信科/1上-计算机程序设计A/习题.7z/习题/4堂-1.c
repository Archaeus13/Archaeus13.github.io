//��С��������
#include <stdio.h>

void main(void)
{
	int a, b, c, d, t;
	printf("a=");
	scanf("%d", &a);
	printf("b=");
	scanf("%d", &b);
	printf("c=");
	scanf("%d", &c);
	printf("d=");
	scanf("%d", &d);
	if (a > b) {
		t = a;
		a = b;
		b = t;
	}
	else if (a > c) {
		t = a;
		a = c;
		c = t;
	}
	else if (a > d) {
		t = a;
		a = d;
		d = t;
	}
	if (b > c) {
		t = b;
		b = c;
		c = t;
	}
	else if (b > d) {
		t = b;
		b = d;
		d = t;
	}
	if (c > d) {
		t = c;
		c = d;
		d = t;
	}
    printf("%d,%d,%d,%d", a, b, c, d);
} 
