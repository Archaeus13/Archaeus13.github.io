//�ɼ�����ȵ�
#include <stdio.h>

void main(void)
{
	register short i;
	short sc, gr;
	printf("����ɼ�\n");
	scanf("%d",&sc);
	for (i = 1; i <= 1;) {
	    if ((sc < 0) || (sc > 100)) {
		    printf("��������\n"); 
	        scanf("%d",&sc);
	    }
	    else i++;
    }
	gr = sc / 10;
	printf("�ȵ�Ϊ��");
	switch (gr) {
	    case 10:
		case 9: printf("A\n"); break;
		case 8: printf("B\n"); break;
		case 7: printf("C\n"); break;
		case 6: printf("D\n"); break;
		default: printf("E\n");	
	}
} 
