//ת�þ���
#include <stdio.h>

void tran(int array[][3])
{
	register short i, j;
	for (i = 0; i < 3; i++) {
		for (j = 0; j < 3; j++) printf("%d ", array[j][i]);
		printf("\n");
	}
}

void main(void)
{
	register short i, j;
	int a[3][3]={{1, 2, 3}, {4, 5, 6}, {7, 8, 9}};
	for (i = 0; i < 3; i++) {
		for (j = 0; j < 3; j++) printf("%d ", a[i][j]);
		printf("\n");
	}
	tran(a);
} 
 
