//ɾ���ڵ�
#include <stdio.h>
#include <stdlib.h>
#define N sizeof(struct Member)

struct Member {
	int num;
	struct Member* next;
};
typedef struct Member* pt;

pt create(int n)
{
    int i;
	pt head, p1, p2;
	p2 = head = malloc(N);
	for (i = 0; i < n; i++) {
		p1 = malloc(N);
		p1->num = i + 1;
		p2->next = p1;
		p2 = p1;
	}
	p2->next = NULL;
	return head;
}

int del(pt p, int n)
{
	int i;
	pt p0;
	for (i = 0; i < n - 1; i++) {
		p = p->next;
		if (p->next == NULL) return 1;
	}
	p0 = p;
	p = p->next;
	p0->next = p->next;
	free(p);
	return 0;
}

void print(pt p)
{
	while(p->next != NULL) {
	    p = p->next;
		printf("%d ", p->num);	
	}
	puts("");
}

void main(void)
{
	int n;
	pt p, head;
	puts("Input Members");
	scanf("%d", &n);
	p = head = create(n);
	print(p);
	puts("Delete Member");
	scanf("%d", &n);
	p = head;
	del(p, n);
	p = head;
	print(p);
}
