#include <iostream>
#include <fstream>
#include <ctime>
#include <windows.h>

using namespace std;

#define RED FALSE
#define BLACK TRUE

struct node{
    int low;
    int high;
    int m;
    bool color;
    node* left;
    node* right;
    node* p;
};

class IntervalTree {
    private:
        node* nil;
        node* root;
        void print_tree(node* now, int depth);
        void left_rotate(node* x);
        void right_rotate(node* x);
        void insert_fixup(node* z);
        void transplant(node* u, node* v);
        void delete_fixup(node* x);

    public:
        void init(void);
        void traverse(void);
        node* minimum(node* x);
        node* search(int low, int high);
        void insert(int low, int high);
        node* delete_node(node* z);
        node* random_node(void);
};