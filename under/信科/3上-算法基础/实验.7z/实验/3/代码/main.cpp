#include "interval_tree.h"

void gen_input(const char* path) {
    ofstream infile;
    infile.open(path, ios::out);
    int a[50] = {0}, count = 0;
    srand(time(0));
    while (1) {
        int temp_start = rand() % 50;
        if (temp_start >= 24 && temp_start <= 30) continue;
        if (a[temp_start] == 1) continue;
        a[temp_start] = 1;
        infile << temp_start << ' ';
        if (temp_start < 24) {
            int end = temp_start + 1 + rand() % (24 - temp_start);
            infile << end << endl;
        }
        else {
            int end = temp_start + 1 + rand() % (50 - temp_start);
            infile << end << endl;
        }
        if (++count == 30) break;
    }
    infile.close();
}

void init_tree(const char* path, IntervalTree& T) {
    T.init();
    ifstream infile;
    infile.open(path, ios::in);
    while (!infile.eof()) {
        int low, high;
        infile >> low >> high;
        T.insert(low, high);
    }
    infile.close();
}

void print_search(int low, int high, IntervalTree T) {
    node* now = T.search(low, high);
    cout << "search for: " << low << ' ' << high << endl;
    cout << "result: " <<  now->low << ' ' << now->high << endl;
}

int main(void) {
    gen_input("../input/input.txt");
    IntervalTree T;
    node* now;
    init_tree("../input/input.txt", T);
    freopen("../output/inorder.txt", "w", stdout);
    T.traverse();
    freopen("../output/delete_data.txt", "w", stdout);
    for (int i = 0; i < 3; i++) {
        now = T.delete_node(T.random_node());
        cout << now->low << ' ' << now->high << endl;
    }
    T.traverse();
    freopen("../output/search.txt", "w", stdout);
    int low = rand() % 50;
    print_search(low, low + rand() % (50 - low + 1), T);
    low = rand() % 50;
    print_search(low, low + rand() % (50 - low + 1), T);
    print_search(25, 30, T);
}