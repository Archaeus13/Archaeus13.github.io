#include "interval_tree.h"

void IntervalTree::init(void) {
    nil = new node;
    nil->color = BLACK;
    nil->p = nil->left = nil->right = nil;
    nil->low = nil->high = nil->m = -1;
    root = nil;
}

void IntervalTree::print_tree(node* now, int depth) {
    if (now == nil) return;
    print_tree(now->left, depth + 1);
    for (int i = 0; i < depth; i++) cout << "---";
    cout << (now->color ? 'B' : 'R') << " [" << now->low << ", " << now->high << ']';
    cout << ' ' << now->m << endl;
    print_tree(now->right, depth + 1);
}

void IntervalTree::traverse(void) {
    print_tree(root, 0);
    cout << endl;
}

node* IntervalTree::minimum(node* x) {
    while (x->left != nil) x = x->left;
    return x;
}

node* IntervalTree::search(int low, int high) {
    node* x = root;
    while (x != nil && (low > x->high || high < x->low))
        if (x->left != nil && x->left->m >= low)
            x = x->left;
        else x = x->right;
    return x;
}

void IntervalTree::left_rotate(node* x) {
    node* y = x->right;
    x->right = y->left;
    if (y->left != nil) y->left->p = x;
    y->p = x->p;
    if (x->p == nil) root = y;
    else if (x == x->p->left) x->p->left = y;
    else x->p->right = y;
    y->left = x;
    x->p = y;
    y->m = x->m;
    x->m = max(max(x->left->m, x->right->m), x->high);
}

void IntervalTree::right_rotate(node* x) {
    node* y = x->left;
    x->left = y->right;
    if (y->right != nil) y->right->p = x;
    y->p = x->p;
    if (x->p == nil) root = y;
    else if (x == x->p->right) x->p->right = y;
    else x->p->left = y;
    y->right = x;
    x->p = y;
    y->m = x->m;
    x->m = max(max(x->left->m, x->right->m), x->high);
}

void IntervalTree::insert_fixup(node* z) {
    while (!z->p->color) if (z->p == z->p->p->left) {
        node* y = z->p->p->right;
        if (!y->color) {
            z->p->color = y->color = BLACK;
            z->p->p->color = RED;
            z = z->p->p;
        }
        else {
            if (z == z->p->right) {
                z = z->p;
                left_rotate(z);
            }
            z->p->color = BLACK;
            z->p->p->color = RED;
            right_rotate(z->p->p);
        }
    }
    else {
        node* y = z->p->p->left;
        if (!y->color) {
            z->p->color = y->color = BLACK;
            z->p->p->color = RED;
            z = z->p->p;
        }
        else {
            if (z == z->p->left) {
                z = z->p;
                right_rotate(z);
            }
            z->p->color = BLACK;
            z->p->p->color = RED;
            left_rotate(z->p->p);
        }
    }
    root->color = BLACK;
}

void IntervalTree::insert(int low, int high) {
    node* z = new node;
    z->low = low;
    z->high = z->m = high;
    node* y = nil;
    node* x = root;
    while (x != nil) {
        y = x;
        if (z->low < x->low) x = x->left;
        else x = x->right;
    }
    z->p = y;
    if (y == nil) root = z;
    else if (z->low < y->low) y->left = z;
    else y->right = z;
    z->left = z->right = nil;
    z->color = RED;
    for (node* t = z->p; t != nil; t = t->p)
        high = t->m = max(t->m, high);
    insert_fixup(z);
}

void IntervalTree::transplant(node* u, node* v) {
    if (u->p == nil) root = v;
    else if (u == u->p->left) u->p->left = v;
    else u->p->right = v;
    v->p = u->p;
}

void IntervalTree::delete_fixup(node* x) {   
    while (x != root && x->color) if (x == x->p->left) {
        node* w = x->p->right;
        if (!w->color) {
            w->color = BLACK;
            x->p->color = RED;
            left_rotate(x->p);
            w = x->p->right;
        }
        if (w->left->color && w->right->color) {
            w->color = RED;
            x = x->p;
        }
        else {
            if (w->right->color == BLACK) {
                w->left->color = BLACK;
                w->color = RED;
                right_rotate(w);
                w = x->p->right;
            }
            w->color = x->p->color;
            x->p->color = BLACK;
            w->right->color = BLACK;
            left_rotate(x->p);
            x = root;
        }
    }
    else {
        node* w = x->p->left;
        if (!w->color) {
            w->color = BLACK;
            x->p->color = RED;
            right_rotate(x->p);
            w = x->p->left;
        }
        if (w->right->color && w->left->color) {
            w->color = RED;
            x = x->p;
        }
        else {
            if (w->left->color == BLACK) {
                w->right->color = BLACK;
                w->color = RED;
                left_rotate(w);
                w = x->p->left;
            }
            w->color = x->p->color;
            x->p->color = BLACK;
            w->left->color = BLACK;
            right_rotate(x->p);
            x = root;
        }
    }
    x->color = BLACK;
}

node* IntervalTree::delete_node(node* z) {
    node* x;
    node* y = z;
    bool origin_color = y->color;
    if (z->left == nil) {
        x = z->right;
        transplant(z, z->right);
    }
    else if (z->right == nil) {
        x = z->left;
        transplant(z, z->left);
    }
    else {
        y = minimum(z->right);
        origin_color = y->color;
        x = y->right;
        if (y->p == z) x->p = y;
        else {
            transplant(y, y->right);
            y->right = z->right;
            y->right->p = y;
        }
        transplant(z, y);
        y->left = z->left;
        y->left->p = y;
        y->color = z->color;
    }
    node* t = x;
    t->m = -1;
    do {
        t->m = max(max(t->left->m, t->right->m), t->high);
        t = t->p;
    } while (t != nil);
    if (origin_color) delete_fixup(x);
    return z;
}

node* IntervalTree::random_node(void) {
    node* x = root;
    while (1) {
        if (x->left == x->right) return x;
        int way = rand() % 3;
        if (x->left == nil) {
            if (way < 2) return x;
            x = x->right;
        }
        else if (x->right == nil) {
            if (way < 2) return x;
            x = x->left;
        }
        else {
            if (way == 0) return x;
            if (way == 1) return x->left;
            return x->right;
        }
    }
}