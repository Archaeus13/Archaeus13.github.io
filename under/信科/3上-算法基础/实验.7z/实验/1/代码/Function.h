#pragma once
#include <iostream>
using namespace std;

void max_heapify(int* A, int i, int hsize);
void build_max_heap(int* A, int n);
void heapsort(int* A, int n);

int partition(int* A, int p, int r);
void quicksort(int* A, int p, int r);
void quicksort(int* A, int n);

void merge(int* A, int p, int q, int r);
void mergesort(int* A, int p, int r);
void mergesort(int* A, int n);

void countingsort(int* A, int n);