#include "Function.h"
#include <cmath>

void max_heapify(int* A, int i, int hsize) {
	int largest;
	while (1) {
		int l = 2 * i + 1, r = 2 * i + 2;
		if (l < hsize && A[l] > A[i]) largest = l;
		else largest = i;
		if (r < hsize && A[r] > A[largest]) largest = r;
		if (largest == i) return;
		swap(A[i], A[largest]);
		i = largest;
	}
}

void build_max_heap(int* A, int n) {
	for (int i = n / 2; i >= 0; i--) max_heapify(A, i, n);
}

void heapsort(int* A, int n) {
	build_max_heap(A, n);
	int hsize = n;
	for (int i = n - 1; i >= 1; i--) {
		swap(A[0], A[i]);
		hsize--;
		max_heapify(A, 0, hsize);
	}
}

int partition(int* A,int p, int r) {
	int x = A[r], i = p - 1;
	for (int j = p; j < r; j++) {
		if (A[j] <= x) {
			i++;
			swap(A[i], A[j]);
		}
	}
	swap(A[i + 1], A[r]);
	return i + 1;
}

void quicksort(int* A, int p, int r) {
	if (p < r) {
		int q = partition(A, p, r);
		quicksort(A, p, q - 1);
		quicksort(A, q + 1, r);
	}
}

void quicksort(int* A, int n) {
	quicksort(A, 0, n - 1);
}

void merge(int* A, int p, int q, int r) {
	int n1 = q - p + 1, n2 = r - q;
	int* L = new int[n1 + 1];
	int* R = new int[n2 + 1];
	for (int i = 0; i < n1; i++) L[i] = A[p + i];
	for (int i = 0; i < n2; i++) R[i] = A[q + i + 1];
	L[n1] = R[n2] = INT_MAX;
	int i = 0, j = 0;
	for (int k = p; k <= r; k++) {
		if (L[i] <= R[j]) {
			A[k] = L[i];
			i++;
		}
		else {
			A[k] = R[j];
			j++;
		}
	}
}

void mergesort(int* A, int p, int r) {
	if (p < r) {
		int q = (p + r) / 2;
		mergesort(A, p, q);
		mergesort(A, q + 1, r);
		merge(A, p, q, r);
	}
}

void mergesort(int* A, int n) {
	mergesort(A, 0, n - 1);
}

void countingsort(int* A, int n) {
	int* B = new int[RAND_MAX+1];
	int* C = new int[n];
	for (int i = 0; i <= RAND_MAX; i++) B[i] = 0;
	for (int i = 0; i < n; i++) B[A[i]]++;
	for (int i = 1; i <= RAND_MAX; i++) B[i] += B[i - 1];
	for (int i = n - 1; i >= 0; i--)
		C[--B[A[i]]] = A[i];
	for (int i = 0; i < n; i++) A[i] = C[i];
}