﻿#include <iostream>
#include <Windows.h>
#include <fstream>
#include "Function.h"

using namespace std;

void gen_input(void) {
	ofstream outfile;
	char filepath[20];
	const int size = (int)pow(2, 18);
	cout << "gen begin" << endl;
	for (int j = 1; j <= 5; j++) {
		sprintf_s(filepath, "../input/%d.txt", j);
		outfile.open(filepath, ios::out);
		for (int k = 0; k < size; k++)
			outfile << rand() << endl;
		outfile.close();
		cout << '.';
	}
	cout << endl << "gen end" << endl << endl;
}

void test_sort(void (*sort)(int* A, int n), const char* name) {
	char outpath[40];
	sprintf_s(outpath, "cd ../output && mkdir %s", name);
	system(outpath);

	LARGE_INTEGER start, ende;
	ifstream infile;
	ofstream outfile, time;
	char infilepath[20];
	int* A;

	sprintf_s(outpath, "../output/%s/time.txt", name);
	time.open(outpath, ios::out);

	cout << name << endl;
	for (int i = 3; i <= 18; i += 3) {
		time << "2^" << i << ":\t";
		cout << "2^" << i << ":\t";
		int size = (int)pow(2, i);
		A = new int[size];
		for (int j = 1; j <= 5; j++) {
			sprintf_s(infilepath, "../input/%d.txt", j);
			infile.open(infilepath, ios::in);
			for (int k = 0; k < size; k++) infile >> A[k];
			infile.close();
			QueryPerformanceCounter(&start);
			sort(A, size);
			QueryPerformanceCounter(&ende);
			time << ende.QuadPart - start.QuadPart << '\t';
			cout << ende.QuadPart - start.QuadPart << '\t';
			sprintf_s(outpath, "../output/%s/2^%d_%d.txt", name, i, j);
			outfile.open(outpath, ios::out);
			for (int k = 0; k < size; k++) outfile << A[k] << endl;
			outfile.close();
		}
		time << endl;
		cout << endl;
		delete[]A;
	}
	cout << endl;
	time.close();
}

int main()
{
	srand(time(0));
	gen_input();
	LARGE_INTEGER tc;
	QueryPerformanceFrequency(&tc);
	cout << tc.QuadPart << " ticks per second" << endl;
	cout << "the following timings are all in ticks" << endl << endl;
	//test_sort(sort_funtion, "sort name");
	test_sort(heapsort, "HeapSort");
	test_sort(quicksort, "QuickSort");
	test_sort(mergesort, "MergeSort");
	test_sort(countingsort, "CountingSort");
	return 0;
}