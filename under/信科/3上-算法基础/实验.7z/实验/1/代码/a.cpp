#include <iostream>
#include <cmath>

using namespace std;

void max_heapify(int* A, int i, int hsize) {
	//int largest;
    //int t;
	while (i<hsize) {
        if(A[i]>A[2*i+1] &&A[i]>A[2*i+2])
            break;
        else if(A[2*i+1]>A[i] &&A[2*i+1]>A[2*i+2])
        {
            swap(A[i], A[2*i+1]);
            i=2*i+1;
        }
        else if(A[2*i+2]>A[i] &&A[2*i+2]>A[2*i+1])
        {
            swap(A[i], A[2*i+2]);
            i=2*i+2;
        }
        printf("%d\n",i);
	}
}

void build_max_heap(int* A, int n) {
	for (int i = n / 2; i >= 0; i--) 
        max_heapify(A, i, n);
}

void heapsort(int* A, int n) {
	build_max_heap(A, n);
	int hsize = n;
	for (int i = n - 1; i >= 1; i--) {
		swap(A[0], A[i]);
		hsize--;
		max_heapify(A, 0, hsize);
	}
}

int main(void) {
    int A[6] = {1,3,2,5,-1,0};
    build_max_heap(A, 6);
    for (int i = 0; i < 6; i++) cout << A[i] << ' ';
}