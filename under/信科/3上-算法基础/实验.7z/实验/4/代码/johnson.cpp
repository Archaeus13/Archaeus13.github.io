﻿#include "graph.h"
#include <windows.h>
#include <time.h>

ofstream time_file;
LARGE_INTEGER start, ende;

void gen_input(int vnum, int edgenum, const char* path) {
    ofstream outfile;
    outfile.open(path, ios::out);
    for (int i = 0; i < vnum; i++)
        for (int j = 0; j < edgenum; j++) {
            outfile << i << ' ';
            int r = rand() % vnum;
            while (r == i) r = rand() % vnum;
            outfile << r << ' ';
            outfile << rand() % 61 - 10 << endl;
    }
    cout << '.';
}

void gen_input(void) {
    gen_input(27, 2, "input/input11.txt");
    gen_input(27, 1, "input/input12.txt");
    gen_input(81, 2, "input/input21.txt");
    gen_input(81, 2, "input/input22.txt");
    gen_input(243, 3, "input/input31.txt");
    gen_input(243, 2, "input/input32.txt");
    gen_input(729, 4, "input/input41.txt");
    gen_input(729, 3, "input/input42.txt");
    cout << "generate done" << endl << endl;
}

void test(int vnum, const char* in_file, const char* out_file) {
    Graph G;
    time_file << vnum << '\t';
    cout << "input vertex num: " << vnum << endl;
    G.init(vnum);
    G.read_file(in_file);
    cout << "negative circle cleaned" << endl;
    cout << "edge num: " << G.get_edge_num() << endl;
    time_file << G.get_edge_num() << " \t";
    QueryPerformanceCounter(&start);
    G.johnson(out_file);
    QueryPerformanceCounter(&ende);
    time_file << ende.QuadPart - start.QuadPart << endl;
    cout << "time: " << ende.QuadPart - start.QuadPart << endl;
    cout << endl;
}

void test(void) {
    test(27, "input/input11.txt", "output/result11.txt");
    test(27, "input/input12.txt", "output/result12.txt");
    test(81, "input/input21.txt", "output/result21.txt");
    test(81, "input/input22.txt", "output/result22.txt");
    test(243, "input/input31.txt", "output/result31.txt");
    test(243, "input/input32.txt", "output/result32.txt");
    test(729, "input/input41.txt", "output/result41.txt");
    test(729, "input/input42.txt", "output/result42.txt");
}

int main(void) {
    srand(time(0));
    time_file.open("output/time.txt", ios::out);

    QueryPerformanceFrequency(&start);
    cout << start.QuadPart << " ticks per second" << endl;
    time_file << start.QuadPart << " ticks per second" << endl;
    cout << "the following timings are all in ticks" << endl << endl;
    time_file << "the following timings are all in ticks" << endl << endl;
    time_file << "V\tE\ttime" << endl;

    gen_input();
    test();

    time_file.close();
}
