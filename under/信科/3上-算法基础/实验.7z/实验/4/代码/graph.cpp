#include "graph.h"

void NumHeap::init(int n) {
	heap_size = n;
	vector<int> dis(n);
	for (int i = 0; i < n; i++) dis[i] = INFTY;
	d = dis;
	vector<int> se(n);
	for (int i = 0; i < n; i++) se[i] = i;
	heap = se;
	pos = se;
}

int NumHeap::extract_min(void) {
	int ret = heap[0];
	swap(pos[heap[0]], pos[heap[--heap_size]]);
	swap(heap[0], heap[heap_size]);
	int now = 0, mini = 0;
	while (1) {
		int l = 2 * now + 1, r = 2 * now + 1;
		if (l < heap_size && d[heap[l]] < d[heap[mini]]) mini = l;
		if (r < heap_size && d[heap[r]] < d[heap[mini]]) mini = r;
		if (mini == now) return ret;
		swap(pos[heap[now]], pos[heap[mini]]);
		swap(heap[now], heap[mini]);
		now = mini;
	}
	return ret;
}

void NumHeap::decrease(int serial, int after) {
	d[heap[serial]] = after;
	while (1) {
		int pre = (serial - 1) / 2;
		if (d[heap[pre]] <= d[heap[serial]]) return;
		swap(pos[heap[pre]], pos[heap[serial]]);
		swap(heap[pre], heap[serial]);
		serial = pre;
	}
}

void Graph::add_edge(int u, int v, int length) {
	node* edg = new node;
	edg->serial = v;
	edg->edge_length = length;
	edg->next = vertex[u]->next;
	vertex[u]->next = edg;
	edge_num++;
}

int Graph::delete_edge(int u, int v) {
	node* now = vertex[u];
	node* pre = now;
	while (now->next != nullptr) {
		now = now->next;
		if (now->serial == v) {
			pre->next = now->next;
			delete now;
			edge_num--;
			return 0;
		}
		pre = pre->next;
	}
	return 1;
}

int Graph::get_edge_length(int u, int v) {
	node* now = vertex[u];
	while (now->next != nullptr) {
		now = now->next;
		if (now->serial == v)
			return now->edge_length;
	}
	return INFTY;
}

int Graph::find_negative_circle(void) {
	const int v = get_vertex_num();
	vector<int> d(v);
	for (int i = 0; i < v - 1; i++) for (int j = 0; j < v; j++) {
		node* now = vertex[j];
		while (now->next != nullptr) {
			now = now->next;
			if (d[now->serial] > d[j] + now->edge_length)
				d[now->serial] = d[j] + now->edge_length;
		}
	}
	for (int j = 0; j < v; j++) {
		node* now = vertex[j];
		while (now->next != nullptr) {
			now = now->next;
			if (d[now->serial] > d[j] + now->edge_length)
				return 1;
		}
	}
	return 0;
}

vector<int> Graph::get_renew_h(void) {
	const int v = get_vertex_num();
	vector<int> d(v);
	for (int i = 0; i < v - 1; i++) for (int j = 0; j < v; j++) {
		node* now = vertex[j];
		while (now->next != nullptr) {
			now = now->next;
			if (d[now->serial] > d[j] + now->edge_length)
				d[now->serial] = d[j] + now->edge_length;
		}
	}
	return d;
}

void Graph::dijkstra(int v, vector<int> h) {
	const int vnum = get_vertex_num();

	vector<int> pi(vnum);
	for (int i = 0; i < vnum; i++) pi[i] = -1;
	
	NumHeap H;
	H.init(vnum);
	H.decrease(H.get_pos(v), 0);
	while (H.get_heap_size() > 0) {
		int u = H.extract_min();
		node* now = vertex[u];
		while (now->next != nullptr) {
			now = now->next;
			int w = now->serial;
			int new_length = H.get_d(u) + now->edge_length + h[u] - h[w];
			if (H.get_d(w) > new_length) {
				H.decrease(H.get_pos(w), new_length); 
				pi[w] = u;
			}
		}
	}

	for (int i = 0; i < vnum; i++) {
		cout << v << '-' << i << ": ";
		if (pi[i] == -1) cout << "none" << endl;
		else {
			int j = i;
			while (pi[j] != -1) {
				cout << j << "<-";
				j = pi[j];
			}
			cout << j << ' ';
			cout << H.get_d(i) - h[v] + h[i] << endl;
		}
	}
}

void Graph::init(int vnum) {
	vector<node*> v(vnum);
	vertex = v;
	for (int i = 0; i < vnum; i++) {
		vertex[i] = new node;
		vertex[i]->serial = -1;
		vertex[i]->edge_length = 0;
		vertex[i]->next = nullptr;
	}
	edge_num = 0;
}

void Graph::read_file(const char* path) {
	ifstream in_file;
	in_file.open(path, ios::in);
	int u = 0, v = 0, w = 0;
	while (in_file >> u >> v >> w) {
		add_edge(u, v, w);
		if (find_negative_circle()) {
			delete_edge(u ,v);
			cout << '(' << u << ',' << v << "); ";
		}
	}

}

void Graph::johnson(const char* path) {
	vector<int> h = get_renew_h();
	FILE* stream;
	freopen_s(&stream, path, "w", stdout);
	for (int i = 0; i < get_vertex_num(); i++)
		dijkstra(i, h);
	fclose(stdout);
	freopen_s(&stream, "CON", "w", stdout);
}