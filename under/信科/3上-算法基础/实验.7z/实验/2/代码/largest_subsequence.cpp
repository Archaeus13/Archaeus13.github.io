#include <iostream>
#include <Windows.h>
#include <fstream>
#include <vector>

using namespace std;

ofstream outfile;

void print_result(vector<vector<char>> t, string a) {
    int m = t.size() - 1;
    int n = t[0].size() - 1;
    string d = "";
    while (m >= 0 && n >= 0) {
        if (t[m][n] == 'd') {
            d = a[m] + d;
            m--;
            n--;
        }
        else if (t[m][n] == 'u') m--;
        else n--;
    }
    cout << d << endl;
    outfile << d << endl;
}

int longest_common_subsequence(string a, string b) {
    int m = a.length(), n = b.length();
    vector<vector<int>> c(m+1, vector<int>(n+1));
    vector<vector<char>> t(m, vector<char>(n));
    for (int i = 0; i < m; i++) for (int j = 0; j < n; j++) {
        if (a[i] == b[j]) {
            c[i+1][j+1] = c[i][j] + 1;
            t[i][j] = 'd';
        }
        else if (c[i][j+1] > c[i+1][j]) {
            c[i+1][j+1] = c[i][j+1];
            t[i][j] = 'u';
        }
        else {
            c[i+1][j+1] = c[i+1][j];
            t[i][j] = 'l';
        }
    }
    char outpath[30];
    sprintf_s(outpath, "../output/result_%d.txt", m);
    outfile.open(outpath, ios::out);
    outfile << c[m][n] << endl;
    print_result(t, a);
    outfile.close();
    return c[m][n];
}

int main(void) {
    ifstream infile;
	ofstream time;
    LARGE_INTEGER start, ende;
	QueryPerformanceFrequency(&start);
	cout << start.QuadPart << " ticks per second" << endl;
	cout << "the following timings are all in ticks" << endl << endl;
    infile.open("../input/2_2_input.txt", ios::in);
    time.open("../output/time.txt", ios::out);
    int size;
    string a, b;
    for (int i = 0; i < 5; i ++) {
        infile >> size;
        infile >> a;
        infile >> b;
        cout << "size: " << size << endl;
        QueryPerformanceCounter(&start);
        longest_common_subsequence(a, b);
        QueryPerformanceCounter(&ende);
        time << ende.QuadPart - start.QuadPart << endl;
		cout << "time: " << ende.QuadPart - start.QuadPart << endl;
    }
    time.close();
    infile.close();
}