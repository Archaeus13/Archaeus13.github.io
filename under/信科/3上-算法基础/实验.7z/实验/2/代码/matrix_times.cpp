#include <iostream>
#include <Windows.h>
#include <fstream>
#include <vector>

#define INFTY INT64_MAX / 4;

using namespace std;

ofstream outfile;

void print_result(vector<vector<long long>> s, int i, int j) {
    if (i == j) {
        outfile << 'A' << i;
        return;
    }
    outfile << '(';
    print_result(s, i, s[j][i]);
    print_result(s, s[j][i] + 1, j);
    outfile << ')';
}

long long min_matrix_times(vector<int> p) {
    const int size = p.size() - 1;
    vector<vector<long long>> m(size, vector<long long>(size));
    for (int l = 1; l < size; l++) for (int i = 0; i < size - l; i++) {
        int j = i + l;
        m[i][j] = INFTY;
        for (int k = i; k < j; k++) {
            long long q = m[i][k] + m[k+1][j] + (long long)p[i]*p[k+1]*p[j+1];
            if (q < m[i][j]) {
                m[i][j] = q;
                m[j][i] = k;
            }
        }
    }
    outfile << m[0][size-1] << endl;
    print_result(m, 0, size-1);
    outfile << endl;
    for (int i = 0; i < size; i++) {
        for (int j = i; j < size; j++) outfile << m[i][j] << "\t\t";
        outfile << endl;
    }
    outfile << endl;
    return m[0][size-1];
}

int main(void) {
    ifstream infile;
	ofstream time;
    LARGE_INTEGER start, ende;
	QueryPerformanceFrequency(&start);
	cout << start.QuadPart << " ticks per second" << endl;
	cout << "the following timings are all in ticks" << endl << endl;
    infile.open("../input/2_1_input.txt", ios::in);
    outfile.open("../output/result.txt", ios::out);
    time.open("../output/time.txt", ios::out);
    int size;
    for (int i = 0; i < 5; i ++) {
        infile >> size;
        vector<int> p(size + 1);
        cout << "size: " << size << endl;
        for (int t = 0; t <= size; t++) infile >> p[t];
        QueryPerformanceCounter(&start);
        cout << "result: " << min_matrix_times(p) << endl;
        QueryPerformanceCounter(&ende);
        time << ende.QuadPart - start.QuadPart << endl;
		cout << "time: " << ende.QuadPart - start.QuadPart << endl;
    }
    outfile.close();
    time.close();
    infile.close();
}
