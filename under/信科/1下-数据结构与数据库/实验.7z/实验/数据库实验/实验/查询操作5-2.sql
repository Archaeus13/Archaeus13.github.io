select title,price
from pubs..titles
order by price desc;