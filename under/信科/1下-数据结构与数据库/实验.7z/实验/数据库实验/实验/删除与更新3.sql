update student..SPB20000296
set price = price - 2
where t_no like 'D%'