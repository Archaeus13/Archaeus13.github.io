select au_fname,au_lname,phone
from pubs..authors
order by au_fname,au_lname;