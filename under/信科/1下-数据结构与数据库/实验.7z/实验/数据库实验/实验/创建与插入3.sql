create view VSPB20000296
as
select Title,QTY from student..SPB20000296