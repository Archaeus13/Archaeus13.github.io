select sum(qty)
from pubs..sales;