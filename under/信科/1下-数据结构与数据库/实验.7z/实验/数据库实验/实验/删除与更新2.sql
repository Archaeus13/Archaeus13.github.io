update student..SPB20000296
set price = price * 0.95