select title,price
from pubs..titles
where price = any
(select max(price)
from pubs..titles);