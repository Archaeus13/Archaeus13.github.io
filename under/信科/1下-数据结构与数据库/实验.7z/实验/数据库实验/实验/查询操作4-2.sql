select pubs..authors.au_fname,au_lname,pubs..titles.title
from pubs..authors,pubs..titleauthor,pubs..titles
where pubs..authors.au_id=pubs..titleauthor.au_id and pubs..titles.title_id=pubs..titleauthor.title_id;