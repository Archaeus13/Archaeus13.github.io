select title
from pubs..titles
where price between 15 and 18;