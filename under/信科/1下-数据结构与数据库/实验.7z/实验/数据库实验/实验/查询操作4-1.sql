select pubs..publishers.pub_name,pubs..titles.title
from pubs..publishers,pubs..titles
where pubs..titles.pub_id=pubs..publishers.pub_id;