select count(distinct type)
from pubs..titles;