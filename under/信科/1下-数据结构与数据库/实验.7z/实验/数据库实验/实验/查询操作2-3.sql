select title_id,title
from pubs..titles
where title like 'T%';