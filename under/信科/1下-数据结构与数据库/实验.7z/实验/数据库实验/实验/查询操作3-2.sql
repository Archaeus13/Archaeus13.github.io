select title_id,title,price
from pubs..titles
where title not like 'T%' and price > 16;