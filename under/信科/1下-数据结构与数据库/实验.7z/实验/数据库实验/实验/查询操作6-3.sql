select title,price
from pubs..titles
where price = any
(select min(price)
from pubs..titles);