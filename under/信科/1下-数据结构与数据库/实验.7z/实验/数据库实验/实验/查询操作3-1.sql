select title,price
from pubs..titles
where title like 'T%' and price < 16;