create table student..SSPB20000296(title char(20),price money);

insert
into student..SSPB20000296(title,price)
select Title,price from student..SPB20000296;