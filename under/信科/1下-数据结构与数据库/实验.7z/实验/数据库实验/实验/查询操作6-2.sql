select count(distinct price)
from pubs..titles;