#include <iostream>
#include <math.h> 
using namespace::std; 

void PrintPower(char c[], int i) {
    int k;
    for (int j = 0; j < pow(2,i); j++) {
    	k = j;
    	cout << '{';
    	for (int m = 0; m < i; m++) {
    		if (k % 2) cout << c[m]; 
    		k /= 2;
		}
		cout << '}' << endl;
	}
}
	

int main(void) {
	char c[10];
	int i = 0;
	while ((c[i] = cin.get()) != '\n') i++;
	PrintPower(c, i);
	return 0;
}
