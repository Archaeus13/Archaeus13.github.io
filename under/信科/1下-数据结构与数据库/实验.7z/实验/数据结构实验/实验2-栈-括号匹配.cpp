#define ElemType char
#include "ʵ��2-ջ-ԭ��.cpp"

int main(void) {
	node* p = NULL;
	char a, b;
	InitStack(p);
	while ((a = cin.get()) != '\n') {
		if (a == '(' || a == '[' || a == '{') Push(p, a);
		if (a == ')' || a == ']' || a == '}') {
			if (!GetTop(p, b) && ((a == ')' && b == '(') || (a == ']' && b == '[') || (a == '}' && b == '{'))) Pop(p, b);
			else {
			    cout << "δƥ��" << endl;
			    DestroyStack(p);
			    return 0;
			}
		}
	}
	if (GetTop(p, a)) cout << "��ƥ��" << endl;
	else cout << "δƥ��" << endl;
	DestroyStack(p);
}
