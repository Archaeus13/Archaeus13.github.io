#define Tree struct bitree
#define ElemType Tree* 
#include "ʵ��3-����-ԭ��.cpp"
#include <math.h> 

struct bitree{
	int dat;
	struct bitree* lchild;
	struct bitree* rchild; 
};

void PrintMenu(void) {
	cout << "***********************************" << endl; 
	cout << "0-�˳�" << endl;
	cout << "1-����������" << endl;
	cout << "2-ɾ��������" << endl;
	cout << "3-����������" << endl;
	cout << "4-����ֵ" << endl;
	cout << "5-����ֵ" << endl;
	cout << "6-����ƽ�����ҳ���" << endl;
	cout << "***********************************" << endl; 
}

void Insert(Tree* &t, int m) {
	if (!t) {
		t = new Tree;
        t->dat = m; 
	    t->lchild = NULL;
	    t->rchild = NULL;
	    return;
	}
	if (m < t->dat) Insert(t->lchild, m);
    else if (m > t->dat) Insert(t->rchild, m);
	else cout << "�����Ѵ���";
}

void InitDSTree(Tree* &t) {
	cout << "�����������ݣ�����0�Խ���" << endl;
	int x;
	while(getchar() != '\n');
	cin >> x;
	while (x) {
		Insert(t, x);
		cin >> x;
	}
}

void DestroyDSTree(Tree* &t) {
	if (!t) return;
	DestroyDSTree(t->lchild);
	DestroyDSTree(t->rchild);
	delete t;
	t = NULL;
}

void Traverse(Tree* t) {
	if (!t) return;
	Traverse(t->lchild);
	cout << t->dat << ' ';
	Traverse(t->rchild);
}

void Search(Tree* t, int m) {
	if (!t) {
		cout << "��������" << endl;
		return;
	}
	if (m == t->dat) {
		cout << m << "���ڣ�Ϊ���ڵ�" << endl;
		return;
	}
	Tree *p, *q;
	p = t;
	if (m < p->dat) q = p->lchild;
    else if (m > p->dat) q = p->rchild;
	while (q) {
		if (m < q->dat) q = q->lchild;
        else if (m > q->dat) q = q->rchild;
        else {
        	cout << m << "���ڣ����ڵ�Ϊ" << p->dat << endl;
        	return;
		}
		if (m < p->dat) p = p->lchild;
        else if (m > p->dat) p = p->rchild;
	}
	cout << m << "������";
}

int nodes(Tree* t) {
	if(!t) return 0;
	return nodes(t->lchild)+nodes(t->rchild)+1;
}

int sum(Tree* t) {
	if(!t) return 0;
	return sum(t->lchild)+nodes(t->lchild)+sum(t->rchild)+nodes(t->rchild)+1;
}

float Average(Tree* t) {
	return (float)sum(t)/nodes(t);
}

int main(void) {
	Tree* a = NULL;
	node* q = NULL;
	char n;
	int m;
	cout << "���س���ʼ" << endl; 
	while (1) {
		while(getchar() != '\n');
		PrintMenu();
		cin >> n;
		switch (n) {
			case '0':
			    exit(0);
			
			case '1':
				InitDSTree(a);
				break;
			
			case '2': 
			    DestroyDSTree(a);
			    break;
			    
			case '3':
				Traverse(a);
				cout << endl;
			    break;
			    
			case '4':
				cin >> m;
				Insert(a, m);
				break;
				
			case '5':
				cin >> m;
				Search(a, m);
				break;
				
			case '6':
				cout << Average(a) << endl;
				break;
							
			default:
				cout << "������������" << endl;
		}
		
	}
}

