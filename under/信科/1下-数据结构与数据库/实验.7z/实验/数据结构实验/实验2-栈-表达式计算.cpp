#define ElemType char
#include "ʵ��2-ջ-ԭ��.cpp"

int count(char num, char sym, float &ans) {
	if (sym == '+') {
		ans += num - '0';
		return ans;
	}
	if (sym == '-') {
		ans = num - '0' - ans;
		return ans;
	}
	if (sym == '*') {
		ans *= num - '0';
		return ans;
	}
	if (sym == '/') {
		ans = (num - '0') / ans;
		return ans;
	}
	cout << "ERROR" << endl;
	return -1;
}

int main(void) {
	node* p = NULL;
	char a, b;
	bool t = 1;
	float ans;
	InitStack(p);
	while ((a = cin.get()) != '\n') {
		if (a >= '0' && a <= '9') Push(p, a);
		else {
			if (t) {
				Pop(p, b);
				ans = b - '0';
				t = 0;
			}
			    Pop(p, b);
			    cout << b << a << ans << '='; 
			    cout << count(b, a, ans) << endl;
		}
	}
	cout << "ans=" << ans << endl;
	DestroyStack(p);
	return 0;
}
