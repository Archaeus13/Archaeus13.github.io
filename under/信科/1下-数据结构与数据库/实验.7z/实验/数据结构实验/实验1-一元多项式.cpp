//һԪ����ʽ������ 
#include <iostream>
#include <math.h>
using namespace::std;

struct ElemType{
	float p;
	int e;
	struct ElemType* next;
};
typedef struct ElemType term;

void PrintMenu(void) {
	cout << "********************" << endl; 
	cout << "0-�˳�" << endl;
	cout << "1-��������ʽf" << endl;
	cout << "2-��������ʽg" << endl;
	cout << "3-��ӡf,g" << endl; 
	cout << "4-ɾ��f" << endl;
	cout << "5-ɾ��g" << endl;
	cout << "6-����f+g" << endl;
	cout << "7-����f-g" << endl;
	cout << "a-����f��ĳ�㴦ȡֵ" << endl;
	cout << "b-����f��N�׵���" << endl;
	cout << "c-����f�Ķ�����" << endl;
	cout << "d-����f*g" << endl;
	cout << "e-����f��g�Ĵ������" << endl;
	cout << "********************" << endl; 
}

int CreatePolyn(term* &p) {
	if (p) {
		cout << "���󣺶���ʽ�Ѵ���" << endl;
		while(getchar() != '\n');
		return -1; 
	}
	int n;
	float a;
	term *qa, *qb;
	qa = p = new term;
	cout << "�밴�����ݼ�˳�����������ϵ�����ڴ�������-1�Խ���" << endl; 
	cout << "�����������";
	while(getchar() != '\n');
	cin >> n;
	while (n >= 0) {
		qb = new term;
		qb->e = n;
		qa->next = qb;
		cout << "������ϵ����";
		while(getchar() != '\n');
		cin >> a;
		while(!a) {
			cout << "����ϵ��Ϊ0�����������룺";
			while(getchar() != '\n');
			cin >> a;
		}
		qb->p = a;
		qa = qb;
		cout << "�����������";
		while(getchar() != '\n');
		cin >> n;
		while(n >= qa->e) {
			cout << "����δ�ݼ����������������룺";
			while(getchar() != '\n');
			cin >> n;
		}
	}
	qa->next = NULL;
	cout << "�ѳɹ����ɶ���ʽ" << endl; 
	return 0;
}

int PrintPolyn(term* p, string c) {
	if (!p) {
	    cout << "���󣺶���ʽ������" << endl;
	    return -1;
	}
	cout << c << " = ";
	if (!p->next) cout << 0;
	while (p->next) {
		p = p->next;
		if (p->e) {
			if (p->p > 0) if (fabs(p->p - 1) > 1e-3) cout << " +" << p->p;
			else cout << " +";
			else if(fabs(p->p + 1) > 1e-3) cout << ' ' << p->p;
			else cout << " -";
			cout << 'x';
			if (p->e != 1) cout << '^' << p->e; 
		}
		else if (p->p > 0) cout << " +" << p->p;
		else cout << ' ' << p->p;
	}
	cout << endl;
	return 0;
}

int DestroyPolyn(term* &p) {
	if (!p) {
	    cout << "���󣺶���ʽ������" << endl;
	    return -1;
	}
	term *q = p;
	while (p) {
		p = p->next;
		delete q;
		q = p;
	}
	return 0;
}

term* AddPolyn(term* pa, term* pb) {
	if (!pa || !pb) {
		cout << "���󣺶���ʽ������" << endl;
	    return NULL;
	}
	term *ans, *s, *t;
	t = ans = new term;
	pa = pa->next;
	pb = pb->next;
	while(pa || pb) {
		if (!pb || (pa && pa->e > pb->e)) {
			s = new term;
		    s->e = pa->e;
		    s->p = pa->p;
		    pa = pa->next;
		    t->next = s;
	    	t = s;
		}
		else if (!pa || pa->e < pb->e) {
			s = new term;
			s->e = pb->e;
		    s->p = pb->p;
		    pb = pb->next;
		    t->next = s;
		    t = s;
		}
		else if (fabs(pa->p + pb->p) > 1e-3) {
			s = new term;
			s->e = pa->e;
			s->p = pa->p + pb->p;
			pa = pa->next;
			pb = pb->next;
			t->next = s;
		    t = s;
		}
		else {
			pa = pa->next;
			pb = pb->next;
		}
	}
	t->next = NULL;
	return ans;
}

term* EasyMultiPolyn(term* p, int e, float c) {
	if (!p) {
	    cout << "���󣺶���ʽ������" << endl;
	    return NULL;
	}
	term *ans, *s, *t;
	t = ans = new term; 
	while (p->next) {
		p = p->next;
		s = new term;
		s->e = p->e + e;
		s->p = c * p->p;
		t->next = s;
		t = s;
	}
	t->next = NULL;
	return ans;
}

term* SubstractPolyn(term* pa, term* pb) {
	term *b, *ans;
	b = EasyMultiPolyn(pb, 0, -1);
	ans = AddPolyn(pa, b);
	DestroyPolyn(b);
	return ans;
}

float Assign(term *p, float a) {
	if (!p) {
		cout << "���󣺶���ʽ������" << endl;
	    return -1;
	}
	float s = 0;
	while (p->next) {
		p = p->next;
		s += p->p * pow(a, p->e);
	}
	return s;
}

term* DerivatePolyn(term* p, int n) {
	if (!p) {
		cout << "���󣺶���ʽ������" << endl;
	    return NULL;
	}
	term *ans, *s, *t;
	t = ans = new term;
	while(p->next && p->next->e >= n) {
		p = p->next;
		s = new term;
		s->e = p->e - n;
		s->p = p->p;
		for (int i = 0; i < n; i++) s->p *= s->e + i + 1;
		t->next = s;
		t = s;
	}
	t->next = NULL;
	return ans;
}

float IntePolyn(term* p, float a, float b) {
	term *ans, *s, *t;
	float m;
	if (!p) {
		cout << "���󣺶���ʽ������" << endl;
	    return -1;
	}
	t = ans = new term;
	while(p->next) {
		p = p->next;
		s = new term;
		s->e = p->e + 1;
		s->p = p->p / s->e;
		t->next = s;
		t = s;
	}
	t->next = NULL;
	m = Assign(ans, b) - Assign(ans, a);
	DestroyPolyn(ans);
	return m;
}

term* MultiPolyn(term* pa, term* pb) {
	if (!pa || !pb) {
		cout << "���󣺶���ʽ������" << endl;
	    return NULL;
	}
	term *p, *q, *ans;
	ans = new term;
	ans->next = NULL;
	while(pb->next) {
		pb = pb->next;
		p = ans;
		q = EasyMultiPolyn(pa, pb->e, pb->p);
		ans = AddPolyn(p, q);
		DestroyPolyn(p);
		DestroyPolyn(q);
	}
	return ans;
}

term* DevidePolyn(term* pa, term* pb) {
    if (!pa || !pb) {
		cout << "���󣺶���ʽ������" << endl;
	    return NULL;
	}
	if (!pb->next) {
		cout << "���󣺳���Ϊ0" << endl;
		return NULL;
	}
	term *ans, *p, *q, *r, *s, *t;
	p = EasyMultiPolyn(pa, 0, 1);
	t = ans = new term;
	while(p->next && p->next->e >= pb->next->e) {
		s = new term;
	    s->e = p->next->e - pb->next->e;
	    s->p = p->next->p / pb->next->p;
	    t->next = s;
	    t = s;
	    q = EasyMultiPolyn(pb, s->e, s->p);
	    r = SubstractPolyn(p, q);
	    DestroyPolyn(p);
	    DestroyPolyn(q);
	    p = r;
	}
	t->next = NULL;
	return ans;
}

term* ModPolyn(term* pa, term* pb) {
	term *s, *t, *ans;
	s = DevidePolyn(pa, pb);
	t = MultiPolyn(s, pb);
	ans = SubstractPolyn(pa, t);
	DestroyPolyn(s);
	DestroyPolyn(t);
	return ans;
}

int main(void){
	term *pa = NULL, *pb = NULL, *ans = NULL;
	char n;
	float a, b;
	int t;
	cout << "���س���ʼ" << endl; 
	while (1) {
		while(getchar() != '\n');
		PrintMenu();
		cin >> n;
		switch (n) {
			case '0':
			    exit(0);
			
			case '1':
				CreatePolyn(pa);
				break;
			
			case '2': 
			    CreatePolyn(pb);
			    break;
			    
			case '3':
			    PrintPolyn(pa, "f");
				PrintPolyn(pb, "g");
				break; 
				
			case '4':
				DestroyPolyn(pa);
				break;
			
			case '5': 
			    DestroyPolyn(pb);
			    break;
			    
			case '6': 
			    PrintPolyn(ans = AddPolyn(pa, pb), "sum");
			    DestroyPolyn(ans);
			    break;
			    
			case '7': 
			    PrintPolyn(ans = SubstractPolyn(pa, pb), "dif");
			    DestroyPolyn(ans);
			    break;
			    
			case 'a':
				cout << "��������ֵ" << endl;
	            while(getchar() != '\n');
	            cin >> a;
				cout << "���Ϊ" << Assign(pa, a) << endl;
				break;
				
			case 'b':
				cout << "�����󵼽���" << endl;
	            while(getchar() != '\n');
	            cin >> t;
	            PrintPolyn(ans = DerivatePolyn(pa, t), "der");
	            DestroyPolyn(ans);
	            break;
	            
	        case 'c':
	        	cout << "���붨��������"  << endl;
				while(getchar() != '\n');
				cout << "��ʼ��" ;
				cin >> a;
				while(getchar() != '\n'); 
				cout << "�յ㣺";
				cin >> b; 
	            cout << IntePolyn(pa, a, b) << endl;
				break;
				
			case'd':
				PrintPolyn(ans = MultiPolyn(pa, pb), "pro");
				DestroyPolyn(ans);
				break;
			
			case'e':
				PrintPolyn(ans = DevidePolyn(pa, pb), "quo");
				DestroyPolyn(ans);
				PrintPolyn(ans = ModPolyn(pa, pb), "rem");
			    DestroyPolyn(ans);
			    break;
				
			default:
				cout << "������������" << endl;
		}
		
	}
}
