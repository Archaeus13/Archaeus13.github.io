#define ElemType int
#include "ʵ��3-����-ԭ��.cpp"

class Graph{
private:
	int vexnum;
	char* vertex;
	bool** connection;
	int* visit;
	int FirstAdjVex(int m);
	int NextAdjVex(int m, int n);
	void DFS(int n);
	void BFS(int n, node* q);
	bool Connect(int m, int n, bool **a);
	int Min(int a, int b);
	
public:
    int Num(char v);
	int CreateEdge(char a, char b);
	int DestroyEdge(char a, char b);
	void CreateGraph(void);
	void DestroyGraph(void);
	void DFSTraverse(void);
	void BFSTraverse(node* q);
	void Prim(void);
	void Kruskal(void);
	int MinRoad(int a, int b);
};

void PrintMenu(void) {
	cout << "***************************" << endl; 
	cout << "0-�˳�" << endl;
	cout << "1-����ͼ" << endl;
	cout << "2-ɾ��ͼ" << endl;
	cout << "3-�����" << endl;
	cout << "4-ɾ����" << endl;
	cout << "5-DFS����" << endl;
	cout << "a-BFS����" << endl;
	cout << "b-��С������(����ķ)" << endl;
	cout << "c-��С������(��³˹����)" << endl;
	cout << "d-���·��" << endl; 
	cout << "***************************" << endl; 
}

int Graph::Num(char v) {
	for(int i = 0; i < vexnum; i++) if (vertex[i] == v) return i;
	return -1;
}

int Graph::CreateEdge(char a, char b) {
	int m, n;
	if ((m = Num(a)) == -1 || (n = Num(b)) == -1) {
		cout << "���󣺶��㲻����" << endl;
		return -1;
	}
	connection[m][n] = connection[n][m] = 1;
}

int Graph::DestroyEdge(char a, char b) {
	int m, n;
	if ((m = Num(a)) == -1 || (n = Num(b)) == -1) {
		cout << "���󣺶��㲻����" << endl;
		return -1;
	}
	connection[m][n] = connection[n][m] = 0;
}

void Graph::CreateGraph(void) {
	int n, i, j;
	char a, b;
	cout << "���붥������";
	cin >> n;
	vexnum = n;
	vertex = new char[n];
	connection = new bool*[n];
	for (i = 0; i < n; i++) connection[i] = new bool[n];
	visit = new int[n];
	for (i = 0; i < n; i++) for (j = 0; j < n; j++) connection[i][j] = 0;
	cout << "�����붥�㣺";
	while (getchar() != '\n');
	i = 0;
	while((a =  cin.get()) != '\n') vertex[i++] = a;
	cout << "���ӱߣ���00������" << endl;
	while (1) {
		cin >> a;
		cin >> b;
		cin.get();
		if (a != '0' || b != '0') CreateEdge(a, b);
		else break;
	}
}

void Graph::DestroyGraph(void) {
	delete[] vertex;
	for (int i = 0; i < vexnum; i++) delete[] connection[i];
	delete[] connection;
}

int Graph::FirstAdjVex(int m) {
	for (int i = 0; i < vexnum; i++) if (connection[m][i]) return i;
	return -1;
}

int Graph::NextAdjVex(int m, int n) {
	for (int i = n + 1; i < vexnum; i++) if (connection[m][i]) return i;
	return -1;
}

void Graph::DFS(int n) {
	cout << vertex[n];
	visit[n] = 1;
	for (int w = FirstAdjVex(n); w != -1; w = NextAdjVex(n, w)) if(!visit[w]) DFS(w);
}

void Graph::DFSTraverse(void) {
	int i;
	for (i = 0; i < vexnum; i++) visit[i] = 0;
	for (i = 0; i < vexnum; i++) if (!visit[i]) DFS(i);
	cout << endl;
}

void Graph::BFS(int n, node* q) {
	int t;
	InitQueue(q);
	EnQueue(q, n);
	while (!GetTop(q, t)) {
		DeQueue(q, t);
		if (!visit[t]) {
			cout << vertex[t];
			visit[t] = 1;
		}
		for (int w = FirstAdjVex(n); w != -1; w = NextAdjVex(n, w)) if(!visit[w]) EnQueue(q, w);
	}
	DestroyQueue(q);
}

void Graph::BFSTraverse(node* q) {
	int i;
	for (i = 0; i < vexnum; i++) visit[i] = 0;
	for (i = 0; i < vexnum; i++) if (!visit[i]) BFS(i, q);
	cout << endl;
}

void Graph::Prim(void) {
	bool a[vexnum] = {0};
	a[0] = 1;
	for (int i = 1; i < vexnum; i++)
		for (int j = 0; j < vexnum; j++) for (int k = 0; k < vexnum; k++)
		    if (connection[j][k] && a[j] && !a[k]) {
			    a[k] = 1;
			    cout << vertex[j] << vertex[k] << ' ';
		    }
	cout << endl;
}

bool Graph::Connect(int m, int n, bool** a) {
	if (m == n) return 1;
	visit[m] = 1;
	int w = -1, i;
	for (i = 0; i < vexnum; i++) if (a[m][i]) {
		w = i;
		break;
	}
	for (; w != -1; ) {
		if(!visit[w]) if (Connect(w, n, a)) return 1;
	    w = -1;
	    for (i++; i < vexnum; i++) if (a[m][i]) {
		    w = i;
		    break;
	    }
	}
	return 0;
}

void Graph::Kruskal(void) {
	int i, j, k;
	bool **t;
	t = new bool*[vexnum];
	for (i = 0; i < vexnum; i++) t[i] = new bool[vexnum];
	for (i = 0; i < vexnum; i++) for (j = 0; j < vexnum; j++) t[i][j] = 0;
	for (i = 0; i < vexnum; i++) for (j = i; j < vexnum; j++) {
		for (k = 0; k < vexnum; k++) visit[k] = 0;
		if (connection[i][j] && !Connect(i, j, t)) {
			t[i][j] = t[j][i] = 1;
			cout << vertex[i] << vertex[j] << ' ';
		}
	}
	cout << endl;
}

int Graph::Min(int a, int b) {
	visit[a] = 1; 
	if (a == b) return 0;
	int t, m = INT_MAX - vexnum;
	for (int w = FirstAdjVex(a); w != -1; w = NextAdjVex(a, w))
		if (!visit[w]) {
		    t = Min(w, b);
		    if (t < m) m = t;
	}
	return m + 1;
}

int Graph::MinRoad(int a, int b) {
	if (a == -1 || b == -1) {
		cout << "���󣺶��㲻����" << endl;
		return -1;
    }
    for (int i = 0; i < vexnum; i++) visit[i] = 0;
    if (!Connect(a, b, connection)) {
    	cout << "���󣺲���ͨ" << endl;
    	return -1;
	}
    for (int i = 0; i < vexnum; i++) visit[i] = 0;
	return Min(a, b);
}

int main(void) {
	Graph a;
	node* q = NULL;
	char n, x, y;
	cout << "���س���ʼ" << endl; 
	while (1) {
		while (getchar() != '\n');
		PrintMenu();
		cin >> n;
		switch (n) {
			case '0':
			    exit(0);
			
			case '1':
				a.CreateGraph();
				break;
			
			case '2':
				a.DestroyGraph();
			    break;
			    
			case '3':
				cin >> x;
				cin >> y;
				a.CreateEdge(x, y);
			    break;
			    
			case '4':
				cin >> x;
				cin >> y;
				a.DestroyEdge(x, y);
			    break;
			    
			case '5':
				a.DFSTraverse();
			    break;
			    
			case 'a':
				a.BFSTraverse(q);
				break;
				
			case 'b':
				a.Prim();
				break;
				
			case 'c':
				a.Kruskal();
			    break;
			
			case 'd':
				cin >> x;
				cin >> y;
				cout << "·������Ϊ" << a.MinRoad(a.Num(x), a.Num(y)) << endl;
			    break;
							
			default:
				cout << "������������" << endl;
		}
		
	}
}
