enum direction{up, down, leftward, rightward};
#define blocked 0
#define available 1 
#define passed 2
#define deadway 3
#define beginning 4
#define ending 5
#define ElemType direction
#include "ʵ��2-ջ-ԭ��.cpp"

void PrintMaze(int a[][12]) {
	cout << endl; 
	for (int i = 0; i < 12; i++) {
		for (int j = 0; j < 12; j++) {
			if (!a[i][j]) cout << "ǽ";
			if (a[i][j] == available) cout << "  ";
			if (a[i][j] == passed) cout << "��";
			if (a[i][j] == deadway) cout << "ʮ"; 
			if (a[i][j] == beginning) cout << "ʼ";
			if (a[i][j] == ending) cout << "��"; 
		}
		cout << endl;
	}
}

int main(void) {
	node* p = NULL;
	InitStack(p);
	direction t;
	int x = 1;
	int y = 1;
	int a[12][12] = {{0,0,0,0,0,0,0,0,0,0,0,0},
	                 {0,4,0,0,0,0,0,0,0,0,1,0},
				     {0,1,0,0,0,0,1,1,0,0,1,0},
		    		 {0,1,1,0,0,0,1,0,0,0,1,0},
					 {0,0,1,0,1,1,1,0,0,1,1,0},
					 {0,0,1,1,1,0,0,0,1,1,0,0},
					 {0,0,1,0,1,0,1,1,1,1,0,0},
	                 {0,1,1,1,1,0,1,0,0,1,0,0},
					 {0,1,0,1,0,0,1,0,0,1,1,0},
					 {0,1,1,1,1,1,1,1,1,0,0,0},
					 {0,0,0,0,1,0,0,0,1,1,0,0},
					 {0,0,0,0,0,0,0,0,0,0,0,0}};
	PrintMaze(a);
    while (x != 1 || y != 10) {
    	if (a[x][y+1] == available) {
			Push(p, rightward);
    		y++;
    		a[x][y] = passed;
		}
		else if (a[x+1][y] == available) {
    		Push(p, down);
    		x++;
    		a[x][y] = passed;
		}
		else if (a[x][y-1] == available) {
    		Push(p, leftward);
    		y--;
    		a[x][y] = passed;
		}
		else if (a[x-1][y] == available) {
    		Push(p, up);
    		x--;
    		a[x][y] = passed;
		}
		else {
			a[x][y] = deadway;
			Pop(p, t);
			if (t == rightward) y--;
			else if (t == down) x--;
			else if (t == leftward) y++;
			else if (t == up) x++;
		}
	}
	a[x][y] = ending;
	PrintMaze(a);
	DestroyStack(p);					   
}
