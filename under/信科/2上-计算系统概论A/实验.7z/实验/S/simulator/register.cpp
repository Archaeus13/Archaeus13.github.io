/*
 * @Author       : Chivier Humber
 * @Date         : 2021-09-15 21:26:21
 * @LastEditors  : Chivier Humber
 * @LastEditTime : 2021-09-20 18:00:46
 * @Description  : file content
 */

#include "register.h"

namespace virtual_machine_nsp {
    std::ostream& operator<<(std::ostream& os, const register_tp& reg) {
        os << "R0 = x" << std::hex << reg[R_R0] << ", ";
        os << "R1 = x" << std::hex << reg[R_R1] << ", ";
        os << "R2 = x" << std::hex << reg[R_R2] << ", ";
        os << "R3 = x" << std::hex << reg[R_R3] << std::endl;
        os << "R4 = x" << std::hex << reg[R_R4] << ", ";
        os << "R5 = x" << std::hex << reg[R_R5] << ", ";
        os << "R6 = x" << std::hex << reg[R_R6] << ", ";
        os << "R7 = x" << std::hex << reg[R_R7] << std::endl;
        os << "COND[NZP] = ";
		if (reg[R_COND] == 1) os << 'P';
		else if (reg[R_COND] == 2) os << 'Z';
		else if (reg[R_COND] == 4) os << 'N';
		else os << "PENDING";
		os << std::endl;
        os << "PC = x" << std::hex << reg[R_PC] << std::endl;
        return os;
    }
} // virtual machine namespace
