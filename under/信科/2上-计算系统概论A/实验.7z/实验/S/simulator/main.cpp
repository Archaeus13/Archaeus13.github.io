/*
 * @Author       : Chivier Humber
 * @Date         : 2021-09-14 21:41:49
 * @LastEditors  : Chivier Humber
 * @LastEditTime : 2021-11-24 05:33:45
 * @Description  : file content
 */
#include "simulator.h"

using namespace virtual_machine_nsp;

bool gIsSingleStepMode = false;
bool gIsDetailedMode = false;
std::string gRegisterStatusFileName = "register.txt";
std::string gInputFileName = "input.txt";
//std::string gOutputFileName = "";

std::pair<bool, std::string> getCmdOption(char **begin, char **end, const std::string &option) {
    char **itr = std::find(begin, end, option);
    if (itr != end && ++itr != end) {
        return std::make_pair(true, *itr);
    }
    return std::make_pair(false, "");
}

bool cmdOptionExists(char **begin, char **end, const std::string &option) {
    return std::find(begin, end, option) != end;
}

int main(int argc, char **argv) {
	if (cmdOptionExists(argv, argv + argc, "-h")) {
        std::cout << "[LC3 SIMULATOR] Options:" << std::endl;
        std::cout << "-h : print out help information" << std::endl;
        std::cout << "-f : the path for the input file" << std::endl;
        std::cout << "-r : the path for register status" << std::endl;
        std::cout << "-d : detailed mod" << std::endl;
        std::cout << "-s : single step mode" << std::endl;
        return 0;
    }
    
	auto input_info = getCmdOption(argv, argv + argc, "-f");
    auto register_info = getCmdOption(argv, argv + argc, "-r");
    
    if (input_info.first) gInputFileName = input_info.second;
    
    if (register_info.first) gRegisterStatusFileName = register_info.second;
    

    if (cmdOptionExists(argv, argv + argc, "-s")) {
        gIsSingleStepMode = true;
    }
    if (cmdOptionExists(argv, argv + argc, "-d")) {
        gIsDetailedMode = true;
    }

    virtual_machine_tp virtual_machine(0x3000, gInputFileName, gRegisterStatusFileName);
    int halt_flag = true;
    int time_flag = 0;
    while (halt_flag) {
        // Single step
        virtual_machine.NextStep(halt_flag);
        if (gIsSingleStepMode || gIsDetailedMode) {
        	std::cout << virtual_machine.reg;
        	if (!gIsSingleStepMode) std::cout << std::endl;
        	else getchar();
		}
        ++time_flag;
    }

    std::cout << virtual_machine.reg << std::endl;
    std::cout << "cycle = " << time_flag << std::endl;
    return 0;
}
