#include <iostream>
using namespace std;

int main(void) {
	short r0, r1, r2 = 1, r3, r7 = 0;
	cin >> r0;
	cin >> r1;
	do {
		r3 = r2 & r1;
		if (r3) r7 += r0;
		r2 = r2 << 1;
		r0 = r0 << 1;
	}
	while (r0);
	cout << r7 << endl;
}
 
