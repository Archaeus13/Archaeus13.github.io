#include <iostream>
using namespace std;

void Recur(int &r0, int &r1) {
	r0++;
	r1--;
	if (r1) Recur(r0, r1);
} 

int main(void) {
	int r0 = 0, r1;
	cin >> r1;
	Recur(r0, r1);
	cout << r0 << endl;
}
