#include <iostream>
using namespace std;

int judge(int r0) {
	int r1 = 1, r2 = 1, r3, r4;
	do {
		r2++;
		r4 = 0;
		r3 = r2;
		do r4 += r2; while(--r3);
		r4 = r0 - r4;
		if (r4 < 0) return r1;
		r3 = r0;
		do r3 -= r2; while (r3 > 0);
	}
	while (r3);
	r1 = 0;
	return r1;
}

int main(void) {
	int r0, r1;
	cin >> r0;
	r1 = judge(r0);
	cout << r1 << endl;
}

