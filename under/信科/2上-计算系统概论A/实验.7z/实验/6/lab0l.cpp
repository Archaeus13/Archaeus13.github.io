#include <iostream>
using namespace std;

int main(void) {
	short r0, r1, r7 = 0;
	cin >> r0;
	cin >> r1;
	do r7 += r1; while (--r0);
	cout << r7 << endl;
}
