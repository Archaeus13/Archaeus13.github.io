#include <iostream>
using namespace std;

int main(void) {
	int r0, r1 = 1023, r4 = 1, r5 = 1, r6 = 2, r7 = 2;
	cin >> r0;
	r0 -= 3;
	if (r0 < 0) r7 = r0 + 1;
	do {
		r7 = (r7 + 2*r4) & r1;
		r4 = r5;
		r5 = r6;
		r6 = r7;
	}
	while (--r0 >= 0);
	cout << r7 << endl;
}
