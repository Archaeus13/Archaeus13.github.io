#include <iostream>
using namespace std;

short Devide8 (short r1) {
	short r2 = 1, r3 = 8, r4 = 0;
	do {
		if (r3 & r1) r4 += r2;
		r2 = r2 << 1;
		r3 = r3 << 1;
	}
	while (r3);
	return r4;
}

int main(void) {
	short r1, r2, r4;
	cin >> r1;
	do {
		r4 = Devide8(r1);
		r2 = r1 & 7;
		r1 = r2 + r4;
	}
	while (r1 > 7);
	if (r1 == 7) r1 -= 7;
	cout << r1 << endl; 
}
