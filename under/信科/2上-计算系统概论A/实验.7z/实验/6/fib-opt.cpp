#include <iostream>
using namespace std;

int main(void) {
	int r0, r1 = 1023, r4 = 1, r5 = 1, r6 = 2, r7 = 2;
	cin >> r0;
	r0 -= 3;
	do {
		r4 = 2 * r4 + r6;
		r5 = 2 * r5 + r4;
		r6 = 2 * r6 + r5;
		r0 -= 3;
	}
	while (r0 >= 0);
	r0 += 2;
	r0 += 2;
	if (r0 < 0) r7 = r4 & r1;
	else if (!r0) r7 = r5 & r1;
	else r7 = r6 & r1;
	cout << r7 << endl;
}
